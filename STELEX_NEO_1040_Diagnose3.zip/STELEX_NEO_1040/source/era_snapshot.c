#include "era_snapshot.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

/* Member metadata from Vincent1232/Fortnite-sdks,
   commit f53c167439fd3b7b5bfbcf7e88f01a672852a280, SDK 10.40-CL-9380822.
   SDK source is not included or executed. GWorld is deliberately unused.
   The user's static client report independently supplies the AppendString
   call, 16384-name chunks and manager+0xB8 table. The getter is only read,
   never called. Its RIP-relative candidates require five fixed names and
   stable pointer evidence before use; no ERA GNames address is retained. */
enum {
    O_GOBJECTS=0x64A0090,O_APPEND_STRING=0x214EC80,O_NAMES_CHUNKS=0xB8,
    O_TEXT_START=0x1000,O_TEXT_END=0x04457E00,
    O_DATA_START=0x05CA9000,O_DATA_END=0x0664EBB8,
    O_CLASS=0x10,O_NAME=0x18,O_SUPER=0x40,
    O_VIEWPORT=0x750,O_VIEWPORT_WORLD=0x78,O_WORLD_INSTANCE=0x160,
    O_WORLD_GAMESTATE=0x120,O_LOCAL_PLAYERS=0x38,O_LOCAL_CONTROLLER=0x30,
    O_LOCAL_PAWN=0x298,O_CAMERA_MANAGER=0x2B0,O_CAMERA_POV=0x1920,
    O_POV_FLAGS=0x30,O_POV_PROJECTION=0x34,O_POV_OFF_CENTER=0x570,
    O_PLAYER_ARRAY=0x230,O_STATE_PAWN=0x2A0,O_PLAYER_NAME=0x320,
    O_PAWN_STATE=0x238,O_ROOT=0x130,O_MESH=0x278,O_TEAM=0xDB0,
    O_DYING=0x6A8,O_DOWNED=0x6AF,
    O_HEALTH_SET=0xCC0,O_HEALTH=0x30,O_MAX_HEALTH=0x58,O_CURRENT_SHIELD=0x80,
    O_ATTRIBUTE_VALUE=0xC,O_ATTRIBUTE_MAX=0x14,O_CURRENT_CLAMPED=0x18,
    O_ATTACH_PARENT=0xC0,O_ATTACH_SOCKET=0xC8,O_RELATIVE=0x11C,
    O_SCENE_FLAGS=0x14C,O_MESH_ASSET=0x3E8,O_BONE_POSES=0x648,
    OBJECTS_PER_CHUNK=65536,NAMES_PER_CHUNK=16384,
    OBJECT_STRIDE=24,MAX_OBJECTS=4000000,MAX_PLAYERS=256,
    NAME_CACHE=1024,MESH_CACHE=32,CLASS_CACHE=128
};
typedef struct { uint64_t data;int32_t count,capacity; } RemoteArray;
typedef struct { int32_t index,number,parent; } BoneInfo;
typedef struct { uint64_t pointer;uint32_t flags;int32_t index;uint64_t class_ptr;int32_t name,number;uint64_t outer; } ObjectHeader;
typedef struct { uint64_t pointer;int valid,source_count;unsigned retry_after;int indexes[ERA_MAX_BONES]; } MeshMap;
typedef struct { int32_t index;int valid;char text[64]; } NameCache;
typedef struct { uint64_t pointer;int kind; } ClassCache;
struct EraSnapshotReader {
    EraReadMemory read;void*context;uint64_t base,engine,world,instance,name_pool;
    uint64_t name_origin,name_manager,name_chunk,name_first;
    int name_indirect,name_offset,name_ready,object_cursor,mesh_budget;
    unsigned steps,names_retry;
    uint64_t chunks;int object_count,num_chunks;
    NameCache names[NAME_CACHE];MeshMap meshes[MESH_CACHE];
    ClassCache classes[CLASS_CACHE];unsigned mesh_next;
    EraNameDiagnostic name_diagnostic;
    int name_probe_active;EraNameReason name_probe_reason;
    uint64_t name_probe_address;size_t name_probe_bytes;
};
_Static_assert(sizeof(RemoteArray)==16,"remote TArray layout");
_Static_assert(sizeof(BoneInfo)==12,"cooked bone metadata layout");
_Static_assert(sizeof(ObjectHeader)==40,"remote UObject header layout");
_Static_assert(sizeof(EraTransform)==48,"remote FTransform layout");

static int pointer_ok(uint64_t pointer){return pointer>=0x10000&&pointer<UINT64_C(0x0000800000000000);}
static void name_probe_reset(EraSnapshotReader*r){
    r->name_probe_reason=ERA_NAME_REASON_NONE;r->name_probe_address=0;r->name_probe_bytes=0;
}
static void name_probe_failure(EraSnapshotReader*r,EraNameReason reason,uint64_t address,size_t bytes){
    if(!r||!r->name_probe_active||r->name_probe_reason!=ERA_NAME_REASON_NONE)return;
    r->name_probe_reason=reason;r->name_probe_address=address;r->name_probe_bytes=bytes;
}
static int read_at(EraSnapshotReader*r,uint64_t address,void*out,size_t bytes){
    if(!r||!r->read||!out||!pointer_ok(address)||bytes>1024*1024||bytes>UINT64_C(0x0000800000000000)-address){
        name_probe_failure(r,ERA_NAME_REASON_INVALID_POINTER,0,0);return 0;
    }
    if(!r->read(r->context,address,out,bytes)){
        name_probe_failure(r,ERA_NAME_REASON_READ_FAILED,address,bytes);return 0;
    }
    return 1;
}
static int read_pointer(EraSnapshotReader*r,uint64_t object,unsigned offset,uint64_t*out){
    *out=0;
    if(!pointer_ok(object)){name_probe_failure(r,ERA_NAME_REASON_INVALID_POINTER,0,0);return 0;}
    return read_at(r,object+offset,out,sizeof(*out));
}
static int array_ok(RemoteArray array,int limit){
    return array.count>=0&&array.count<=limit&&array.capacity>=array.count&&
        array.capacity<=limit*8&&(array.count==0||pointer_ok(array.data));
}
static int ascii_entry(EraSnapshotReader*r,uint64_t pool,int offset,int32_t index,char*out,size_t size){
    uint64_t chunk=0,entry=0;
    if(out&&size)out[0]=0;
    if(index<0||index>2000000||size<2||!read_pointer(r,pool,(unsigned)(index/NAMES_PER_CHUNK)*8,&chunk)||
       !read_pointer(r,chunk,(unsigned)(index%NAMES_PER_CHUNK)*8,&entry))return 0;
    if(!pointer_ok(entry)){name_probe_failure(r,ERA_NAME_REASON_INVALID_POINTER,0,0);return 0;}
    unsigned char flags=0;
    if(!read_at(r,entry+8,&flags,1)||(flags&1))return 0;
    for(size_t i=0;i<size;i++){
        unsigned char value=0;if(!read_at(r,entry+(unsigned)offset+i,&value,1))return 0;
        if(!value){out[i]=0;return i>0;}
        if(value<32||value>126||i==size-1)return 0;
        out[i]=(char)value;
    }
    return 0;
}
static int name_pool_current(EraSnapshotReader*r){
    uint64_t manager=r->name_origin,chunk=0,first=0;unsigned char flags=0;char none[5];
    if(r->name_indirect&&!read_at(r,r->name_origin,&manager,8))return 0;
    return manager==r->name_manager&&
        read_pointer(r,r->name_pool,0,&chunk)&&chunk==r->name_chunk&&
        read_pointer(r,chunk,0,&first)&&first==r->name_first&&
        read_at(r,first+8,&flags,1)&&!(flags&1)&&
        read_at(r,first+(unsigned)r->name_offset,none,sizeof(none))&&memcmp(none,"None",5)==0;
}
static void name_diagnostic_failure(EraSnapshotReader*r,EraNameStage stage,EraNameReason reason,
                                    unsigned matched,int offset){
    EraNameDiagnostic*d=&r->name_diagnostic;
    /* Prefer the deepest validated stage, then the most fixed names. At an
       equal stage/prefix, a concrete failed read is more useful than a mismatch
       from the other text-layout candidate. Never hide a better candidate. */
    if(stage<d->stage||(stage==d->stage&&matched<d->sentinels_matched))return;
    if(stage==d->stage&&matched==d->sentinels_matched&&
       d->reason==ERA_NAME_REASON_READ_FAILED&&reason!=ERA_NAME_REASON_READ_FAILED&&
       reason!=ERA_NAME_REASON_AMBIGUOUS)return;
    d->stage=stage;d->reason=reason;d->sentinels_matched=matched;d->entry_offset=offset;
    d->failed_address=reason==ERA_NAME_REASON_READ_FAILED?r->name_probe_address:0;
    d->failed_bytes=reason==ERA_NAME_REASON_READ_FAILED?r->name_probe_bytes:0;
}
static int name_attempt_failed(EraSnapshotReader*r,EraNameStage stage,EraNameReason reason){
    name_diagnostic_failure(r,stage,reason,0,0);r->name_probe_active=0;return 0;
}
/* Candidate discovery is bounded to the getter called by the known client
   AppendString. Raw RIP-byte matches are not instruction-boundary proof;
   data-section bounds, independent fixed names, uniqueness and stable reads
   are mandatory. No target function is executed or remotely invoked. */
static int find_name_pool(EraSnapshotReader*r){
    static const char*expected[]={"None","ByteProperty","IntProperty","BoolProperty","FloatProperty"};
    static const unsigned char prefix[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x48,0x89,0x7c,0x24,0x18,0x41,0x56,0x48,0x83,0xec,0x20,0x48,0x8b,0xda,0x4c,0x8b,0xf1,0xe8};
    static const unsigned char lookup[]={0x49,0x8b,0x84,0xc1,0xb8,0,0,0,0x48,0x8b,0x0c,0xd0};
    unsigned char append[0x4F],getter[256];int32_t displacement=0;
    unsigned attempt=r->name_diagnostic.attempt+1U;
    memset(&r->name_diagnostic,0,sizeof(r->name_diagnostic));
    r->name_diagnostic.attempt=attempt;r->name_probe_active=1;name_probe_reset(r);
    if(!read_at(r,r->base+O_APPEND_STRING,append,sizeof(append)))
        return name_attempt_failed(r,ERA_NAME_STAGE_APPEND,r->name_probe_reason);
    if(memcmp(append,prefix,sizeof(prefix))||memcmp(append+0x43,lookup,sizeof(lookup)))
        return name_attempt_failed(r,ERA_NAME_STAGE_APPEND,ERA_NAME_REASON_PREFIX_MISMATCH);
    memcpy(&displacement,append+0x1C,4);
    int64_t getter_rva=(int64_t)O_APPEND_STRING+0x20+displacement;
    r->name_diagnostic.getter_rva=getter_rva;
    if(getter_rva<O_TEXT_START||getter_rva>O_TEXT_END-(int64_t)sizeof(getter))
        return name_attempt_failed(r,ERA_NAME_STAGE_GETTER,ERA_NAME_REASON_GETTER_BOUNDS);
    if(!read_at(r,r->base+(uint64_t)getter_rva,getter,sizeof(getter)))
        return name_attempt_failed(r,ERA_NAME_STAGE_GETTER,r->name_probe_reason);
    r->name_diagnostic.stage=ERA_NAME_STAGE_CANDIDATE;
    r->name_diagnostic.reason=ERA_NAME_REASON_NO_RIP_CANDIDATE;
    uint64_t found=0,origin=0,manager_found=0,chunk_found=0,first_found=0;
    int chosen=0,indirect_found=0;
    for(unsigned i=0;i+7<=sizeof(getter);i++){
        if(getter[i]!=0x48||(getter[i+1]!=0x8B&&getter[i+1]!=0x8D)||getter[i+2]!=0x05)continue;
        r->name_diagnostic.rip_candidates++;
        memcpy(&displacement,getter+i+3,4);
        int64_t target=getter_rva+i+7+displacement;
        if(target<O_DATA_START||target>O_DATA_END-8)continue;
        r->name_diagnostic.data_candidates++;name_probe_reset(r);
        uint64_t candidate_origin=r->base+(uint64_t)target,manager=candidate_origin;
        int indirect=getter[i+1]==0x8B;
        if(indirect&&!read_at(r,candidate_origin,&manager,8)){
            name_diagnostic_failure(r,ERA_NAME_STAGE_CANDIDATE,r->name_probe_reason,0,0);continue;
        }
        if(!pointer_ok(manager)){
            name_diagnostic_failure(r,ERA_NAME_STAGE_CANDIDATE,ERA_NAME_REASON_INVALID_POINTER,0,0);continue;
        }
        uint64_t pool=manager+O_NAMES_CHUNKS,chunk=0,first=0;
        if(!read_pointer(r,pool,0,&chunk)||!read_pointer(r,chunk,0,&first)){
            name_diagnostic_failure(r,ERA_NAME_STAGE_CANDIDATE,r->name_probe_reason,0,0);continue;
        }
        if(!pointer_ok(first)){
            name_diagnostic_failure(r,ERA_NAME_STAGE_CANDIDATE,ERA_NAME_REASON_INVALID_POINTER,0,0);continue;
        }
        r->name_diagnostic.readable_candidates++;
        for(int offset=12;offset<=16;offset+=4){
            int valid=1,stable=1;char text[64];unsigned matched=0;name_probe_reset(r);
            for(int n=0;valid&&n<5;n++){
                valid=ascii_entry(r,pool,offset,n,text,sizeof(text))&&strcmp(text,expected[n])==0;
                if(valid)matched++;
            }
            if(!valid)name_diagnostic_failure(r,ERA_NAME_STAGE_SENTINELS,
                r->name_probe_reason==ERA_NAME_REASON_NONE?ERA_NAME_REASON_SENTINEL_MISMATCH:r->name_probe_reason,matched,offset);
            name_probe_reset(r);
            uint64_t after_manager=candidate_origin,after_chunk=0,after_first=0;
            if(indirect&&(!read_at(r,candidate_origin,&after_manager,8)||after_manager!=manager))stable=0;
            if(!read_pointer(r,pool,0,&after_chunk)||after_chunk!=chunk||
               !read_pointer(r,after_chunk,0,&after_first)||after_first!=first)stable=0;
            if(valid&&!stable)name_diagnostic_failure(r,ERA_NAME_STAGE_STABILITY,
                r->name_probe_reason==ERA_NAME_REASON_NONE?ERA_NAME_REASON_UNSTABLE:r->name_probe_reason,matched,offset);
            if(!valid||!stable)continue;
            r->name_diagnostic.valid_candidates++;
            if(found&&(found!=pool||chosen!=offset)){
                name_diagnostic_failure(r,ERA_NAME_STAGE_STABILITY,ERA_NAME_REASON_AMBIGUOUS,5,offset);
                r->name_probe_active=0;return 0;
            }
            found=pool;chosen=offset;origin=candidate_origin;manager_found=manager;
            chunk_found=chunk;first_found=first;indirect_found=indirect;
        }
    }
    r->name_probe_active=0;if(!found)return 0;
    r->name_pool=found;r->name_offset=chosen;r->name_ready=1;
    r->name_origin=origin;r->name_manager=manager_found;r->name_chunk=chunk_found;
    r->name_first=first_found;r->name_indirect=indirect_found;
    memset(r->names,0,sizeof(r->names));
    r->name_diagnostic.stage=ERA_NAME_STAGE_READY;r->name_diagnostic.reason=ERA_NAME_REASON_NONE;
    r->name_diagnostic.sentinels_matched=5;r->name_diagnostic.entry_offset=chosen;
    r->name_diagnostic.failed_address=0;r->name_diagnostic.failed_bytes=0;return 1;
}
static int name_text(EraSnapshotReader*r,int32_t index,char*out,size_t size){
    if(!r->name_ready||index<0||size<2)return 0;
    NameCache*cache=&r->names[(unsigned)index%NAME_CACHE];
    if(!cache->valid||cache->index!=index){
        cache->valid=0;if(!ascii_entry(r,r->name_pool,r->name_offset,index,cache->text,sizeof(cache->text)))return 0;
        cache->index=index;cache->valid=1;
    }
    size_t length=strlen(cache->text);if(length>=size)return 0;memcpy(out,cache->text,length+1);return 1;
}
static int object_header(EraSnapshotReader*r,uint64_t pointer,ObjectHeader*out){
    return read_at(r,pointer,out,sizeof(*out))&&pointer_ok(out->pointer)&&pointer_ok(out->class_ptr)&&out->index>=0&&out->name>=0;
}
enum {K_ENGINE=1,K_PAWN=2,K_STATE=4};
static int class_kind(EraSnapshotReader*r,uint64_t class_ptr){
    ClassCache*cache=&r->classes[(unsigned)(class_ptr>>4)%CLASS_CACHE];
    if(cache->pointer==class_ptr)return cache->kind;
    uint64_t current=class_ptr,visited[20];int count=0,kind=0;
    while(pointer_ok(current)&&count<20){
        for(int i=0;i<count;i++)if(visited[i]==current)return 0;
        visited[count++]=current;int32_t name=0;char text[64];
        if(!read_at(r,current+O_NAME,&name,4)||!name_text(r,name,text,sizeof(text)))return 0;
        if(strcmp(text,"FortEngine")==0)kind|=K_ENGINE;
        if(strcmp(text,"FortPlayerPawn")==0||strcmp(text,"FortPlayerPawnAthena")==0)kind|=K_PAWN;
        if(strcmp(text,"FortPlayerStateAthena")==0)kind|=K_STATE;
        uint64_t parent=0;if(!read_pointer(r,current,O_SUPER,&parent))return 0;current=parent;
    }
    if(current)return 0;
    cache->pointer=class_ptr;cache->kind=kind;return kind;
}
static int object_is(EraSnapshotReader*r,uint64_t pointer,int kind){
    ObjectHeader object;return object_header(r,pointer,&object)&&!(object.flags&0x10U)&&(class_kind(r,object.class_ptr)&kind)!=0;
}
static int objects_header(EraSnapshotReader*r){
    unsigned char block[32];int32_t maximum=0,max_chunks=0;
    if(!read_at(r,r->base+O_GOBJECTS,block,sizeof(block)))return 0;
    memcpy(&r->chunks,block,8);memcpy(&maximum,block+16,4);memcpy(&r->object_count,block+20,4);
    memcpy(&max_chunks,block+24,4);memcpy(&r->num_chunks,block+28,4);
    return pointer_ok(r->chunks)&&r->object_count>0&&r->object_count<=MAX_OBJECTS&&maximum>=r->object_count&&
        maximum<=MAX_OBJECTS&&r->num_chunks>0&&r->num_chunks<=64&&max_chunks>=r->num_chunks&&max_chunks<=64&&
        r->object_count<=r->num_chunks*OBJECTS_PER_CHUNK;
}
static void clear_derived_caches(EraSnapshotReader*r){
    r->mesh_next=0;
    /* Class and mesh pointers can be reused after travel. Names remain
       process-global and are invalidated independently with their manager. */
    memset(r->classes,0,sizeof(r->classes));memset(r->meshes,0,sizeof(r->meshes));
}
static void forget_engine(EraSnapshotReader*r){
    r->engine=0;r->world=0;r->instance=0;r->object_cursor=0;
    clear_derived_caches(r);
}
static int engine_step(EraSnapshotReader*r){
    if(!objects_header(r))return -1;
    if(r->object_cursor>=r->object_count)r->object_cursor=0;
    int count=r->object_count-r->object_cursor;if(count>256)count=256;
    int chunk_remaining=OBJECTS_PER_CHUNK-r->object_cursor%OBJECTS_PER_CHUNK;
    if(count>chunk_remaining)count=chunk_remaining;
    uint64_t chunk=0;if(!read_pointer(r,r->chunks,(unsigned)(r->object_cursor/OBJECTS_PER_CHUNK)*8,&chunk))return -1;
    unsigned char block[256*OBJECT_STRIDE];
    if(!read_at(r,chunk+(unsigned)(r->object_cursor%OBJECTS_PER_CHUNK)*OBJECT_STRIDE,block,(size_t)count*OBJECT_STRIDE))return -1;
    int waiting_world=0;
    for(int i=0;i<count;i++){
        uint64_t object=0;memcpy(&object,block+(size_t)i*OBJECT_STRIDE,8);
        if(!pointer_ok(object)||!object_is(r,object,K_ENGINE))continue;
        uint64_t viewport=0,world=0,instance=0;
        /* A retired Engine can remain in GObjects with an empty World path.
           Do not repeatedly choose it ahead of an active replacement. */
        if(read_pointer(r,object,O_VIEWPORT,&viewport)&&pointer_ok(viewport)&&
           read_pointer(r,viewport,O_VIEWPORT_WORLD,&world)&&pointer_ok(world)&&
           read_pointer(r,world,O_WORLD_INSTANCE,&instance)&&pointer_ok(instance)){
            r->engine=object;r->object_cursor+=count;return 1;
        }
        waiting_world=1;
    }
    r->object_cursor+=count;return waiting_world?2:0;
}
static int scene_transform(EraSnapshotReader*r,uint64_t component,EraTransform*out){
    struct Scene {uint64_t pointer;EraTransform local;unsigned char flags;} chain[16];int count=0;
    while(component){
        if(!pointer_ok(component)||count==16)return 0;
        for(int i=0;i<count;i++)if(chain[i].pointer==component)return 0;
        EraVec3 relative[3];uint64_t parent=0;int32_t socket[2]={0,0};unsigned char flags=0;
        if(!read_at(r,component+O_RELATIVE,relative,sizeof(relative))||!read_pointer(r,component,O_ATTACH_PARENT,&parent)||
           !read_at(r,component+O_ATTACH_SOCKET,socket,sizeof(socket))||!read_at(r,component+O_SCENE_FLAGS,&flags,1)||
           !era_vec_valid(relative[0])||!era_vec_valid(relative[1])||!era_vec_valid(relative[2]))return 0;
        /* A named attachment needs the parent's socket pose, not its origin. */
        if(parent&&(socket[0]!=0||socket[1]!=0))return 0;
        chain[count].pointer=component;chain[count].flags=flags;
        chain[count].local=(EraTransform){era_rotation_quat(relative[1]),relative[0],0,relative[2],0};
        if(!era_transform_valid(&chain[count].local))return 0;
        count++;component=parent;
    }
    EraTransform world={{0,0,0,1},{0,0,0},0,{1,1,1},0};
    for(int i=count-1;i>=0;i--){
        EraTransform combined=era_transform_combine(&world,&chain[i].local);
        if(chain[i].flags&4)combined.translation=chain[i].local.translation;
        if(chain[i].flags&8)combined.rotation=chain[i].local.rotation;
        if(chain[i].flags&16)combined.scale=chain[i].local.scale;
        if(!era_transform_valid(&combined))return 0;
        world=combined;
    }
    *out=world;return count>0;
}
static const char*bone_names[ERA_MAX_BONES]={
    [ERA_HEAD]="head",[ERA_NECK]="neck_01",[ERA_PELVIS]="pelvis",
    [ERA_CHEST]="spine_03",[ERA_L_UPPERARM]="upperarm_l",
    [ERA_L_FOREARM]="lowerarm_l",[ERA_L_HAND]="hand_l",
    [ERA_R_UPPERARM]="upperarm_r",[ERA_R_FOREARM]="lowerarm_r",
    [ERA_R_HAND]="hand_r",[ERA_L_THIGH]="thigh_l",
    [ERA_L_CALF]="calf_l",[ERA_L_FOOT]="foot_l",
    [ERA_R_THIGH]="thigh_r",[ERA_R_CALF]="calf_r",[ERA_R_FOOT]="foot_r",
    [ERA_SPINE_01]="spine_01",[ERA_SPINE_02]="spine_02",
    [ERA_L_CLAVICLE]="clavicle_l",[ERA_R_CLAVICLE]="clavicle_r"
};
static int bone_map_candidate(EraSnapshotReader*r,RemoteArray infos,int bone_count,int*out){
    if(!array_ok(infos,512)||infos.count!=bone_count||infos.count<4)return 0;
    BoneInfo entries[512];if(!read_at(r,infos.data,entries,(size_t)infos.count*sizeof(entries[0])))return 0;
    for(int i=0;i<ERA_MAX_BONES;i++)out[i]=-1;
    int32_t names[512];
    for(int i=0;i<infos.count;i++){
        if(entries[i].number!=0||entries[i].index<0||(i==0&&entries[i].parent!=-1)||
           (i>0&&(entries[i].parent<0||entries[i].parent>=i)))return 0;
        for(int j=0;j<i;j++)if(names[j]==entries[i].index)return 0;
        names[i]=entries[i].index;char name[64];if(!name_text(r,entries[i].index,name,sizeof(name)))return 0;
        if(i==0&&strcmp(name,"root")!=0)return 0;
        for(int j=0;j<ERA_MAX_BONES;j++)if(strcmp(name,bone_names[j])==0)out[j]=i;
    }
    return out[0]>=0&&out[1]>=0&&out[2]>=0&&out[3]>=0;
}
static MeshMap*mesh_map(EraSnapshotReader*r,uint64_t asset,int count){
    MeshMap*reuse=NULL;
    for(int i=0;i<MESH_CACHE;i++)if(r->meshes[i].pointer==asset&&r->meshes[i].source_count==count){
        if(r->meshes[i].valid)return &r->meshes[i];
        if((int32_t)(r->steps-r->meshes[i].retry_after)<0)return NULL;
        reuse=&r->meshes[i];break;
    }
    if(!r->mesh_budget)return NULL;
    r->mesh_budget--;
    MeshMap result={0};result.pointer=asset;result.source_count=count;result.retry_after=r->steps+64U;
    unsigned char header[0x360];int header_read=read_at(r,asset,header,sizeof(header));
    /* Private reference-skeleton placement is not supplied by the SDK. Accept
       only a structurally verified pair of metadata and reference-pose arrays,
       entirely within the SDK's private region. No bone index is guessed. */
    for(unsigned offset=0x178;header_read&&offset+32<=0x2F0;offset+=8){
        RemoteArray infos,poses;memcpy(&infos,header+offset,16);memcpy(&poses,header+offset+16,16);
        if(!array_ok(infos,512)||infos.count!=count||!array_ok(poses,512)||poses.count!=count)continue;
        EraTransform pose;if(!read_at(r,poses.data,&pose,sizeof(pose))||!era_transform_valid(&pose))continue;
        int indexes[ERA_MAX_BONES];if(!bone_map_candidate(r,infos,count,indexes))continue;
        if(result.valid&&memcmp(indexes,result.indexes,sizeof(indexes))!=0){result.valid=0;break;}
        memcpy(result.indexes,indexes,sizeof(indexes));result.valid=1;
    }
    /* Failed header reads need the same retry backoff as invalid metadata.
       Otherwise the local pawn can consume the only lookup budget forever. */
    MeshMap*slot=reuse?reuse:&r->meshes[r->mesh_next++%MESH_CACHE];*slot=result;return slot->valid?slot:NULL;
}
static void read_bones(EraSnapshotReader*r,uint64_t pawn,EraEntity*entity){
    uint64_t mesh=0,asset=0;RemoteArray poses;
    if(!read_pointer(r,pawn,O_MESH,&mesh)||!pointer_ok(mesh)||!read_pointer(r,mesh,O_MESH_ASSET,&asset)||!pointer_ok(asset)||
       !read_at(r,mesh+O_BONE_POSES,&poses,sizeof(poses))||!array_ok(poses,512)||poses.count<4)return;
    MeshMap*map=mesh_map(r,asset,poses.count);if(!map)return;
    EraTransform component;if(!scene_transform(r,mesh,&component))return;
    EraTransform transforms[512];if(!read_at(r,poses.data,transforms,(size_t)poses.count*sizeof(transforms[0])))return;
    RemoteArray after;uint64_t after_asset=0;
    if(!read_at(r,mesh+O_BONE_POSES,&after,sizeof(after))||memcmp(&after,&poses,sizeof(after))!=0||
       !read_pointer(r,mesh,O_MESH_ASSET,&after_asset)||after_asset!=asset)return;
    for(int i=0;i<ERA_MAX_BONES;i++){
        int index=map->indexes[i];if(index<0||index>=poses.count||!era_transform_valid(&transforms[index]))continue;
        EraVec3 point=era_transform_point(&component,transforms[index].translation);
        if(!era_vec_valid(point)||era_distance(point,entity->root)>500.0f)continue;
        entity->bones[i]=point;entity->bone_mask|=1U<<(unsigned)i;
    }
    const int targets[]={ERA_HEAD,ERA_NECK,ERA_CHEST};
    for(int i=0;i<3;i++)if(entity->bone_mask&(1U<<(unsigned)targets[i])){entity->targets[i]=entity->bones[targets[i]];entity->target_mask|=1U<<(unsigned)i;}
}
static void player_name(EraSnapshotReader*r,uint64_t state,char*out,size_t size){
    RemoteArray string;if(size<2||!read_at(r,state+O_PLAYER_NAME,&string,sizeof(string))||!array_ok(string,256)||string.count<1||string.count>96)return;
    uint16_t input[96];if(!read_at(r,string.data,input,(size_t)string.count*2)||input[string.count-1]!=0)return;
    size_t used=0;
    for(int i=0;i<string.count-1&&used+1<size;i++){
        uint32_t c=input[i];if(c<32||c==127)continue;
        if(c>=0xD800&&c<=0xDBFF){
            if(i+1>=string.count-1||input[i+1]<0xDC00||input[i+1]>0xDFFF){out[0]=0;return;}
            c=0x10000+((c-0xD800)<<10)+(input[++i]-0xDC00);
        }else if(c>=0xDC00&&c<=0xDFFF){out[0]=0;return;}
        unsigned bytes=c<128?1:c<2048?2:c<65536?3:4;if(used+bytes>=size)break;
        if(bytes==1)out[used++]=(char)c;
        else{
            out[used++]=(char)((bytes==2?0xC0:bytes==3?0xE0:0xF0)|(c>>(6*(bytes-1))));
            for(unsigned j=bytes-1;j>0;j--)out[used++]=(char)(0x80|((c>>(6*(j-1)))&0x3F));
        }
    }
    out[used]=0;
}
static void read_vitals(EraSnapshotReader*r,uint64_t pawn,EraEntity*out){
    uint64_t set=0;unsigned char attributes[0x78];
    if(!read_pointer(r,pawn,O_HEALTH_SET,&set)||!pointer_ok(set)||
       !read_at(r,set+O_HEALTH,attributes,sizeof(attributes)))return;
    float health=0,maximum=0,shield=0,shield_bound=0;
    memcpy(&health,attributes+O_ATTRIBUTE_VALUE,4);
    memcpy(&maximum,attributes+O_MAX_HEALTH-O_HEALTH+O_ATTRIBUTE_VALUE,4);
    memcpy(&shield,attributes+O_CURRENT_SHIELD-O_HEALTH+O_ATTRIBUTE_VALUE,4);
    memcpy(&shield_bound,attributes+O_CURRENT_SHIELD-O_HEALTH+O_ATTRIBUTE_MAX,4);
    if(isfinite(health)&&isfinite(maximum)&&health>=0&&maximum>0&&maximum<=10000&&health<=maximum+0.001f){
        out->health=health;out->max_health=maximum;out->health_valid=1;
        if(health==0)out->alive=0;
    }
    if(isfinite(shield)&&shield>=0&&shield<=10000){
        out->shield=shield;out->shield_valid=1;
        /* A configured attribute clamp is a usable display bound. Without it
           only the actual current shield is published; no assumed 100 cap. */
        unsigned char clamped=attributes[O_CURRENT_SHIELD-O_HEALTH+O_CURRENT_CLAMPED];
        if(clamped==1&&isfinite(shield_bound)&&shield_bound>0&&shield_bound<=10000&&shield<=shield_bound+0.001f)
            out->max_shield=shield_bound;
    }
}
static int pawn_entity(EraSnapshotReader*r,uint64_t state,uint64_t pawn,EraEntity*out){
    memset(out,0,sizeof(*out));
    if(!object_is(r,state,K_STATE)||!object_is(r,pawn,K_PAWN))return 0;
    uint64_t actual_state=0,root=0;unsigned char dying=0,downed=0,team=0;EraTransform world;
    if(!read_pointer(r,pawn,O_PAWN_STATE,&actual_state)||actual_state!=state||!read_pointer(r,pawn,O_ROOT,&root)||
       !read_at(r,state+O_TEAM,&team,1)||!read_at(r,pawn+O_DYING,&dying,1)||!read_at(r,pawn+O_DOWNED,&downed,1)||
       !scene_transform(r,root,&world))return 0;
    out->id=pawn;out->team=team;out->alive=(dying&8)==0;out->downed=(downed&1)!=0;out->root=world.translation;
    read_vitals(r,pawn,out);
    player_name(r,state,out->name,sizeof(out->name));read_bones(r,pawn,out);
    return 1;
}
EraSnapshotReader*era_snapshot_create(EraReadMemory read,void*context,uint64_t module_base){
    if(!read||!pointer_ok(module_base))return NULL;
    EraSnapshotReader*r=(EraSnapshotReader*)calloc(1,sizeof(*r));if(!r)return NULL;
    r->read=read;r->context=context;r->base=module_base;return r;
}
void era_snapshot_destroy(EraSnapshotReader*reader){free(reader);}
const EraNameDiagnostic*era_snapshot_name_diagnostic(const EraSnapshotReader*reader){
    return reader?&reader->name_diagnostic:NULL;
}
const char*era_name_stage_text(EraNameStage stage){
    switch(stage){
    case ERA_NAME_STAGE_IDLE:return "idle";
    case ERA_NAME_STAGE_APPEND:return "append";
    case ERA_NAME_STAGE_GETTER:return "getter";
    case ERA_NAME_STAGE_CANDIDATE:return "candidate";
    case ERA_NAME_STAGE_SENTINELS:return "sentinels";
    case ERA_NAME_STAGE_STABILITY:return "stability";
    case ERA_NAME_STAGE_READY:return "ready";
    default:return "unknown";
    }
}
const char*era_name_reason_text(EraNameReason reason){
    switch(reason){
    case ERA_NAME_REASON_NONE:return "none";
    case ERA_NAME_REASON_READ_FAILED:return "read-failed";
    case ERA_NAME_REASON_PREFIX_MISMATCH:return "prefix-mismatch";
    case ERA_NAME_REASON_GETTER_BOUNDS:return "getter-bounds";
    case ERA_NAME_REASON_NO_RIP_CANDIDATE:return "no-rip-candidate";
    case ERA_NAME_REASON_INVALID_POINTER:return "invalid-pointer";
    case ERA_NAME_REASON_SENTINEL_MISMATCH:return "sentinel-mismatch";
    case ERA_NAME_REASON_AMBIGUOUS:return "ambiguous";
    case ERA_NAME_REASON_UNSTABLE:return "unstable";
    default:return "unknown";
    }
}
EraStatus era_snapshot_step(EraSnapshotReader*r,EraFrame*frame){
    if(!frame)return ERA_READ_FAILED;
    EraFrame next={0};next.pid=frame->pid;next.windows_error=frame->windows_error;next.captured_ms=frame->captured_ms;
    next.sequence=frame->sequence;next.game_window=frame->game_window;next.status=ERA_READ_FAILED;
    next.module_base=frame->module_base;next.attach_flags=frame->attach_flags;
    if(!r){*frame=next;return next.status;}r->steps++;r->mesh_budget=1;
    if(r->name_ready&&!name_pool_current(r)){
        r->name_ready=0;r->names_retry=r->steps;forget_engine(r);
        memset(r->names,0,sizeof(r->names));
    }
    if(!r->name_ready){
        if((int32_t)(r->steps-r->names_retry)>=0){
            r->names_retry=r->steps+64U;
            (void)find_name_pool(r);
        }
        if(!r->name_ready){next.status=ERA_FINDING_NAMES;*frame=next;return next.status;}
    }
    next.names_ready=1;
    /* Cached pointers must be revalidated: UObject storage can be replaced
       while the same game process and module remain alive. */
    if(r->engine&&!object_is(r,r->engine,K_ENGINE)){
        forget_engine(r);
    }
    if(!r->engine){int found=engine_step(r);if(found!=1){
        next.status=found<0?ERA_READ_FAILED:found==2?ERA_WAITING_WORLD:ERA_FINDING_ENGINE;
        *frame=next;return next.status;
    }}
    uint64_t viewport=0,world=0,instance=0,local_player=0,controller=0,pawn=0,camera=0,state=0,game_state=0;
    RemoteArray locals,players;
    if(!read_pointer(r,r->engine,O_VIEWPORT,&viewport)||!pointer_ok(viewport)||!read_pointer(r,viewport,O_VIEWPORT_WORLD,&world)||!pointer_ok(world)||
       !read_pointer(r,world,O_WORLD_INSTANCE,&instance)||!pointer_ok(instance)){
        /* Retry bounded discovery instead of pinning a retired Engine forever. */
        forget_engine(r);
        next.status=ERA_WAITING_WORLD;*frame=next;return next.status;
    }
    /* Travel can replace a valid World/GameInstance without an intervening
       null pointer or a new Engine. Reused addresses must not retain the
       previous generation's class kinds or bone-name mappings. */
    if(r->world!=world||r->instance!=instance){
        clear_derived_caches(r);r->world=world;r->instance=instance;
    }
    if(!read_at(r,instance+O_LOCAL_PLAYERS,&locals,sizeof(locals))||!array_ok(locals,4)||locals.count!=1||
       !read_at(r,locals.data,&local_player,8)||!read_pointer(r,local_player,O_LOCAL_CONTROLLER,&controller)||
       !read_pointer(r,controller,O_LOCAL_PAWN,&pawn)||!pointer_ok(pawn)||!read_pointer(r,pawn,O_PAWN_STATE,&state)||!pointer_ok(state)){
        next.status=ERA_WAITING_MATCH;*frame=next;return next.status;
    }
    if(!read_pointer(r,controller,O_CAMERA_MANAGER,&camera)||!pointer_ok(camera)||!read_at(r,camera+O_CAMERA_POV,&next.camera,sizeof(next.camera))||
       !era_camera_valid(&next.camera)||!read_pointer(r,world,O_WORLD_GAMESTATE,&game_state)||!pointer_ok(game_state)||
       !read_at(r,game_state+O_PLAYER_ARRAY,&players,sizeof(players))||!array_ok(players,MAX_PLAYERS)||players.count<1){
        *frame=next;return next.status;
    }
    unsigned char projection=255,camera_flags=0;float off_center[2];
    if(!read_at(r,camera+O_CAMERA_POV+O_POV_PROJECTION,&projection,1)||projection!=0||
       !read_at(r,camera+O_CAMERA_POV+O_POV_FLAGS,&camera_flags,1)||(camera_flags&1)||
       !read_at(r,camera+O_CAMERA_POV+O_POV_OFF_CENTER,off_center,sizeof(off_center))||
       !isfinite(off_center[0])||!isfinite(off_center[1])||off_center[0]!=0.0f||off_center[1]!=0.0f){
        *frame=next;return next.status;
    }
    uint64_t player_states[MAX_PLAYERS];if(!read_at(r,players.data,player_states,(size_t)players.count*8)){*frame=next;return next.status;}
    int local_found=0;for(int i=0;i<players.count;i++)if(player_states[i]==state)local_found=1;
    EraEntity local;
    if(!local_found||!pawn_entity(r,state,pawn,&local)){*frame=next;return next.status;}
    next.local_pawn=pawn;next.local_team=local.team;next.local_alive=local.alive&&!local.downed&&local.health_valid&&local.health>0;
    for(int i=0;i<players.count&&next.count<ERA_MAX_ENTITIES;i++){
        uint64_t other=0;if(player_states[i]==state||!read_pointer(r,player_states[i],O_STATE_PAWN,&other)||!pointer_ok(other)||other==pawn)continue;
        int duplicate=0;for(int j=0;j<next.count;j++)if(next.entities[j].id==other)duplicate=1;if(duplicate)continue;
        EraEntity entity;if(pawn_entity(r,player_states[i],other,&entity))next.entities[next.count++]=entity;
    }
    /* Do not publish mixed travel frames whose local controller changed while
       the remote reads were in progress. */
    uint64_t after=0,after_world=0;
    if(!read_pointer(r,controller,O_LOCAL_PAWN,&after)||after!=pawn||
       !read_pointer(r,viewport,O_VIEWPORT_WORLD,&after_world)||after_world!=world){
        next.count=0;next.local_alive=0;*frame=next;return next.status;
    }
    next.status=ERA_READY;*frame=next;return next.status;
}
