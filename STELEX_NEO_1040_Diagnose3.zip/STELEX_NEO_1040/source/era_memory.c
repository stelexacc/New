#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#include <windows.h>
#include <tlhelp32.h>
#include <winver.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "era_memory.h"
#include "era_snapshot.h"
#include "era_identity.h"

struct EraReader {
    HANDLE process;
    DWORD pid,last_error;
    uint64_t module,next_attempt,sequence,verify_after,window_after;
    HWND window;
    int build_checked,build_verified,decoding;
    unsigned name_attempt;
    DWORD name_attempt_error;
    uint64_t name_failed_read_address,name_failed_read_bytes;
    EraStatus blocked;
    EraSnapshotReader*decoder;
};
static const wchar_t process_name[]=L"FortniteClient-Win64-Shipping.exe";

static void reset_name_error(EraReader*r){
    r->name_attempt=0;r->name_attempt_error=0;
    r->name_failed_read_address=0;r->name_failed_read_bytes=0;
}
static void detach(EraReader*r){
    era_snapshot_destroy(r->decoder);r->decoder=NULL;
    if(r->process)CloseHandle(r->process);
    r->process=NULL;r->pid=0;r->module=0;r->blocked=ERA_NOT_RUNNING;r->last_error=0;r->build_checked=0;r->build_verified=0;
    r->next_attempt=0;r->verify_after=0;r->window_after=0;r->window=NULL;
    reset_name_error(r);
}
static int read_failure(EraReader*r,uint64_t address,size_t bytes,DWORD error){
    r->last_error=error;
    const EraNameDiagnostic*d=r->decoding?era_snapshot_name_diagnostic(r->decoder):NULL;
    if(d&&d->stage!=ERA_NAME_STAGE_READY){
        r->name_attempt_error=error;r->name_failed_read_address=address;r->name_failed_read_bytes=bytes;
    }
    return 0;
}
static int read_memory(void*context,uint64_t address,void*output,size_t bytes){
    EraReader*r=context;SIZE_T received=0;
    if(!r)return 0;
    const EraNameDiagnostic*d=r->decoding?era_snapshot_name_diagnostic(r->decoder):NULL;
    if(d&&d->attempt!=r->name_attempt){
        /* The first read of a new discovery attempt separates it from an
           earlier cached-name check in the same snapshot poll. */
        r->name_attempt=d->attempt;r->name_attempt_error=0;
        r->name_failed_read_address=0;r->name_failed_read_bytes=0;
    }
    if(!r->process||!output||!bytes||bytes>1024U*1024U)return read_failure(r,address,bytes,ERROR_INVALID_PARAMETER);
    if(address<0x10000ULL||address>0x00007FFFFFFFFFFFULL||bytes>0x0000800000000000ULL-address)return read_failure(r,address,bytes,ERROR_INVALID_ADDRESS);
    BOOL complete=ReadProcessMemory(r->process,(const void*)(uintptr_t)address,output,bytes,&received);
    if(!complete||received!=bytes){
        DWORD error=complete?ERROR_PARTIAL_COPY:GetLastError();
        return read_failure(r,address,bytes,error?error:ERROR_PARTIAL_COPY);
    }
    return 1;
}
static DWORD find_process(void){
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(snapshot==INVALID_HANDLE_VALUE)return 0;
    PROCESSENTRY32W entry={0};entry.dwSize=sizeof(entry);DWORD result=0;
    int count=0;
    if(Process32FirstW(snapshot,&entry))do{
        if(_wcsicmp(entry.szExeFile,process_name)==0){result=entry.th32ProcessID;break;}
    }while(++count<32768&&Process32NextW(snapshot,&entry));
    CloseHandle(snapshot);return result;
}
static uint64_t find_module(DWORD pid,DWORD*error){
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);
    if(snapshot==INVALID_HANDLE_VALUE){*error=GetLastError();return 0;}
    MODULEENTRY32W entry={0};entry.dwSize=sizeof(entry);uint64_t result=0;int count=0;
    if(Module32FirstW(snapshot,&entry))do{
        if(_wcsicmp(entry.szModule,process_name)==0&&entry.modBaseSize>0x064A00B0U){
            result=(uint64_t)(uintptr_t)entry.modBaseAddr;break;
        }
    }while(++count<4096&&Module32NextW(snapshot,&entry));
    *error=result?0:ERROR_MOD_NOT_FOUND;CloseHandle(snapshot);return result;
}
typedef struct {DWORD pid;HWND window;unsigned count;} WindowSearch;
static BOOL CALLBACK find_window(HWND hwnd,LPARAM parameter){
    WindowSearch*search=(WindowSearch*)parameter;DWORD pid=0;
    if(++search->count>32768)return FALSE;
    GetWindowThreadProcessId(hwnd,&pid);
    if(pid==search->pid&&IsWindowVisible(hwnd)&&GetWindow(hwnd,GW_OWNER)==NULL){
        RECT rect;if(GetClientRect(hwnd,&rect)&&rect.right>100&&rect.bottom>100){search->window=hwnd;return FALSE;}
    }
    return TRUE;
}
static HWND game_window(DWORD pid){WindowSearch search={pid,NULL,0};EnumWindows(find_window,(LPARAM)&search);return search.window;}

static int file_build_marker(const wchar_t*path){
    HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return 0;
    LARGE_INTEGER size;
    if(!GetFileSizeEx(file,&size)||size.QuadPart<1024||size.QuadPart>512LL*1024*1024){CloseHandle(file);return 0;}
    HANDLE mapping=CreateFileMappingW(file,NULL,PAGE_READONLY,0,0,NULL);CloseHandle(file);
    if(!mapping)return 0;
    const unsigned char*data=MapViewOfFile(mapping,FILE_MAP_READ,0,0,0);int matched=0;
    if(data){
        size_t scan_size=(size_t)size.QuadPart;if(scan_size>128U*1024U*1024U)scan_size=128U*1024U*1024U;
        matched=era_identity_image(data,scan_size);
        UnmapViewOfFile(data);
    }
    CloseHandle(mapping);return matched;
}
/* A Toolhelp module entry is not proof that VM_READ succeeded. Read the actual
   mapped DOS/NT headers before publishing ERA_ATTACH_MODULE on every poll. */
static int module_header(EraReader*r){
    IMAGE_DOS_HEADER dos;IMAGE_NT_HEADERS64 nt;
    if(!read_memory(r,r->module,&dos,sizeof(dos)))return 0;
    if(dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<64||dos.e_lfanew>1024*1024){r->last_error=ERROR_BAD_EXE_FORMAT;return 0;}
    if(!read_memory(r,r->module+(unsigned)dos.e_lfanew,&nt,sizeof(nt)))return 0;
    if(nt.Signature!=IMAGE_NT_SIGNATURE||nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||
       nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||nt.FileHeader.NumberOfSections==0||
       nt.FileHeader.NumberOfSections>96||nt.FileHeader.SizeOfOptionalHeader<sizeof(IMAGE_OPTIONAL_HEADER64)||
       nt.FileHeader.SizeOfOptionalHeader>4096||nt.OptionalHeader.SizeOfImage<=0x064A00B0U||
       nt.OptionalHeader.SizeOfHeaders>nt.OptionalHeader.SizeOfImage||
       nt.OptionalHeader.SizeOfHeaders<(unsigned)dos.e_lfanew+4U+sizeof(IMAGE_FILE_HEADER)+nt.FileHeader.SizeOfOptionalHeader){
        r->last_error=ERROR_BAD_EXE_FORMAT;return 0;
    }
    return 1;
}
/* FEngineVersion is additionally accepted only when all four numeric fields
   and the pointed-to release branch agree. No gameplay address is used here. */
static int remote_build_marker(EraReader*r,uint64_t base){
    IMAGE_DOS_HEADER dos;IMAGE_NT_HEADERS64 nt;
    if(!base||!read_memory(r,base,&dos,sizeof(dos))||dos.e_magic!=IMAGE_DOS_SIGNATURE||
       dos.e_lfanew<64||dos.e_lfanew>1024*1024||!read_memory(r,base+(unsigned)dos.e_lfanew,&nt,sizeof(nt))||
       nt.Signature!=IMAGE_NT_SIGNATURE||nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||
       nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||nt.FileHeader.NumberOfSections==0||nt.FileHeader.NumberOfSections>96||
       nt.FileHeader.SizeOfOptionalHeader<sizeof(IMAGE_OPTIONAL_HEADER64)||nt.FileHeader.SizeOfOptionalHeader>4096)return 0;
    uint64_t sections=base+(unsigned)dos.e_lfanew+4+sizeof(IMAGE_FILE_HEADER)+nt.FileHeader.SizeOfOptionalHeader;
    unsigned char*block=malloc(262144+32);if(!block)return 0;int matched=0;
    size_t scanned=0;
    for(unsigned index=0;index<nt.FileHeader.NumberOfSections&&!matched&&scanned<64U*1024U*1024U;index++){
        IMAGE_SECTION_HEADER section;
        if(!read_memory(r,sections+index*sizeof(section),&section,sizeof(section)))break;
        DWORD size=section.Misc.VirtualSize;
        if(!(section.Characteristics&IMAGE_SCN_MEM_READ)||(section.Characteristics&IMAGE_SCN_MEM_EXECUTE)||
           size<32||size>32U*1024U*1024U||section.VirtualAddress>nt.OptionalHeader.SizeOfImage||
           size>nt.OptionalHeader.SizeOfImage-section.VirtualAddress)continue;
        for(DWORD offset=0;offset<size&&!matched&&scanned<64U*1024U*1024U;offset+=262144){
            DWORD count=size-offset;if(count>262144+32)count=262144+32;
            if(count<32)break;
            scanned+=count;
            if(!read_memory(r,base+section.VirtualAddress+offset,block,count))continue;
            DWORD candidates=count-31;if(candidates>262144)candidates=262144;
            for(DWORD i=0;i<candidates;i+=4){
                WORD numbers[3];DWORD changelist;memcpy(numbers,block+i,sizeof(numbers));memcpy(&changelist,block+i+8,4);
                if(numbers[0]!=4||numbers[1]!=23||numbers[2]!=0||(changelist&0x7FFFFFFFU)!=9380822U)continue;
                uint64_t branch=0;int length=0,capacity=0;
                memcpy(&branch,block+i+16,8);memcpy(&length,block+i+24,4);memcpy(&capacity,block+i+28,4);
                if(length<2||length>80||capacity<length||capacity>4096)continue;
                wchar_t text[80];
                if(read_memory(r,branch,text,(SIZE_T)length*2)&&
                   era_identity_engine(numbers[0],numbers[1],numbers[2],changelist,(const uint16_t*)text,(size_t)length)){matched=1;break;}
            }
        }
    }
    free(block);return matched;
}
static int verify_build(EraReader*r){
    wchar_t path[32768];DWORD length=(DWORD)(sizeof(path)/sizeof(path[0]));
    int path_ok=QueryFullProcessImageNameW(r->process,0,path,&length)&&length>0&&length<32768;
    if(path_ok)path[length]=0;
    DWORD ignored=0,bytes=path_ok?GetFileVersionInfoSizeW(path,&ignored):0;int matched=0;
    if(bytes&&bytes<=4U*1024U*1024U){
        void*data=malloc(bytes);
        if(data&&GetFileVersionInfoW(path,0,bytes,data)){
            struct Translation {WORD language,codepage;}*translations=NULL;
            UINT translation_bytes=0;
            if(VerQueryValueW(data,L"\\VarFileInfo\\Translation",(LPVOID*)&translations,&translation_bytes)){
                unsigned count=translation_bytes/(unsigned)sizeof(*translations);if(count>32)count=32;
                const wchar_t*keys[]={L"ProductVersion",L"FileVersion"};
                for(unsigned i=0;i<count&&!matched;i++)for(unsigned k=0;k<2&&!matched;k++){
                    wchar_t query[128],*value=NULL;UINT chars=0;
                    _snwprintf(query,128,L"\\StringFileInfo\\%04x%04x\\%ls",translations[i].language,translations[i].codepage,keys[k]);
                    query[127]=0;
                    if(VerQueryValueW(data,query,(LPVOID*)&value,&chars)&&value&&chars>0&&chars<4096&&value[chars-1]==0)
                        matched=era_identity_text16((const uint16_t*)value,chars);
                }
            }
        }
        free(data);
    }
    return matched||remote_build_marker(r,r->module)||(path_ok&&file_build_marker(path));
}
EraReader*era_reader_create(void){return calloc(1,sizeof(EraReader));}
void era_reader_destroy(EraReader*r){if(r){detach(r);free(r);}}
void era_reader_poll(EraReader*r,EraFrame*frame){
    if(!frame)return;
    memset(frame,0,sizeof(*frame));frame->status=ERA_NOT_RUNNING;frame->captured_ms=GetTickCount64();
    if(!r){frame->status=ERA_READ_FAILED;frame->windows_error=ERROR_OUTOFMEMORY;return;}
    frame->sequence=++r->sequence;
    if(r->process){
        DWORD exit_code=0;
        if(!GetExitCodeProcess(r->process,&exit_code)||exit_code!=STILL_ACTIVE)detach(r);
    }
    if(!r->process){
        if(frame->captured_ms<r->next_attempt){frame->status=r->blocked;frame->pid=r->pid;frame->windows_error=r->last_error;return;}
        r->next_attempt=frame->captured_ms+2000;
        r->pid=0;r->blocked=ERA_NOT_RUNNING;r->last_error=0;
        DWORD pid=find_process();if(!pid)return;
        frame->pid=pid;
        r->process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,pid);
        if(!r->process){r->last_error=GetLastError();r->blocked=ERA_OPEN_DENIED;r->pid=pid;
            frame->windows_error=r->last_error;frame->status=r->blocked;return;}
        r->pid=pid;r->next_attempt=0;
    }
    frame->pid=r->pid;frame->attach_flags=ERA_ATTACH_PROCESS;
    if(frame->captured_ms>=r->window_after||!IsWindow(r->window)){
        r->window=game_window(r->pid);r->window_after=frame->captured_ms+1000;
    }
    frame->game_window=(uintptr_t)r->window;
    if(!r->module){
        if(frame->captured_ms<r->next_attempt){frame->status=r->last_error?ERA_READ_FAILED:ERA_WAITING_WORLD;frame->windows_error=r->last_error;return;}
        r->next_attempt=frame->captured_ms+1000;r->module=find_module(r->pid,&r->last_error);
        if(!r->module){frame->status=ERA_READ_FAILED;frame->windows_error=r->last_error;return;}
    }
    frame->module_base=r->module;
    if(!module_header(r)){
        DWORD error=r->last_error;
        era_snapshot_destroy(r->decoder);r->decoder=NULL;r->module=0;r->build_checked=0;r->build_verified=0;
        r->blocked=ERA_READ_FAILED;r->verify_after=0;r->next_attempt=frame->captured_ms+1000;r->last_error=error;
        frame->status=ERA_READ_FAILED;frame->windows_error=error;return;
    }
    frame->attach_flags|=ERA_ATTACH_MODULE;
    if(!r->build_verified){
        if(frame->captured_ms<r->verify_after){frame->status=ERA_BUILD_UNVERIFIED;frame->windows_error=r->last_error;return;}
        r->build_checked++;r->last_error=0;
        if(verify_build(r)){r->build_verified=1;r->blocked=ERA_NOT_RUNNING;r->last_error=0;}
        else {r->blocked=ERA_BUILD_UNVERIFIED;r->verify_after=frame->captured_ms+(r->build_checked<4?3000:60000);}
        if(!r->build_verified){frame->status=ERA_BUILD_UNVERIFIED;frame->windows_error=r->last_error;return;}
    }
    frame->attach_flags|=ERA_ATTACH_BUILD;
    if(!r->decoder){reset_name_error(r);r->decoder=era_snapshot_create(read_memory,r,r->module);
        if(!r->decoder){frame->status=ERA_READ_FAILED;frame->windows_error=ERROR_OUTOFMEMORY;return;}}
    /* Discovery/build verification can be slow. Date the game snapshot at its
       own read start; keep actual decoder latency visible to freshness gates. */
    frame->captured_ms=GetTickCount64();
    r->last_error=0;r->decoding=1;
    frame->status=era_snapshot_step(r->decoder,frame);r->decoding=0;
    const EraNameDiagnostic*diagnostic=era_snapshot_name_diagnostic(r->decoder);
    if(diagnostic){
        frame->name_diagnostic=*diagnostic;
        if(diagnostic->attempt!=r->name_attempt){
            r->name_attempt=diagnostic->attempt;
            r->name_attempt_error=0;
            r->name_failed_read_address=0;r->name_failed_read_bytes=0;
        }
        if(diagnostic->stage==ERA_NAME_STAGE_READY){
            r->name_attempt_error=0;r->name_failed_read_address=0;r->name_failed_read_bytes=0;
        }
    }
    /* Decoders replace game fields. Connection evidence belongs to this reader. */
    frame->module_base=r->module;frame->attach_flags=ERA_ATTACH_COMPLETE;
    if(frame->status==ERA_FINDING_NAMES){
        /* Idle retry polls do not perform name reads. Retain the last actual
           attempt's evidence; a new readable mismatch replaces old errors. */
        frame->windows_error=r->name_attempt_error;
        frame->name_read_error=r->name_attempt_error;
        frame->name_failed_read_address=r->name_failed_read_address;
        frame->name_failed_read_bytes=r->name_failed_read_bytes;
    }else if(frame->status!=ERA_READY)frame->windows_error=r->last_error;
}
const wchar_t*era_status_text(EraStatus status){
    switch(status){
    case ERA_OPEN_DENIED:return L"Speicherzugriff verweigert";
    case ERA_BUILD_UNVERIFIED:return L"Client-Build 9380822 nicht bestaetigt";
    case ERA_FINDING_ENGINE:return L"Suche die verifizierte Engine-Instanz";
    case ERA_FINDING_NAMES:return L"Namenspool noch nicht bestaetigt: Clientcode, Zugriff oder Eintraege passen nicht";
    case ERA_WAITING_WORLD:return L"Warte auf eine gueltige Spielwelt";
    case ERA_WAITING_MATCH:return L"Warte auf lokale Match-Daten";
    case ERA_READ_FAILED:return L"Spielerdaten nicht vollstaendig lesbar";
    case ERA_READY:return L"Spielerdaten gelesen - Live-Wirkung nicht bestaetigt";
    default:return L"Fortnite-Client nicht gefunden";
    }
}
