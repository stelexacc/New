"""Build/run native probe-launch and menu-button checks under configured Wine."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig', required=True)
    parser.add_argument('--wine', required=True)
    parser.add_argument('--suite', action='append', choices=['probe_launcher', 'report_button', 'gdi_resources', 'fortnite_window', 'reader_recovery'])
    args = parser.parse_args()
    suites = args.suite or ['probe_launcher', 'report_button']
    environment = os.environ.copy()
    environment.setdefault('ZIG_GLOBAL_CACHE_DIR', str(ROOT / 'build/zig-global-cache'))
    environment.setdefault('ZIG_LOCAL_CACHE_DIR', str(ROOT / 'build/zig-local-cache'))
    rows = []
    with tempfile.TemporaryDirectory(prefix='neo-native-tests-') as temporary:
        folder = Path(temporary)
        for suite in suites:
            test = ROOT / 'tests' / ('test_' + suite + '_windows.c')
            if not test.exists():
                raise FileNotFoundError(test)
            output = folder / (suite + '.exe')
            command = [args.zig, 'cc', '-target', 'x86_64-windows-gnu', '-std=c11', '-O2',
                       '-Wall', '-Wextra', '-Werror', '-municode', '-Wl,--subsystem,console',
                       '-I' + str(ROOT / 'source'), str(test)]
            if suite != 'probe_launcher':
                command += [str(ROOT / 'source' / name) for name in
                            ['era_memory.c', 'era_snapshot.c', 'era_core.c', 'era_identity.c',
                             'era_startup.c', 'era_probe_launcher.c']
                            if suite != 'reader_recovery' or name != 'era_memory.c']
            command += ['-luser32', '-lgdi32', '-lshell32', '-lversion', '-lwinmm', '-ladvapi32',
                        '-o', str(output)]
            compiled = subprocess.run(command, cwd=ROOT, env=environment, text=True,
                                      capture_output=True, timeout=240)
            rows.append(dict(name=suite + ' compile', passed=compiled.returncode == 0,
                             exit_code=compiled.returncode, stdout=compiled.stdout,
                             stderr=compiled.stderr))
            if compiled.returncode:
                print(compiled.stderr, flush=True)
                continue
            log = folder / (suite + '.log')
            with log.open('wb') as stream:
                result = subprocess.run([args.wine, str(output)], cwd=ROOT, env=environment,
                                        stdout=stream, stderr=stream, timeout=120)
            text = log.read_text(errors='replace')
            match = re.search(r'NEO [^\r\n:]+: (\d+) assertions, (\d+) failures', text)
            passed = bool(match and int(match[1]) > 0 and int(match[2]) == 0 and result.returncode == 0)
            row = dict(name=suite + ' execute', passed=passed, exit_code=result.returncode,
                       assertions=int(match[1]) if match else None,
                       failures=int(match[2]) if match else None, output=text,
                       test_sha256=hashlib.sha256(test.read_bytes()).hexdigest())
            if suite == 'gdi_resources':
                measurements = re.search(r'redraws=(\d+) resource_api=(\d+) baseline=(\d+) warm=(\d+) maximum=(\d+) cleaned=(\d+)', text)
                if measurements:
                    row.update(redraws=int(measurements[1]),
                               gdi_handle_measurement_available=measurements[2] == '1',
                               gdi_counts=dict(zip(['baseline', 'warm', 'maximum', 'cleaned'],
                                                  map(int, measurements.groups()[2:]))))
            rows.append(row)
            print(('PASS ' if passed else 'FAIL ') + suite, flush=True)
            print(match[0] if match else text[-1000:], flush=True)
    report = dict(passed=len(rows) == len(suites) * 2 and all(row['passed'] for row in rows),
                  wine_execution=True, actual_windows_tested=False, live_neo_tested=False,
                  source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in (ROOT / 'source').iterdir() if p.suffix in {'.c', '.h'}},
                  checks=rows)
    (ROOT / 'research/ADDITIONAL_WINDOWS_TESTS.json').write_text(json.dumps(report, indent=2) + '\n')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
