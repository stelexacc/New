"""Validate the prepared package on native Windows; never start or attach to a game.

The workflow pins the package and tooling hashes. Tests compile the supplied
sources, execute ordinary Win32/GDI checks, and smoke-test both the shipped
assistant-built EXE and the EXE rebuilt on Windows. Mouse input is mocked by
the overlay suite. Real Neo memory, camera, poses and game input remain untested.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--package-sha256', required=True)
    parser.add_argument('--package-root', type=Path,
                        default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--zig', type=Path, required=True)
    args = parser.parse_args()
    if os.name != 'nt':
        parser.error('This runner requires native Windows; Wine is not selected here.')
    root = args.package_root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    build = root / 'build/native-ci'
    build.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env['ZIG_GLOBAL_CACHE_DIR'] = str(root / 'build/zig-global-cache')
    env['ZIG_LOCAL_CACHE_DIR'] = str(root / 'build/zig-local-cache')
    report = dict(passed=False, native_windows_tested=True, live_neo_tested=False,
                  real_game_memory_tested=False, real_game_input_tested=False,
                  platform=platform.platform(), architecture=platform.machine(),
                  python=sys.version.split()[0], package_sha256=digest(args.package),
                  workflow_commit=os.environ.get('GITHUB_SHA'), checks=[])
    rows = report['checks']

    def check(name: str, passed: bool, **details) -> bool:
        rows.append(dict(name=name, passed=bool(passed), **details))
        print(('PASS ' if passed else 'FAIL ') + name, flush=True)
        return bool(passed)

    def run(name: str, command: list[str], timeout: int = 240) -> tuple[bool, str]:
        path = output / (re.sub(r'[^A-Za-z0-9_.-]', '_', name) + '.log')
        try:
            with path.open('wb') as stream:
                result = subprocess.run(command, cwd=root, env=env,
                                        stdout=stream, stderr=stream, timeout=timeout)
            text = path.read_text(errors='replace')
            passed = result.returncode == 0
            check(name, passed, command=command, exit_code=result.returncode,
                  log=path.name)
            if text.strip():
                print(text[-12000:].rstrip(), flush=True)
            return passed, text
        except (OSError, subprocess.TimeoutExpired) as error:
            check(name, False, command=command, error=str(error), log=path.name)
            return False, ''

    def compile_test(suite: str, sources: list[Path], unicode: bool,
                     extra_flags: list[str] | None = None) -> Path | None:
        executable = build / (suite + '.exe')
        flags = ['-target', 'x86_64-windows-gnu', '-std=c11', '-O2',
                 '-Wall', '-Wextra', '-Werror']
        flags += extra_flags or []
        if unicode:
            flags += ['-municode', '-Wl,--subsystem,console']
        command = [str(args.zig), 'cc', *flags,
                   '-I' + str(root / 'source'), *map(str, sources)]
        command += ['-luser32', '-lgdi32', '-lshell32', '-lversion',
                    '-lwinmm', '-ladvapi32']
        command += ['-o', str(executable)]
        passed, _ = run('compile_' + suite, command)
        return executable if passed else None

    def execute_test(suite: str, executable: Path) -> None:
        passed, text = run('execute_' + suite, [str(executable)], timeout=60)
        match = re.search(r'(\d+) assertions(?:,\s*(\d+) failures)?', text)
        check(suite + '_assertions_completed',
              passed and match is not None and int(match[1]) > 0 and
              (match[2] is None or int(match[2]) == 0),
              assertions=int(match[1]) if match else None,
              failures=int(match[2]) if match and match[2] else None)
        if suite == 'gdi_resources':
            resources = re.search(r'redraws=(\d+) resource_api=(\d+) baseline=(\d+) '
                                  r'warm=(\d+) maximum=(\d+) cleaned=(\d+)', text)
            check('native_gdi_resource_counts_available',
                  passed and resources is not None and int(resources[1]) == 512 and
                  int(resources[2]) == 1,
                  redraws=int(resources[1]) if resources else None,
                  resource_api=bool(int(resources[2])) if resources else False,
                  baseline=int(resources[3]) if resources else None,
                  warm=int(resources[4]) if resources else None,
                  maximum=int(resources[5]) if resources else None,
                  cleaned=int(resources[6]) if resources else None)

    def product_smoke(name: str, product: Path, helper: Path, protocol: int) -> None:
        runtime = Path(os.environ['LOCALAPPDATA']) / 'STELEX_NEO_1040/runtime.log'
        start_size = runtime.stat().st_size if runtime.exists() else 0
        initial_hash = digest(product)
        process = None
        counter = 0

        def probe(mode: str = 'probe') -> dict:
            nonlocal counter
            counter += 1
            evidence = output / (name + '_probe_' + str(counter) + '.json')
            evidence.unlink(missing_ok=True)
            command = [str(helper), mode, str(evidence)]
            path = output / (name + '_probe_process.log')
            with path.open('ab') as stream:
                result = subprocess.run(command, cwd=root, env=env,
                                        stdout=stream, stderr=stream, timeout=15)
            if not evidence.exists():
                raise RuntimeError('Window probe returned no JSON: ' + str(result.returncode))
            return json.loads(evidence.read_text())

        try:
            initial = probe()
            if not check(name + '_no_existing_product', not initial.get('menu_exists'),
                         probe=initial):
                return
            process_log = output / (name + '_process.log')
            with process_log.open('wb') as stream:
                process = subprocess.Popen([str(product)], cwd=product.parent, env=env,
                                           stdout=stream, stderr=stream,
                                           creationflags=subprocess.CREATE_NEW_CONSOLE)
                deadline = time.monotonic() + 45
                state = {}
                while time.monotonic() < deadline:
                    state = probe()
                    if state.get('menu_exists') and state.get('console_exists'):
                        break
                    if process.poll() is not None:
                        break
                    time.sleep(0.1)
                check(name + '_console_exists', state.get('console_exists'), probe=state)
                check(name + '_console_visible', state.get('console_visible'), probe=state)
                check(name + '_menu_created_hidden',
                      state.get('menu_exists') and not state.get('menu_visible'), probe=state)
                check(name + '_overlay_hidden_without_game',
                      state.get('menu_exists') and not state.get('overlay_visible'), probe=state)
                check(name + '_protocol_matches', state.get('protocol') == protocol,
                      expected=protocol, probe=state)
                blocked = probe('show')
                check(name + '_show_blocked_without_game',
                      blocked.get('menu_exists') and not blocked.get('menu_visible'),
                      probe=blocked)
                time.sleep(0.4)
                probe('close')
                process.wait(timeout=15)
                check(name + '_clean_exit', process.returncode == 0,
                      exit_code=process.returncode)
            text = runtime.read_bytes()[start_size:].decode('utf-8', errors='replace')
            (output / (name + '_runtime.log')).write_text(text, encoding='utf-8')
            for suffix, marker in [('heartbeat', '[STATE NEO]'),
                                   ('blocked_log', '[MENU] Gesperrt:'),
                                   ('shutdown_request', '[EXIT] Beenden ueber Konsole angefordert.'),
                                   ('worker_cleanup', '[EXIT] Worker und Fenster beendet.')]:
                check(name + '_' + suffix, marker in text)
            check(name + '_product_unchanged', digest(product) == initial_hash,
                  artifact_sha256=initial_hash)
        except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
            check(name + '_smoke_completed', False, error=str(error))
        finally:
            if process is not None and process.poll() is None:
                try:
                    probe('close')
                    process.wait(timeout=5)
                except Exception:
                    process.terminate()
                    process.wait(timeout=5)

    try:
        if not check('package_hash_matches',
                     report['package_sha256'] == args.package_sha256.lower()):
            raise ValueError('Prepared ZIP hash mismatch')
        manifest = json.loads((root / 'SHA256.json').read_text())['files']
        mismatches = []
        for relative, expected in manifest.items():
            path = (root / relative).resolve()
            if not path.is_relative_to(root) or not path.is_file() or digest(path) != expected:
                mismatches.append(relative)
        if not check('package_manifest_matches', not mismatches,
                     files=len(manifest), mismatches=mismatches):
            raise ValueError('Extracted package file manifest mismatch')
        source_hashes = {p.name: digest(p) for p in (root / 'source').iterdir()
                         if p.suffix in {'.c', '.h', '.rc', '.manifest', '.ico'}}
        report['source_hashes'] = source_hashes
        shipped = build / 'shipped/STELEX_NEO_1040.exe'
        shipped.parent.mkdir(exist_ok=True)
        shutil.copyfile(root / 'STELEX_NEO_1040.exe', shipped)
        report['shipped_artifact_sha256'] = digest(shipped)
        run('zig_version', [str(args.zig), 'version'], timeout=30)
        rebuilt_ok, _ = run('rebuild_product_on_windows',
                            [sys.executable, str(root / 'source/build.py'),
                             '--zig', str(args.zig)])
        rebuilt = root / 'STELEX_NEO_1040.exe'
        if rebuilt_ok:
            report['rebuilt_artifact_sha256'] = digest(rebuilt)
            run('rebuilt_static_pe', [sys.executable, str(root / 'research/verify_pe.py')])
        shutil.copyfile(root / 'research/BUILD_REPORT.json', output / 'WINDOWS_BUILD_REPORT.json')
        shutil.copyfile(root / 'research/PE_REPORT.json', output / 'WINDOWS_PE_REPORT.json')
        common = [root / 'source' / source for source in
                  ['era_memory.c', 'era_snapshot.c', 'era_core.c',
                   'era_identity.c', 'era_startup.c', 'era_probe_launcher.c']]
        for suite in ['settings', 'desktop', 'overlay', 'probe_launcher', 'report_button',
                      'gdi_resources', 'fortnite_window']:
            test = root / 'tests' / ('test_' + suite + '_windows.c')
            if not check(suite + '_source_present', test.is_file(), source=str(test)):
                continue
            sources = [test] if suite == 'probe_launcher' else [test, *common]
            executable = compile_test(suite, sources, unicode=True)
            if executable:
                execute_test(suite, executable)
        pure = {
            'core': ['era_core.c'],
            'snapshot': ['era_core.c', 'era_snapshot.c'],
            'identity': ['era_core.c', 'era_identity.c'],
            'startup': ['era_core.c', 'era_startup.c'],
        }
        for suite, sources in pure.items():
            executable = compile_test(suite + '_windows_logic',
                                      [root / 'tests' / ('test_' + suite + '.c'),
                                       *[root / 'source' / source for source in sources]],
                                      unicode=False)
            if executable:
                execute_test(suite + '_windows_logic', executable)
        # This suite compiles the actual reader with bounded API/decoder
        # doubles. Namespace those symbols to avoid colliding with the real
        # Windows CRT's own kernel32 imports; no game process is opened.
        doubled_functions = [
            'CloseHandle', 'CreateFileMappingW', 'CreateFileW',
            'CreateToolhelp32Snapshot', 'EnumWindows', 'GetClientRect',
            'GetExitCodeProcess', 'GetFileSizeEx', 'GetFileVersionInfoSizeW',
            'GetFileVersionInfoW', 'GetLastError', 'GetTickCount64', 'GetWindow',
            'GetWindowThreadProcessId', 'IsWindow', 'IsWindowVisible',
            'MapViewOfFile', 'Module32FirstW', 'Module32NextW', 'OpenProcess',
            'Process32FirstW', 'Process32NextW', 'QueryFullProcessImageNameW',
            'ReadProcessMemory', 'SetLastError', 'UnmapViewOfFile',
            'VerQueryValueW', '_snwprintf', '_wcsicmp',
        ]
        memory_flags = ['-UNDEBUG', '-D_CRTIMP=',
                        '-I' + str(root / 'tests/win32_stub')]
        memory_flags += ['-D' + name + '=era_double_' + name
                         for name in doubled_functions]
        memory = compile_test('memory_doubles_windows',
                              [root / 'tests/test_memory.c',
                               root / 'source/era_memory.c',
                               root / 'source/era_identity.c'],
                              unicode=False, extra_flags=memory_flags)
        report['memory_doubles_scope'] = dict(
            actual_reader_source=True, win32_api_doubles=True,
            snapshot_decoder_double=True, actual_process_access_tested=False,
            assertions_enabled=True, namespaced_functions=doubled_functions)
        if memory:
            execute_test('memory_doubles_windows', memory)
        recovery = compile_test('reader_recovery_windows',
                                [root / 'tests/test_reader_recovery_windows.c',
                                 root / 'source/era_snapshot.c',
                                 root / 'source/era_core.c',
                                 root / 'source/era_identity.c'],
                                unicode=True, extra_flags=['-UNDEBUG'])
        report['reader_recovery_scope'] = dict(
            actual_reader_source=True, actual_snapshot_decoder=True,
            actual_win32_memory_reads=True, memory_owner='own test process',
            synthetic_module_and_names=True, liveness_query_failure_forced=True,
            clock_controlled=True, actual_game_access_tested=False)
        if recovery:
            execute_test('reader_recovery_windows', recovery)
        loader = compile_test('native_probe_loader',
                              [root / 'tests/native_probe_loader_windows.c',
                               root / 'source/era_probe_launcher.c'], unicode=True)
        if loader:
            isolated = build / 'Probe launcher \u00c4 \u4e2d'
            (isolated / 'ClientProbeV2').mkdir(parents=True, exist_ok=True)
            isolated_loader = isolated / 'native-loader.exe'
            shutil.copyfile(loader, isolated_loader)
            bundled_probe = root / 'ClientProbeV2/NEO_Client_Probe.exe'
            isolated_probe = isolated / 'ClientProbeV2/NEO_Client_Probe.exe'
            shutil.copyfile(bundled_probe, isolated_probe)
            passed, text = run('execute_native_probe_loader', [str(isolated_loader)], timeout=30)
            check('native_probe_picker_real_shell_execute',
                  passed and 'launched=1 selected=0 failure=0 native=0' in text and
                  'probe_visible=1 picker_visible=1 same_process=1' in text and
                  'closed=1' in text,
                  probe_sha256=digest(isolated_probe),
                  game_file_selected=False, game_process_started=False)
        helper = compile_test('desktop_probe', [root / 'tests/desktop_probe.c'], unicode=False)
        if helper:
            # The small window-probe helper needs User32 despite its main() entry.
            protocol_match = re.search(r'#define\s+ERA_DESKTOP_PROTOCOL\s+(0x[0-9a-fA-F]+)',
                                       (root / 'source/era_desktop.c').read_text())
            if protocol_match is None:
                raise ValueError('Expected desktop protocol declaration not found')
            protocol = int(protocol_match[1], 16)
            product_smoke('shipped', shipped, helper, protocol)
            if rebuilt_ok:
                product_smoke('rebuilt', rebuilt, helper, protocol)
        report['passed'] = bool(rows) and all(row['passed'] for row in rows)
    except Exception as error:
        check('runner_completed', False, error=type(error).__name__ + ': ' + str(error))
    finally:
        report['not_tested'] = [
            'Actual Neo/Fortnite client, memory access and name-table compatibility',
            'Real game input acceptance, camera/bone freshness and in-game overlay',
            'Physical keyboard Ctrl+C',
            'ASan/UBSan on native Windows (Linux sanitizer evidence is separate)',
            'Real protected-process liveness query denial (reader regression uses API doubles)',
        ]
        (output / 'NATIVE_WINDOWS_RESULTS.json').write_text(
            json.dumps(report, indent=2) + '\n', encoding='utf-8')
        summary_path = os.environ.get('GITHUB_STEP_SUMMARY')
        if summary_path:
            summary = ['## Native Windows validation', '',
                       'Result: **' + ('PASS' if report['passed'] else 'FAIL') + '**', '',
                       'Package SHA256: `' + report['package_sha256'] + '`', '',
                       '| Check | Result | Assertions |', '|---|---|---:|']
            for row in rows:
                summary.append('| ' + row['name'] + ' | ' +
                               ('PASS' if row['passed'] else 'FAIL') + ' | ' +
                               str(row.get('assertions', '')) + ' |')
            summary += ['', 'No actual Neo client or game input was tested.']
            with Path(summary_path).open('a', encoding='utf-8') as stream:
                stream.write('\n'.join(summary) + '\n')
        print(json.dumps(dict(passed=report['passed'], checks=len(rows),
                              report=str(output / 'NATIVE_WINDOWS_RESULTS.json'))), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
