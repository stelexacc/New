/* Actual HWND/PID/visibility state for the Fortnite connection display.
 * Foreground selection is controlled without changing focus or sending input. */
#define WIN32_LEAN_AND_MEAN
#define UNICODE 1
#define _UNICODE 1
#include <windows.h>
#include <stdio.h>
static HWND selected_foreground;
static HWND WINAPI selected_foreground_window(void){return selected_foreground;}
#define GetForegroundWindow selected_foreground_window
#define wmain desktop_console_not_started
#define wWinMain desktop_entry_not_started
#include "../source/era_desktop.c"
#undef GetForegroundWindow
#undef wmain
#undef wWinMain

static int checks,failures;
#define CHECK(condition) do {checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);failures++;}}while(0)
int wmain(void){
    EraFrame frame={0};
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: nicht erkannt")==0);
    HWND game=CreateWindowExW(0,L"STATIC",L"FortniteGame fixture",WS_OVERLAPPEDWINDOW,
        0,0,1280,720,NULL,NULL,GetModuleHandleW(NULL),NULL);
    CHECK(game!=NULL);if(!game)return 2;
    frame.pid=GetCurrentProcessId();frame.game_window=(uintptr_t)game;selected_foreground=game;
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: verborgen")==0);
    ShowWindow(game,SW_SHOWNOACTIVATE);
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: aktiv")==0);
    selected_foreground=NULL;
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: im Hintergrund")==0);
    ShowWindow(game,SW_MINIMIZE);
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: minimiert")==0);
    ShowWindow(game,SW_RESTORE);selected_foreground=game;frame.pid++;
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: anderer Prozess")==0);
    frame.pid=0;CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: nicht erkannt")==0);
    frame.pid=GetCurrentProcessId();CHECK(DestroyWindow(game));
    CHECK(wcscmp(fortnite_window_status(&frame),L"Fortnite-Fenster: nicht erkannt")==0);
    printf("NEO Fortnite window: %d assertions, %d failures; real HWND/PID/visibility, no game or input\n",checks,failures);
    return failures?1:0;
}
