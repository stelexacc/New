"""Rebuild a window probe and smoke-test the product under Wine/Xvfb.

Requires an initialized 64-bit Wine prefix, a running DISPLAY, a newly built
product EXE, and Zig 0.15.2+. Does not launch or attach to Neo/Fortnite.
Wine 10 wineconsole accepts the application command directly, without the
obsolete --backend option. Native Windows and physical Ctrl+C are untested.
"""
from pathlib import Path
import argparse,subprocess,time,os,json,hashlib,shutil
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--wine',required=True,help='Wine64 loader or configured wrapper')
parser.add_argument('--prefix',type=Path,required=True,help='Initialized Wine prefix')
parser.add_argument('--zig',default=os.environ.get('ZIG','zig'),help='Zig executable for rebuilding the window probe')
parser.add_argument('--timeout',type=float,default=90,help='Cold-start or probe timeout in seconds')
parser.add_argument('--username',default=os.environ.get('USER','agent'),help='Wine prefix profile directory name')
args=parser.parse_args()
root=Path(__file__).resolve().parent.parent
evidence=root/'research'
wine=args.wine
prefix=args.prefix.resolve()
env=os.environ.copy();env['WINEPREFIX']=str(prefix);env.setdefault('WINEARCH','win64')
product=root/'STELEX_NEO_1040.exe'
helper=root/'build/review_desktop_probe.exe'
console=prefix/'drive_c/windows/system32/wineconsole.exe'
runtime=prefix/'drive_c/users'/args.username/'AppData/Local/STELEX_NEO_1040/runtime.log'
report={'passed':False,'wine_version':'not queried','actual_windows_tested':False,'live_neo_tested':False,'artifact_sha256':hashlib.sha256(product.read_bytes()).hexdigest(),'checks':[]}
start_size=runtime.stat().st_size if runtime.exists() else 0
out=(evidence/'REVIEW_STARTUP_PROCESS.log').open('w')
proc=None
counter=0
def zpath(p):return 'Z:'+str(p).replace('/',chr(92))
def probe(mode='probe'):
 global counter
 counter+=1
 f=root/'build'/('review_probe_'+str(counter)+'.json')
 f.unlink(missing_ok=True)
 # Wine service children can retain captured pipe descriptors after the probe
 # returns. Its structured result is already a file; log streams to disk so
 # completion waits for the helper itself rather than unrelated pipe EOF.
 p=subprocess.run([wine,str(helper),mode,zpath(f)],stdout=out,stderr=out,timeout=args.timeout,env=env)
 return json.loads(f.read_text()) if f.exists() else {'probe_exit':p.returncode,'probe_result_missing':True}
def expect(key,condition,details=None):
 report['checks'].append({'name':key,'passed':bool(condition),'details':details})
 if not condition:raise AssertionError(key)
try:
 build=root/'build';build.mkdir(exist_ok=True)
 zig=shutil.which(args.zig)
 if not zig:raise RuntimeError('Zig not found: '+args.zig)
 build_env=env.copy()
 build_env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(build/'zig-global-cache'))
 build_env.setdefault('ZIG_LOCAL_CACHE_DIR',str(build/'zig-local-cache'))
 command=[zig,'cc','-target','x86_64-windows-gnu','-std=c11','-O2','-Wall','-Wextra','-Werror',str(root/'tests/desktop_probe.c'),'-luser32','-o',str(helper)]
 compiled=subprocess.run(command,cwd=root,env=build_env,text=True,capture_output=True,timeout=240)
 expect('Window probe rebuilt',compiled.returncode==0,{'command':command,'exit_code':compiled.returncode,'stdout':compiled.stdout,'stderr':compiled.stderr})
 version=subprocess.run([wine,'--version'],env=env,text=True,capture_output=True,timeout=args.timeout)
 report['wine_version']=version.stdout.strip()
 initial=probe()
 expect('No existing product menu before launch',not initial.get('menu_exists'),initial)
 proc=subprocess.Popen([wine,str(console),zpath(product)],stdout=out,stderr=out,env=env)
 until=time.monotonic()+args.timeout
 state={}
 while time.monotonic()<until:
  state=probe()
  if state.get('menu_exists') and state.get('console_visible'):break
  if proc.poll() is not None:raise RuntimeError('Console process exited early: '+str(proc.returncode))
  time.sleep(.15)
 expect('Product console visible',state.get('console_visible'),state)
 expect('Product menu created hidden',state.get('menu_exists') and not state.get('menu_visible'),state)
 expect('Product overlay hidden',not state.get('overlay_visible'),state)
 expect('Protocol verified',state.get('protocol')==0x4e454f37,state)
 blocked=probe('show')
 expect('Menu show request blocked without game',not blocked.get('menu_visible'),blocked)
 time.sleep(1)
 closing=probe('close')
 proc.wait(timeout=20)
 expect('Console process exited cleanly',proc.returncode==0,{'exit_code':proc.returncode,'probe':closing})
 raw=runtime.read_bytes()[start_size:].decode('utf-8',errors='replace')
 (evidence/'REVIEW_STARTUP_RUNTIME.log').write_text(raw)
 expect('Status heartbeat written','[STATE NEO]' in raw)
 expect('Unverified attach stays blocked','[MENU] Gesperrt:' in raw)
 expect('Shutdown requested','[EXIT] Beenden ueber Konsole angefordert.' in raw)
 expect('Worker and windows shut down','[EXIT] Worker und Fenster beendet.' in raw)
 expect('Product remained byte-identical',hashlib.sha256(product.read_bytes()).hexdigest()==report['artifact_sha256'])
 report['passed']=True
except Exception as e:
 report['error']=type(e).__name__+': '+str(e)
 if proc and proc.poll() is None:
  try:probe('close');proc.wait(timeout=10)
  except Exception:proc.terminate()
 if runtime.exists():(evidence/'REVIEW_STARTUP_RUNTIME.log').write_bytes(runtime.read_bytes()[start_size:])
finally:
 out.close()
 report['limits']=['No actual Neo client or game memory was used.','WM_APP+2 shutdown exercised; physical console Ctrl+C not tested in this run.','Overlay draw contents and game input were not exercised.']
 (evidence/'REVIEW_STARTUP_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
raise SystemExit(0 if report['passed'] else 1)
