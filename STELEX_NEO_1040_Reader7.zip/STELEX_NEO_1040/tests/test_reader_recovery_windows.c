/* Integration of the actual process reader and snapshot decoder. The only
 * memory opened/read belongs to this test process and its synthetic fixture.
 * No game, target executable, input, elevation or remote execution is used. */
#define WIN32_LEAN_AND_MEAN
#define UNICODE 1
#define _UNICODE 1
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static ULONGLONG fixture_tick=100;
static int query_mode,query_calls,vm_reads;
static DWORD query_error=ERROR_ACCESS_DENIED;
static ULONGLONG WINAPI fixture_clock(void){return fixture_tick;}
static BOOL WINAPI fixture_exit_code(HANDLE process,LPDWORD code){
    query_calls++;
    if(query_mode==1){
        *code=STILL_ACTIVE; /* A failed query's output must never be trusted. */
        if(query_error)SetLastError(query_error);
        return FALSE;
    }
    if(query_mode==2){*code=0;return TRUE;}
    return GetExitCodeProcess(process,code);
}
static BOOL WINAPI fixture_vm_read(HANDLE process,LPCVOID address,LPVOID out,SIZE_T bytes,SIZE_T*received){
    vm_reads++;
    return ReadProcessMemory(process,address,out,bytes,received);
}
#define GetTickCount64 fixture_clock
#define GetExitCodeProcess fixture_exit_code
#define ReadProcessMemory fixture_vm_read
#include "../source/era_memory.c"
#undef ReadProcessMemory
#undef GetExitCodeProcess
#undef GetTickCount64

static int assertions,failures;
#define CHECK(condition) do{assertions++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);failures++;}}while(0)
enum {IMAGE_BYTES=0x08000000,APPEND_RVA=0x0214EC80,GETTER_RVA=0x02152D30,SLOT_RVA=0x064A8000};
static unsigned char*fixture_image,*fixture_names;

static int prepare_fixture(void){
    fixture_image=VirtualAlloc(NULL,IMAGE_BYTES,MEM_RESERVE,PAGE_READWRITE);
    fixture_names=VirtualAlloc(NULL,0x4000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
    if(!fixture_image||!fixture_names)return 0;
    if(!VirtualAlloc(fixture_image,0x1000,MEM_COMMIT,PAGE_READWRITE)||
       !VirtualAlloc(fixture_image+0x0214E000,0x6000,MEM_COMMIT,PAGE_READWRITE)||
       !VirtualAlloc(fixture_image+SLOT_RVA,0x1000,MEM_COMMIT,PAGE_READWRITE))return 0;
    IMAGE_DOS_HEADER dos={0};dos.e_magic=IMAGE_DOS_SIGNATURE;dos.e_lfanew=0x80;
    IMAGE_NT_HEADERS64 nt={0};nt.Signature=IMAGE_NT_SIGNATURE;
    nt.FileHeader.Machine=IMAGE_FILE_MACHINE_AMD64;nt.FileHeader.NumberOfSections=1;
    nt.FileHeader.SizeOfOptionalHeader=sizeof(IMAGE_OPTIONAL_HEADER64);
    nt.OptionalHeader.Magic=IMAGE_NT_OPTIONAL_HDR64_MAGIC;
    nt.OptionalHeader.SizeOfImage=IMAGE_BYTES;nt.OptionalHeader.SizeOfHeaders=0x1000;
    memcpy(fixture_image,&dos,sizeof(dos));memcpy(fixture_image+0x80,&nt,sizeof(nt));
    /* Known AppendString shape and a deliberately synthetic RIP-relative
       getter. This fixture is no evidence for a live client name layout. */
    static const unsigned char prefix[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x48,0x89,0x7c,0x24,0x18,0x41,0x56,0x48,0x83,0xec,0x20,0x48,0x8b,0xda,0x4c,0x8b,0xf1,0xe8};
    static const unsigned char lookup[]={0x49,0x8b,0x84,0xc1,0xb8,0,0,0,0x48,0x8b,0x0c,0xd0};
    memcpy(fixture_image+APPEND_RVA,prefix,sizeof(prefix));
    memcpy(fixture_image+APPEND_RVA+0x43,lookup,sizeof(lookup));
    int32_t relative=GETTER_RVA-(APPEND_RVA+0x20);
    memcpy(fixture_image+APPEND_RVA+0x1c,&relative,4);
    unsigned char getter[]={0x48,0x8b,0x05,0,0,0,0,0xc3};
    relative=SLOT_RVA-(GETTER_RVA+7);memcpy(getter+3,&relative,4);
    memcpy(fixture_image+GETTER_RVA,getter,sizeof(getter));
    uint64_t manager=(uint64_t)(uintptr_t)fixture_names;
    uint64_t chunk=manager+0x1000,first=manager+0x2000;
    memcpy(fixture_image+SLOT_RVA,&manager,8);memcpy(fixture_names+0xb8,&chunk,8);
    memcpy(fixture_names+0x1000,&first,8);memcpy(fixture_names+0x2010,"WrongName",10);
    return 1;
}
static EraReader*prepared_reader(void){
    EraReader*r=era_reader_create();if(!r)return NULL;
    r->process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,GetCurrentProcessId());
    if(!r->process){era_reader_destroy(r);return NULL;}
    r->pid=GetCurrentProcessId();r->module=(uint64_t)(uintptr_t)fixture_image;
    r->build_verified=1; /* Fixture metadata, not a target build assertion. */
    return r;
}
int wmain(void){
    CHECK(prepare_fixture());if(!fixture_image||!fixture_names||failures)return 2;
    EraReader*r=prepared_reader();CHECK(r!=NULL);if(!r)return 3;
    EraFrame frame={0};era_reader_poll(r,&frame);
    CHECK(frame.status==ERA_FINDING_NAMES);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);
    CHECK(frame.reader_generation==1);CHECK(frame.name_diagnostic.attempt==1);
    CHECK(frame.name_diagnostic.stage==ERA_NAME_STAGE_SENTINELS);
    CHECK(frame.name_diagnostic.reason==ERA_NAME_REASON_SENTINEL_MISMATCH);
    CHECK(frame.name_diagnostic.readable_candidates==1);CHECK(frame.name_diagnostic.sentinels_matched==0);
    EraSnapshotReader*decoder=r->decoder;HANDLE process=r->process;
    int reads_before=vm_reads;query_mode=1;fixture_tick+=16;era_reader_poll(r,&frame);
    CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);
    CHECK(frame.pid==GetCurrentProcessId());CHECK(!frame.attach_flags);CHECK(!frame.module_base);
    CHECK(!frame.count&&!frame.names_ready&&!frame.local_pawn);CHECK(!frame.game_window);
    CHECK(r->decoder==decoder&&r->process==process);CHECK(frame.reader_generation==1);
    CHECK(vm_reads==reads_before);int queries_before=query_calls;
    for(int i=0;i<64;i++){
        fixture_tick+=10;era_reader_poll(r,&frame);
        CHECK(frame.status==ERA_READ_FAILED&&frame.windows_error==ERROR_ACCESS_DENIED);
        CHECK(!frame.attach_flags&&!frame.count&&!frame.names_ready&&!frame.local_pawn);
        CHECK(r->decoder==decoder&&r->process==process);CHECK(frame.reader_generation==1);
    }
    CHECK(query_calls==queries_before);CHECK(vm_reads==reads_before);
    fixture_tick+=1000;era_reader_poll(r,&frame);
    CHECK(query_calls==queries_before+1);CHECK(vm_reads==reads_before);
    CHECK(r->decoder==decoder&&r->process==process);
    query_mode=0;fixture_tick+=1000;era_reader_poll(r,&frame);
    CHECK(frame.status==ERA_FINDING_NAMES);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);
    CHECK(frame.reader_generation==1);CHECK(frame.name_diagnostic.attempt==1);
    CHECK(r->decoder==decoder&&r->process==process);CHECK(vm_reads>reads_before);
    for(int i=0;i<63;i++){
        fixture_tick+=16;era_reader_poll(r,&frame);
        CHECK(frame.status==ERA_FINDING_NAMES);CHECK(frame.reader_generation==1);
    }
    CHECK(frame.name_diagnostic.attempt==2);CHECK(!frame.names_ready&&!frame.count);
    /* A failure without a native error must replace a stale last-error value. */
    query_mode=1;query_error=0;SetLastError(ERROR_ACCESS_DENIED);
    fixture_tick+=16;reads_before=vm_reads;era_reader_poll(r,&frame);
    CHECK(frame.windows_error==ERROR_GEN_FAILURE);CHECK(!frame.attach_flags);CHECK(vm_reads==reads_before);
    CHECK(r->decoder==decoder&&frame.reader_generation==1);
    query_mode=0;fixture_tick+=1000;era_reader_poll(r,&frame);
    CHECK(frame.status==ERA_FINDING_NAMES);CHECK(frame.name_diagnostic.attempt==2);
    CHECK(r->decoder==decoder&&frame.reader_generation==1);
    /* Recovery is still conditional on a fresh valid mapped module header. */
    query_mode=1;query_error=ERROR_ACCESS_DENIED;fixture_tick+=16;era_reader_poll(r,&frame);
    CHECK(!frame.attach_flags);fixture_image[0]=0;query_mode=0;fixture_tick+=1000;
    era_reader_poll(r,&frame);CHECK(frame.status==ERA_READ_FAILED);
    CHECK(frame.windows_error==ERROR_BAD_EXE_FORMAT);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);
    CHECK(r->decoder==NULL);CHECK(r->process==process);CHECK(frame.reader_generation==1);
    era_reader_destroy(r);
    fixture_image[0]='M';query_mode=0;fixture_tick+=2000;r=prepared_reader();CHECK(r!=NULL);
    if(r){
        era_reader_poll(r,&frame);CHECK(frame.reader_generation==1);CHECK(r->decoder!=NULL);
        query_mode=2;fixture_tick+=16;reads_before=vm_reads;era_reader_poll(r,&frame);
        CHECK(frame.status==ERA_NOT_RUNNING);CHECK(!frame.attach_flags&&!frame.module_base);
        CHECK(r->process==NULL&&r->decoder==NULL);CHECK(vm_reads==reads_before);
        CHECK(r->next_attempt==fixture_tick+1000);
        fixture_tick+=16;era_reader_poll(r,&frame);CHECK(frame.status==ERA_NOT_RUNNING);
        CHECK(r->process==NULL&&r->decoder==NULL);era_reader_destroy(r);
    }
    /* Real Win32 ERROR_INVALID_HANDLE from an actually closed own-process
       handle must revoke the decoder and stop retrying that stale handle. */
    query_mode=0;fixture_tick+=2000;r=prepared_reader();CHECK(r!=NULL);
    if(r){
        era_reader_poll(r,&frame);CHECK(r->decoder!=NULL);CHECK(frame.reader_generation==1);
        CHECK(CloseHandle(r->process));fixture_tick+=16;reads_before=vm_reads;
        era_reader_poll(r,&frame);
        CHECK(frame.status==ERA_READ_FAILED&&frame.windows_error==ERROR_INVALID_HANDLE);
        CHECK(!frame.attach_flags&&!frame.module_base&&!frame.game_window&&!frame.names_ready&&!frame.count);
        CHECK(r->process==NULL&&r->decoder==NULL);CHECK(vm_reads==reads_before);
        CHECK(frame.reader_generation==1);CHECK(r->next_attempt==fixture_tick+1000);
        queries_before=query_calls;
        for(int i=0;i<10;i++){
            fixture_tick+=16;era_reader_poll(r,&frame);
            CHECK(frame.windows_error==ERROR_INVALID_HANDLE&&!frame.attach_flags);
            CHECK(query_calls==queries_before&&vm_reads==reads_before);
        }
        era_reader_destroy(r);
    }
    VirtualFree(fixture_names,0,MEM_RELEASE);VirtualFree(fixture_image,0,MEM_RELEASE);
    printf("NEO reader recovery: %d assertions, %d failures; actual Win32 reads of own synthetic fixture and real decoder, no game or input\n",assertions,failures);
    return failures?1:0;
}
