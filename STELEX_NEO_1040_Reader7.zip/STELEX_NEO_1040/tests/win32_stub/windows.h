#ifndef ERA_TEST_WINDOWS_H
#define ERA_TEST_WINDOWS_H
#include <stddef.h>
#include <stdint.h>
#include <stdarg.h>
/* Host-only Win32 API double. Compile with -fshort-wchar; never shipped as a
 * replacement Windows SDK and never used by source/build.py. */
typedef void *HANDLE,*HWND,*LPVOID;typedef uint32_t DWORD;typedef uint16_t WORD;typedef int BOOL;typedef size_t SIZE_T;typedef intptr_t LPARAM;typedef unsigned UINT;typedef unsigned char BYTE;
typedef struct {int32_t left,top,right,bottom;} RECT;
typedef struct {int64_t QuadPart;} LARGE_INTEGER;
#define TRUE 1
#define FALSE 0
#define CALLBACK
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define PROCESS_QUERY_LIMITED_INFORMATION 0x1000U
#define PROCESS_VM_READ 0x10U
#define ERROR_PARTIAL_COPY 299U
#define ERROR_MOD_NOT_FOUND 126U
#define ERROR_OUTOFMEMORY 14U
#define ERROR_INVALID_PARAMETER 87U
#define ERROR_INVALID_ADDRESS 487U
#define ERROR_BAD_EXE_FORMAT 193U
#define ERROR_ACCESS_DENIED 5U
#define ERROR_BAD_LENGTH 24U
#define ERROR_GEN_FAILURE 31U
#define ERROR_INVALID_HANDLE 6U
#define STILL_ACTIVE 259U
#define GW_OWNER 4U
#define GENERIC_READ 0x80000000U
#define FILE_SHARE_READ 1U
#define FILE_SHARE_WRITE 2U
#define FILE_SHARE_DELETE 4U
#define OPEN_EXISTING 3U
#define FILE_ATTRIBUTE_NORMAL 0x80U
#define PAGE_READONLY 2U
#define FILE_MAP_READ 4U
#define IMAGE_DOS_SIGNATURE 0x5a4dU
#define IMAGE_NT_SIGNATURE 0x4550U
#define IMAGE_FILE_MACHINE_AMD64 0x8664U
#define IMAGE_NT_OPTIONAL_HDR64_MAGIC 0x20bU
#define IMAGE_SCN_MEM_READ 0x40000000U
#define IMAGE_SCN_MEM_EXECUTE 0x20000000U
#define TH32CS_SNAPPROCESS 2U
#define TH32CS_SNAPMODULE 8U
#define TH32CS_SNAPMODULE32 0x10U
typedef struct {WORD e_magic;BYTE pad[58];int32_t e_lfanew;} IMAGE_DOS_HEADER;
typedef struct {WORD Machine,NumberOfSections;DWORD TimeDateStamp,PointerToSymbolTable,NumberOfSymbols;WORD SizeOfOptionalHeader,Characteristics;} IMAGE_FILE_HEADER;
typedef struct {WORD Magic;BYTE pad[54];DWORD SizeOfImage,SizeOfHeaders;BYTE tail[176];} IMAGE_OPTIONAL_HEADER64;
typedef struct {DWORD Signature;IMAGE_FILE_HEADER FileHeader;IMAGE_OPTIONAL_HEADER64 OptionalHeader;} IMAGE_NT_HEADERS64;
typedef struct {BYTE Name[8];union {DWORD PhysicalAddress,VirtualSize;} Misc;DWORD VirtualAddress,SizeOfRawData,PointerToRawData,PointerToRelocations,PointerToLinenumbers;WORD NumberOfRelocations,NumberOfLinenumbers;DWORD Characteristics;} IMAGE_SECTION_HEADER;
typedef struct {DWORD dwSize,th32ProcessID;wchar_t szExeFile[260];} PROCESSENTRY32W;
typedef struct {DWORD dwSize;BYTE *modBaseAddr;DWORD modBaseSize;wchar_t szModule[256];} MODULEENTRY32W;
DWORD GetLastError(void);void SetLastError(DWORD);HANDLE CreateToolhelp32Snapshot(DWORD,DWORD);BOOL Process32FirstW(HANDLE,PROCESSENTRY32W*);BOOL Process32NextW(HANDLE,PROCESSENTRY32W*);BOOL Module32FirstW(HANDLE,MODULEENTRY32W*);BOOL Module32NextW(HANDLE,MODULEENTRY32W*);BOOL CloseHandle(HANDLE);BOOL ReadProcessMemory(HANDLE,const void*,void*,SIZE_T,SIZE_T*);
BOOL EnumWindows(BOOL(CALLBACK*)(HWND,LPARAM),LPARAM);DWORD GetWindowThreadProcessId(HWND,DWORD*);BOOL IsWindowVisible(HWND);HWND GetWindow(HWND,UINT);BOOL GetClientRect(HWND,RECT*);BOOL IsWindow(HWND);
HANDLE CreateFileW(const wchar_t*,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);BOOL GetFileSizeEx(HANDLE,LARGE_INTEGER*);HANDLE CreateFileMappingW(HANDLE,void*,DWORD,DWORD,DWORD,const wchar_t*);void*MapViewOfFile(HANDLE,DWORD,DWORD,DWORD,SIZE_T);BOOL UnmapViewOfFile(const void*);BOOL QueryFullProcessImageNameW(HANDLE,DWORD,wchar_t*,DWORD*);
DWORD GetFileVersionInfoSizeW(const wchar_t*,DWORD*);BOOL GetFileVersionInfoW(const wchar_t*,DWORD,DWORD,void*);BOOL VerQueryValueW(const void*,const wchar_t*,LPVOID*,UINT*);
uint64_t GetTickCount64(void);BOOL GetExitCodeProcess(HANDLE,DWORD*);HANDLE OpenProcess(DWORD,BOOL,DWORD);int _wcsicmp(const wchar_t*,const wchar_t*);int _snwprintf(wchar_t*,size_t,const wchar_t*,...);
#endif
