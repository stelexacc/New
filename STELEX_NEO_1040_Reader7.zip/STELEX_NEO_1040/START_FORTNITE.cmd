@echo off
setlocal
cd /d "%~dp0"
title FortniteGame - STELEX NEO Readerbuild 7
if not exist "STELEX_NEO_1040.exe" (
  echo STELEX_NEO_1040.exe fehlt. ZIP vollstaendig entpacken.
  pause
  exit /b 2
)
"%~dp0STELEX_NEO_1040.exe"
set "neo_result=%ERRORLEVEL%"
if not "%neo_result%"=="0" (
  echo.
  echo STELEX NEO wurde mit Fehler %neo_result% beendet. Meldungen oben und runtime.log pruefen.
  pause
)
exit /b %neo_result%
