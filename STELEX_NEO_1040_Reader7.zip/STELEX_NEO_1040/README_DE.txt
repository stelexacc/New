STELEX NEO 10.40-CL-9380822 - Readerbuild 7
========================================

Zuerst START_HIER_DE.txt lesen. Dieses Paket ist fuer Neo/Fortnite 10.40 und
FortniteClient-Win64-Shipping.exe vorgesehen. CS2 ist kein unterstuetztes
Ziel. Die Verbindungsseite nennt Ziel und Fensterstatus; das Spielfenster
muss zur gleichen Prozess-ID wie der erkannte Client gehoeren.

Readerbuild 7 behaelt den ruhenden Decoder bei unbekanntem Prozessstatus,
statt eine fehlgeschlagene Windows-Statusabfrage als Prozessende zu behandeln.
Bis Prozessstatus und Modulheader erneut bestaetigt sind, bleiben Spieldaten
und Eingabe gesperrt. Das ist keine Bestaetigung einer behobenen Namenaufloesung.
Die bisherigen Screenshots zeigen weiterhin Anfangsnamen=0/5.

START UND BEDIENUNG
Alte Tool-Instanzen schliessen, die ZIP vollstaendig in einen neuen,
schreibbaren Ordner entpacken und START_FORTNITE.cmd oeffnen. Im Titel muss
Readerbuild 7 stehen. INSERT oeffnet/schliesst das Menue, sobald Prozess,
Modulheader und Build bestaetigt sind. Fuer das Overlay Neo in Fenster- oder
rahmenlosem Fenstermodus verwenden und den Spielfokus herstellen.
Aim, ESP und Fadenkreuz starten aus; "Zielkreis anzeigen" startet an.
Ohne frische Kamera ist der Ring sichtbar als 90-Grad-Vorschau beschriftet.

Die Konsole zeigt Status und Logs. STRG+C beendet das Tool. Einstellungen,
Profile und runtime.log liegen unter %LOCALAPPDATA%\STELEX_NEO_1040.
DIAGNOSE.cmd sammelt die letzten Meldungen in diagnose.txt.

CLIENT-BERICHT
Im Menue "Verbindung -> Clientbericht erstellen" anklicken. Die beiliegende
Probe wird nach SHA-256-Pruefung gestartet und liest die ausgewaehlte echte
FortniteClient-Win64-Shipping.exe offline. Sie startet diese Datei nicht.
Der Prozesspfad wird nach Moeglichkeit vorgewaehlt; sonst die Clientdatei im
Dialog waehlen. Ueber "Berichtsordner" die erzeugte *_v2_*.txt weitergeben.
Sie muss mit NEO_PROBE_V2_COMPLETE enden. Ersatzwege: CLIENT_BERICHT.cmd oder
ClientProbeV2\NEO_Client_Probe.exe direkt oeffnen.
Dieser V2-Bericht bleibt fuer die offene Pruefung mit Anfangsnamen=0/5 noetig.

DIAGNOSE UND GRENZEN
Handle/Header/Build=1 bestaetigt diese Anbindungsschritte. Namen=0 bestaetigt
keine Namenstabelle; damit fehlen auch die davon abhaengigen Spieler- und
Kameradaten. Win32=299 ist ein unvollstaendiger Leseversuch und kann von
einem verworfenen Kandidaten stammen. DIAGNOSE_LESEN_DE.txt erklaert die
getrennten Namenszaehler, Fehlerangaben und den Reader-Neuaufbauzaehler.

Der Code prueft Kandidaten mit fuenf festen Anfangsnamen, Struktur und
stabilen Zeigerlesungen. Namen=1 gilt nur fuer die jeweilige aktuelle
Aufnahme. Es werden keine geratenen Ersatz-Zielpunkte verwendet.
Der Prozesszugriff verwendet normale Windows-Leseoperationen, keinen
Treiber und keine Fernaufrufe in den Client.

Aktuelle Testevidenz und offene Live-Pruefungen stehen in REVIEW_DE.txt und
research/REVIEW_VALIDATION.json. Fruehere Clientbuild-5-Ergebnisse unter
research/client5/ sind historische Nachweise. Kein simulierter oder nativer
Windows-Test ersetzt einen echten Neo-Test. Es gibt keine Zusage fuer
Fehlerfreiheit oder Eingabeannahme im Spiel.

QUELLEN UND BUILD
research/SDK_FACTS.json und SDK_SOURCE_RESEARCH.json dokumentieren die
gepinnten SDK-Metadaten. CLIENT_NAME_LAYOUT.json trennt statische Belege von
noch offenen Live-Pruefungen. Der vollstaendige hochgeladene Client-Codeauszug
wird nicht mitverteilt. SHA256.json nennt die gelieferten Dateihashes.

Python 3.10+ und Zig 0.15.2:
  python source/build.py --zig PFAD_ZU_ZIG
Portable Tests mit GCC:
  python source/run_tests.py --sanitize

Readerbuild7: Win32=6 verwirft den ungueltigen Handle und baut die Verbindung
nach begrenzter Wartezeit neu auf; die Namenskompatibilitaet bleibt offen.
