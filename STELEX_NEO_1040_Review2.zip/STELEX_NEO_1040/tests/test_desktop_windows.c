/* Desktop timer regression. A deterministic reader publication happens while
 * acquiring the real frame lock. Only clock/key samples are replaced; the
 * product timer and startup transitions execute unchanged. No reader thread,
 * game process, mouse injection or desktop entry point is started. */
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
static ULONGLONG WINAPI desktop_test_clock(void);
static void WINAPI desktop_test_enter(LPCRITICAL_SECTION section);
static SHORT WINAPI desktop_test_keys(int key);
#define GetTickCount64 desktop_test_clock
#define EnterCriticalSection desktop_test_enter
#define GetAsyncKeyState desktop_test_keys
#define wWinMain desktop_entry_not_started
#define wmain desktop_console_not_started
#ifndef ERA_DESKTOP_SOURCE
#define ERA_DESKTOP_SOURCE "../source/era_desktop.c"
#endif
#include ERA_DESKTOP_SOURCE
#undef GetTickCount64
#undef EnterCriticalSection
#undef GetAsyncKeyState
#undef wWinMain
#undef wmain

static ULONGLONG test_clock=100000;
static int publish_during_lock,test_checks,test_failures;
#define CHECK(condition) do {test_checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);test_failures++;}}while(0)
static ULONGLONG WINAPI desktop_test_clock(void){return test_clock;}
static SHORT WINAPI desktop_test_keys(int key){(void)key;return 0;}
static void WINAPI desktop_test_enter(LPCRITICAL_SECTION section){
    EnterCriticalSection(section);
    if(section==&frame_lock&&publish_during_lock){
        publish_during_lock=0;
        shared_frame.captured_ms=++test_clock;
        shared_frame.sequence++;
    }
}
static void next_tick(void){test_clock+=16;timer_tick();}
int wmain(void){
    InitializeCriticalSection(&frame_lock);InitializeCriticalSection(&log_lock);
    /* Invalid non-NULL handles keep nonessential paint/show requests targeted
       at test handles instead of InvalidateRect(NULL), which targets a desktop. */
    menu_window=(HWND)(uintptr_t)0x12345;overlay_window=(HWND)(uintptr_t)0x12346;
    era_config_defaults(&config);config_dirty=0;log_file[0]=0;
    shared_frame=(EraFrame){0};shared_frame.status=ERA_WAITING_WORLD;
    shared_frame.pid=777;shared_frame.module_base=UINT64_C(0x140000000);
    shared_frame.attach_flags=ERA_ATTACH_COMPLETE;shared_frame.captured_ms=test_clock;
    startup_state=(EraStartupState){1,shared_frame.pid,shared_frame.module_base};
    menu_shown=1;last_tick=test_clock-16;

    /* Reproduce a worker finishing after the timer started but before its
       frame copy. Sampling before the lock incorrectly detaches and hides UI. */
    publish_during_lock=1;timer_tick();
    CHECK(!publish_during_lock);CHECK(display_frame.captured_ms==test_clock);
    CHECK(last_tick==test_clock);CHECK(startup_state.attached);CHECK(menu_shown);
    CHECK(era_startup_can_show(&display_frame,test_clock));
    next_tick();CHECK(startup_state.attached);CHECK(menu_shown);

    /* The ordering correction must retain genuine loss/staleness gates. */
    shared_frame.attach_flags=ERA_ATTACH_PROCESS|ERA_ATTACH_MODULE;
    next_tick();CHECK(!startup_state.attached);CHECK(!menu_shown);
    shared_frame.attach_flags=ERA_ATTACH_COMPLETE;shared_frame.captured_ms=test_clock;
    next_tick();CHECK(startup_state.attached);CHECK(menu_shown);
    test_clock+=ERA_STARTUP_MAX_AGE_MS+1;timer_tick();
    CHECK(!startup_state.attached);CHECK(!menu_shown);
    shared_frame.captured_ms=test_clock;next_tick();
    CHECK(startup_state.attached);CHECK(menu_shown);

    DeleteCriticalSection(&log_lock);DeleteCriticalSection(&frame_lock);
    printf("NEO desktop timer: %d assertions, %d failures; no game or input started\n",test_checks,test_failures);
    return test_failures?1:0;
}
