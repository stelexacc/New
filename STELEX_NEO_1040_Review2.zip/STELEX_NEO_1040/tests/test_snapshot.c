/* SDK-backed fields and bounded getter/name-table simulations. These do not
   establish successful live Neo access or current bone poses. */
#include "../source/era_snapshot.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BASE UINT64_C(0x140000000)
#define DATA UINT64_C(0x300000000)
#define GLOBAL (BASE+0x064A0000)
#define CODE_BASE (BASE+0x0214E000)
#define NAME_SLOT_RVA UINT32_C(0x064A8000)
#define NAME_GETTER_RVA UINT32_C(0x02152D30)
#define AT(offset) (DATA+(offset))
typedef struct {unsigned char data[0x400000],globals[0x10000],code[0x5000];int denied,reads;uint64_t fail,base_reads,fail_hits;} Memory;
static Memory memory;
static int assertions;
#define CHECK(condition) do {assertions++;if(!(condition)){fprintf(stderr,"line %d: %s\n",__LINE__,#condition);exit(1);}} while(0)
static unsigned char*region(uint64_t address,size_t bytes){
    if(address>=DATA&&address-DATA<=sizeof(memory.data)&&bytes<=sizeof(memory.data)-(size_t)(address-DATA))return memory.data+(size_t)(address-DATA);
    if(address>=GLOBAL&&address-GLOBAL<=sizeof(memory.globals)&&bytes<=sizeof(memory.globals)-(size_t)(address-GLOBAL))return memory.globals+(size_t)(address-GLOBAL);
    if(address>=CODE_BASE&&address-CODE_BASE<=sizeof(memory.code)&&bytes<=sizeof(memory.code)-(size_t)(address-CODE_BASE))return memory.code+(size_t)(address-CODE_BASE);
    return NULL;
}
static int read_memory(void*context,uint64_t address,void*out,size_t bytes){
    Memory*m=(Memory*)context;m->reads++;if(address==BASE)m->base_reads++;
    unsigned char*source=region(address,bytes);if(m->denied||!source)return 0;
    if(address==m->fail){m->fail_hits++;if(bytes)memcpy(out,source,bytes-1);return 0;}
    memcpy(out,source,bytes);return 1;
}
static void put(uint64_t address,const void*data,size_t bytes){unsigned char*dst=region(address,bytes);assert(dst);memcpy(dst,data,bytes);}
static void pointer(uint64_t address,uint64_t value){put(address,&value,8);}
static void integer(uint64_t address,int32_t value){put(address,&value,4);}
static void byte(uint64_t address,unsigned char value){put(address,&value,1);}
static void array(uint64_t address,uint64_t data,int count,int capacity){pointer(address,data);integer(address+8,count);integer(address+12,capacity);}
static void name_entry(int index,const char*name){uint64_t entry=AT(0x4000)+(unsigned)index*128;pointer(AT(0x1000)+(unsigned)index*8,entry);put(entry+16,name,strlen(name)+1);}
static void object(uint64_t address,uint64_t type,int name,int index){
    pointer(address,BASE+0x1000);integer(address+8,0);integer(address+12,index);pointer(address+0x10,type);integer(address+0x18,name);integer(address+0x1C,0);pointer(address+0x20,0);
}
static void scene(uint64_t address,EraVec3 location,uint64_t parent){
    EraVec3 values[3]={location,{0,0,0},{1,1,1}};
    pointer(address+0xC0,parent);integer(address+0xC8,0);integer(address+0xCC,0);put(address+0x11C,values,sizeof(values));byte(address+0x14C,0);
}
static EraTransform transform(float z){return (EraTransform){{0,0,0,1},{0,0,z},0,{1,1,1},0};}
static void fixture(void){
    memset(&memory,0,sizeof(memory));
    const char*names[]={"None","ByteProperty","IntProperty","BoolProperty","FloatProperty"};
    for(int i=0;i<5;i++)name_entry(i,names[i]);
    name_entry(10,"FortEngine");name_entry(11,"FortPlayerPawnAthena");name_entry(12,"FortPlayerStateAthena");
    name_entry(20,"root");name_entry(21,"head");name_entry(22,"neck_01");name_entry(23,"pelvis");name_entry(24,"spine_03");
    /* AppendString prefix/lookup from the user-provided static report. */
    static const unsigned char append[]={0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x48,0x89,0x7c,0x24,0x18,0x41,0x56,0x48,0x83,0xec,0x20,0x48,0x8b,0xda,0x4c,0x8b,0xf1,0xe8,0x90,0x40,0x00,0x00,0x4c,0x8b,0xc8,0x41,0x8b,0x06,0x99,0x81,0xe2,0xff,0x3f,0x00,0x00,0x03,0xc2,0x44,0x8b,0xc0,0x25,0xff,0x3f,0x00,0x00,0x2b,0xc2,0x41,0xc1,0xf8,0x0e,0x48,0x63,0xd0,0x49,0x63,0xc0,0x49,0x8b,0x84,0xc1,0xb8,0x00,0x00,0x00,0x48,0x8b,0x0c,0xd0};
    put(BASE+0x0214EC80,append,sizeof(append));
    unsigned char getter[]={0x48,0x8B,0x05,0,0,0,0,0xC3};
    int32_t disp=(int32_t)(NAME_SLOT_RVA-(NAME_GETTER_RVA+7U));memcpy(getter+3,&disp,4);
    put(BASE+NAME_GETTER_RVA,getter,sizeof(getter));
    pointer(BASE+NAME_SLOT_RVA,AT(0));pointer(AT(0)+0xB8,AT(0x1000));
    pointer(BASE+0x64A0090,AT(0x9000));integer(BASE+0x64A0090+16,1);integer(BASE+0x64A0090+20,1);
    integer(BASE+0x64A0090+24,1);integer(BASE+0x64A0090+28,1);pointer(AT(0x9000),AT(0xA000));pointer(AT(0xA000),AT(0x10000));
    object(AT(0x70000),AT(0x70000),10,100);object(AT(0x71000),AT(0x71000),11,101);object(AT(0x72000),AT(0x72000),12,102);
    pointer(AT(0x70000)+0x40,0);pointer(AT(0x71000)+0x40,0);pointer(AT(0x72000)+0x40,0);
    object(AT(0x10000),AT(0x70000),10,0);pointer(AT(0x10000)+0x750,AT(0x11000));
    pointer(AT(0x11000)+0x78,AT(0x12000));pointer(AT(0x12000)+0x160,AT(0x13000));pointer(AT(0x12000)+0x120,AT(0x1B000));
    array(AT(0x13000)+0x38,AT(0x1D000),1,1);pointer(AT(0x1D000),AT(0x14000));pointer(AT(0x14000)+0x30,AT(0x15000));
    pointer(AT(0x15000)+0x298,AT(0x30000));pointer(AT(0x15000)+0x2B0,AT(0x18000));
    EraCamera camera={{0,0,160},{0,0,0},90};put(AT(0x18000)+0x1920,&camera,sizeof(camera));
    array(AT(0x1B000)+0x230,AT(0x1C000),2,2);pointer(AT(0x1C000),AT(0x20000));pointer(AT(0x1C008),AT(0x22000));
    for(int i=0;i<2;i++){
        uint64_t state=AT(0x20000)+(unsigned)i*0x2000,pawn=AT(0x30000)+(unsigned)i*0x2000;
        uint64_t root=AT(0x40000)+(unsigned)i*0x1000,mesh=AT(0x42000)+(unsigned)i*0x1000,poses=AT(0x50000)+(unsigned)i*0x2000;
        object(state,AT(0x72000),12,10+i);object(pawn,AT(0x71000),11,20+i);
        pointer(state+0x2A0,pawn);pointer(pawn+0x238,state);byte(state+0xDB0,(unsigned char)(i+2));
        pointer(pawn+0x130,root);pointer(pawn+0x278,mesh);scene(root,(EraVec3){1000,(float)(i*20),100},0);scene(mesh,(EraVec3){0,0,0},root);
        uint64_t health_set=AT(0x80000)+(unsigned)i*0x1000;pointer(pawn+0xCC0,health_set);
        float health=100,shield=50;put(health_set+0x30+0xC,&health,4);put(health_set+0x58+0xC,&health,4);put(health_set+0x80+0xC,&shield,4);
        pointer(mesh+0x3E8,AT(0x60000));array(mesh+0x648,poses,5,5);
        const float z[]={0,0,40,65,80};
        for(int b=0;b<5;b++){EraTransform value=transform(z[b]);put(poses+(unsigned)b*48,&value,sizeof(value));}
        uint16_t text[]={i?'E':'L','x',0};uint64_t text_at=AT(0x25000)+(unsigned)i*32;
        put(text_at,text,sizeof(text));array(state+0x320,text_at,3,3);
    }
    array(AT(0x60000)+0x180,AT(0x61000),5,5);array(AT(0x60000)+0x190,AT(0x62000),5,5);
    const int indexes[]={20,23,24,22,21};
    for(int i=0;i<5;i++){
        int values[]={indexes[i],0,i?i-1:-1};put(AT(0x61000)+(unsigned)i*12,values,sizeof(values));
        EraTransform pose=transform(0);put(AT(0x62000)+(unsigned)i*48,&pose,sizeof(pose));
    }
}
static EraSnapshotReader*reader(void){EraSnapshotReader*r=era_snapshot_create(read_memory,&memory,BASE);CHECK(r!=NULL);return r;}
static void test_valid(void){
    fixture();EraSnapshotReader*r=reader();EraFrame frame={0};frame.pid=123;frame.game_window=456;frame.captured_ms=789;frame.sequence=42;
    frame.module_base=BASE;frame.attach_flags=ERA_ATTACH_COMPLETE;
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);CHECK(frame.local_team==2);CHECK(frame.local_alive);
    CHECK(frame.pid==123&&frame.game_window==456&&frame.captured_ms==789&&frame.sequence==42);
    CHECK(frame.module_base==BASE&&frame.attach_flags==ERA_ATTACH_COMPLETE);
    CHECK(frame.entities[0].team==3);CHECK(strcmp(frame.entities[0].name,"Ex")==0);CHECK(frame.entities[0].target_mask==7);
    CHECK(fabsf(frame.entities[0].targets[0].z-180)<0.01f);CHECK(fabsf(frame.entities[0].targets[1].z-165)<0.01f);
    CHECK(fabsf(frame.entities[0].targets[2].z-140)<0.01f);CHECK(frame.entities[0].root.z==100);CHECK(memory.base_reads==0);
    memory.fail=AT(0x18000)+0x1920;CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);CHECK(frame.count==0);CHECK(!frame.local_alive);
    CHECK(frame.module_base==BASE&&frame.attach_flags==ERA_ATTACH_COMPLETE);
    memory.fail=0;CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    integer(AT(0x1B000)+0x230+8,257);CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);CHECK(!frame.count);
    era_snapshot_destroy(r);
}
static void test_invalid(void){
    CHECK(era_snapshot_create(NULL,NULL,BASE)==NULL);CHECK(era_snapshot_create(read_memory,&memory,0)==NULL);
    EraFrame frame={0};frame.module_base=BASE;frame.attach_flags=ERA_ATTACH_PROCESS;CHECK(era_snapshot_step(NULL,&frame)==ERA_READ_FAILED);CHECK(frame.module_base==BASE&&frame.attach_flags==ERA_ATTACH_PROCESS);CHECK(era_snapshot_step(NULL,NULL)==ERA_READ_FAILED);
    fixture();memory.denied=1;EraSnapshotReader*r=reader();CHECK(era_snapshot_step(r,&frame)!=ERA_READY);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();name_entry(0,"Wrong");r=reader();CHECK(era_snapshot_step(r,&frame)!=ERA_READY);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();integer(AT(0x61000)+4*12+8,4);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);CHECK(frame.entities[0].target_mask==0);era_snapshot_destroy(r);
    fixture();pointer(AT(0x40000)+0xC0,AT(0x40000));r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();integer(AT(0x43000)+0xC8,21);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);CHECK(!frame.entities[0].target_mask);era_snapshot_destroy(r);
    fixture();integer(AT(0x43000)+0x648+8,513);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(!frame.entities[0].target_mask);era_snapshot_destroy(r);
    fixture();array(AT(0x13000)+0x38,AT(0x1D000),2,2);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_WAITING_MATCH);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();byte(AT(0x18000)+0x1920+0x34,1);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();byte(AT(0x18000)+0x1920+0x30,1);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);era_snapshot_destroy(r);
    fixture();float off_center=0.25f;put(AT(0x18000)+0x1920+0x570,&off_center,4);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);era_snapshot_destroy(r);
}
static void test_chunk_boundary(void){
    fixture();EraFrame frame={0};
    pointer(BASE+0x64A0090,AT(0x9000));integer(BASE+0x64A0090+16,65537);integer(BASE+0x64A0090+20,65537);
    integer(BASE+0x64A0090+24,2);integer(BASE+0x64A0090+28,2);
    pointer(AT(0x9000),AT(0x100000));pointer(AT(0x9008),AT(0x300000));pointer(AT(0x300000),AT(0x10000));
    EraSnapshotReader*r=reader();
    for(int i=0;i<256;i++)CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_ENGINE);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);era_snapshot_destroy(r);
}
static void test_validation_and_retry(void){
    fixture();EraFrame frame={0};EraSnapshotReader*r=reader();
    /* Reference metadata can arrive after the mesh pose buffer. */
    integer(AT(0x61000)+4*12+8,4);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(!frame.entities[0].target_mask);
    integer(AT(0x61000)+4*12+8,3);
    for(int i=0;i<63;i++)CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    CHECK(!frame.entities[0].target_mask);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.entities[0].target_mask==7);
    era_snapshot_destroy(r);

    /* Validate the alternate legacy entry header through fixed names, rather
       than preferring the usual offset regardless of actual contents. */
    fixture();
    for(int i=0;i<25;i++){
        uint64_t entry=0;memcpy(&entry,region(AT(0x1000)+(unsigned)i*8,8),8);
        if(!entry)continue;
        char text[96];strcpy(text,(const char*)region(entry+16,96));
        memset(region(entry+8,104),0,104);put(entry+12,text,strlen(text)+1);
    }
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.entities[0].target_mask==7);era_snapshot_destroy(r);

    fixture();byte(BASE+NAME_GETTER_RVA+1,0x8D);pointer(BASE+NAME_SLOT_RVA+0xB8,AT(0x1000));
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.entities[0].target_mask==7);era_snapshot_destroy(r);

    fixture();integer(AT(0x10000)+8,0x10);
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_ENGINE);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();pointer(AT(0x70000)+0x40,AT(0x70000));
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_ENGINE);era_snapshot_destroy(r);

    fixture();array(AT(0x1B000)+0x230,AT(0x1C000),3,3);pointer(AT(0x1C010),AT(0x22000));
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);era_snapshot_destroy(r);

    fixture();uint16_t unicode[]={'N',0x00FC,0xD83D,0xDE80,0};
    put(AT(0x25020),unicode,sizeof(unicode));array(AT(0x22000)+0x320,AT(0x25020),5,5);
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(strcmp(frame.entities[0].name,"N\xC3\xBC\xF0\x9F\x9A\x80")==0);era_snapshot_destroy(r);
    fixture();uint16_t bad_unicode[]={'N',0xD800,0};
    put(AT(0x25020),bad_unicode,sizeof(bad_unicode));
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.entities[0].name[0]==0);era_snapshot_destroy(r);
}
static void test_vitals(void){
    fixture();EraFrame frame={0};
    for(int i=0;i<2;i++){
        uint64_t pawn=AT(0x30000)+(unsigned)i*0x2000,set=AT(0x80000)+(unsigned)i*0x1000;
        pointer(pawn+0xCC0,set);float health=75,maximum=100,shield=40,bound=100;
        put(set+0x30+0xC,&health,4);put(set+0x58+0xC,&maximum,4);put(set+0x80+0xC,&shield,4);
        put(set+0x80+0x14,&bound,4);byte(set+0x80+0x18,1);
    }
    EraSnapshotReader*r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    CHECK(frame.entities[0].health_valid);CHECK(frame.entities[0].health==75);CHECK(frame.entities[0].max_health==100);
    CHECK(frame.entities[0].shield_valid);CHECK(frame.entities[0].shield==40);CHECK(frame.entities[0].max_shield==100);
    byte(AT(0x81000)+0x80+0x18,0);CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    CHECK(frame.entities[0].shield_valid);CHECK(frame.entities[0].shield==40);CHECK(frame.entities[0].max_shield==0);
    float invalid=NAN;put(AT(0x81000)+0x30+0xC,&invalid,4);put(AT(0x81000)+0x80+0xC,&invalid,4);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(!frame.entities[0].health_valid);CHECK(!frame.entities[0].shield_valid);
    float zero=0;put(AT(0x80000)+0x30+0xC,&zero,4);CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(!frame.local_alive);
    memory.fail=AT(0x80000)+0x30;CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(!frame.local_alive);
    CHECK(!frame.entities[0].health_valid);era_snapshot_destroy(r);
}
static void test_engine_replacement(void){
    fixture();EraFrame frame={0};EraSnapshotReader*r=reader();
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    /* The old UObject storage disappears while PID and module stay unchanged. */
    object(AT(0x90000),AT(0x70000),10,1);pointer(AT(0x90000)+0x750,AT(0x11000));
    pointer(AT(0xA000),AT(0x90000));pointer(AT(0x10000),0);
    /* Recycled mesh storage must not retain a previous generation's name map. */
    integer(AT(0x61000)+3*12,21);integer(AT(0x61000)+4*12,22);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);
    CHECK(fabsf(frame.entities[0].targets[0].z-165)<0.01f);
    CHECK(fabsf(frame.entities[0].targets[1].z-180)<0.01f);
    era_snapshot_destroy(r);

    fixture();r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    /* A retained old Engine with an empty viewport World must not win every
       discovery pass ahead of a new active Engine in the same object chunk. */
    object(AT(0x90000),AT(0x70000),10,1);pointer(AT(0x90000)+0x750,AT(0x92000));
    pointer(AT(0x92000)+0x78,AT(0x12000));pointer(AT(0xA000)+24,AT(0x90000));
    integer(BASE+0x64A0090+16,2);integer(BASE+0x64A0090+20,2);
    pointer(AT(0x11000)+0x78,0);
    CHECK(era_snapshot_step(r,&frame)==ERA_WAITING_WORLD);CHECK(!frame.count);CHECK(!frame.local_alive);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);
    era_snapshot_destroy(r);

    /* The same inactive-first/active-second order must also work on startup. */
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);
    era_snapshot_destroy(r);

    fixture();r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    pointer(AT(0x11000)+0x78,0);
    for(int i=0;i<4;i++)CHECK(era_snapshot_step(r,&frame)==ERA_WAITING_WORLD);
    pointer(AT(0x11000)+0x78,AT(0x12000));
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);
    /* A partial read failure must neither publish old data nor permanently
       pin the reader to a failed path. */
    memory.fail=AT(0x10000)+0x750;
    CHECK(era_snapshot_step(r,&frame)==ERA_WAITING_WORLD);CHECK(!frame.count);
    memory.fail=0;CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    era_snapshot_destroy(r);
}
static void test_world_generation_replacement(void){
    for(int replace_world=0;replace_world<2;replace_world++){
        fixture();EraFrame frame={0};EraSnapshotReader*r=reader();
        CHECK(era_snapshot_step(r,&frame)==ERA_READY);
        CHECK(fabsf(frame.entities[0].targets[0].z-180)<0.01f);
        if(replace_world){
            put(AT(0xA0000),region(AT(0x12000),0x200),0x200);
            pointer(AT(0x11000)+0x78,AT(0xA0000));
        }else{
            put(AT(0xA0000),region(AT(0x13000),0x100),0x100);
            pointer(AT(0x12000)+0x160,AT(0xA0000));
        }
        /* Same Engine, name manager, asset address and bone count; only the
           valid World or GameInstance generation and recycled metadata change. */
        integer(AT(0x61000)+3*12,21);integer(AT(0x61000)+4*12,22);
        CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.names_ready);
        CHECK(frame.count==1);CHECK(frame.entities[0].target_mask==7);
        CHECK(fabsf(frame.entities[0].targets[0].z-165)<0.01f);
        CHECK(fabsf(frame.entities[0].targets[1].z-180)<0.01f);
        CHECK(era_snapshot_step(r,&frame)==ERA_READY);
        CHECK(fabsf(frame.entities[0].targets[0].z-165)<0.01f);
        era_snapshot_destroy(r);
    }
    fixture();EraFrame frame={0};EraSnapshotReader*r=reader();
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    put(AT(0xA0000),region(AT(0x12000),0x200),0x200);
    pointer(AT(0x11000)+0x78,AT(0xA0000));
    /* A recycled class pointer no longer denotes a pawn. A cached old kind
       must not make the new generation's local pawn pass validation. */
    integer(AT(0x71000)+0x18,20);
    CHECK(era_snapshot_step(r,&frame)==ERA_READ_FAILED);
    CHECK(frame.names_ready);CHECK(!frame.count);CHECK(!frame.local_alive);
    integer(AT(0x71000)+0x18,11);
    /* The negative kind is also cached: replacement needs another generation. */
    put(AT(0xA1000),region(AT(0xA0000),0x200),0x200);
    pointer(AT(0x11000)+0x78,AT(0xA1000));
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);
    era_snapshot_destroy(r);
}
static void test_mesh_read_budget_recovery(void){
    fixture();EraFrame frame={0};EraSnapshotReader*r=reader();
    /* Local and remote use different mesh assets. Only the local header fails.
       Previously it consumed the sole mesh lookup budget on every frame. */
    put(AT(0x90000),region(AT(0x60000),0x360),0x360);
    pointer(AT(0x42000)+0x3E8,AT(0x90000));memory.fail=AT(0x90000);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.count==1);
    CHECK(frame.entities[0].target_mask==0);CHECK(memory.fail_hits==1);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.entities[0].target_mask==7);
    CHECK(memory.fail_hits==1);
    for(int i=0;i<62;i++){
        CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.entities[0].target_mask==7);
    }
    CHECK(memory.fail_hits==1);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(memory.fail_hits==2);
    CHECK(frame.entities[0].target_mask==7);
    memory.fail=0;CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    CHECK(frame.entities[0].target_mask==7);era_snapshot_destroy(r);
}
static void test_private_region_bounds(void){
    /* The SDK only establishes this padding interval, not a skeleton member.
       Verify that structural candidates cannot escape the documented bounds. */
    const unsigned offsets[]={0x178,0x2D0,0x170,0x2D8};
    for(unsigned i=0;i<sizeof(offsets)/sizeof(offsets[0]);i++){
        fixture();unsigned char candidate[32];
        memcpy(candidate,region(AT(0x60000)+0x180,sizeof(candidate)),sizeof(candidate));
        memset(region(AT(0x60000)+0x180,sizeof(candidate)),0,sizeof(candidate));
        put(AT(0x60000)+offsets[i],candidate,sizeof(candidate));
        EraFrame frame={0};EraSnapshotReader*r=reader();
        CHECK(era_snapshot_step(r,&frame)==ERA_READY);
        CHECK(frame.entities[0].target_mask==(i<2?7U:0U));
        era_snapshot_destroy(r);
    }
}
static void add_getter_candidate(unsigned offset,uint32_t target){
    unsigned char code[]={0x48,0x8B,0x05,0,0,0,0};
    int32_t disp=(int32_t)(target-(NAME_GETTER_RVA+offset+7U));memcpy(code+3,&disp,4);
    put(BASE+NAME_GETTER_RVA+offset,code,sizeof(code));
}
static void test_name_locator(void){
    EraFrame frame={0};EraSnapshotReader*r;
    fixture();r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.names_ready);era_snapshot_destroy(r);
    /* A readable old ERA location is not consulted or accepted. */
    fixture();memset(region(BASE+NAME_GETTER_RVA,256),0,256);
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);CHECK(!frame.names_ready);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();byte(BASE+0x0214EC80,0x90);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    fixture();byte(BASE+0x0214EC80+0x47,0);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    fixture();integer(BASE+0x0214EC80+0x1C,0x70000000);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    fixture();memory.fail=BASE+NAME_GETTER_RVA;r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);CHECK(memory.fail_hits==1);era_snapshot_destroy(r);
    fixture();memory.fail=BASE+NAME_SLOT_RVA;r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    fixture();byte(AT(0x4000)+4*128+8,1);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    fixture();name_entry(4,"NotFloatProperty");r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    fixture();add_getter_candidate(16,NAME_SLOT_RVA);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.names_ready);era_snapshot_destroy(r);
    /* Distinct valid managers are ambiguous, even when sharing first names. */
    fixture();pointer(BASE+NAME_SLOT_RVA+8,AT(0xB000));pointer(AT(0xB000)+0xB8,AT(0x1000));add_getter_candidate(16,NAME_SLOT_RVA+8);
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);CHECK(!frame.count);era_snapshot_destroy(r);
    fixture();add_getter_candidate(0,0x0214E100);r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);era_snapshot_destroy(r);
    /* The call displacement is signed; a preceding in-section getter works. */
    fixture();unsigned char code[256];memcpy(code,region(BASE+NAME_GETTER_RVA,sizeof(code)),sizeof(code));
    int32_t disp=(int32_t)(0x0214E000-0x0214ECA0);memcpy(code+3,&(int32_t){(int32_t)(NAME_SLOT_RVA-(0x0214E000+7))},4);
    put(CODE_BASE,code,sizeof(code));integer(BASE+0x0214EC80+0x1C,disp);
    r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);era_snapshot_destroy(r);
    /* Manager replacement invalidates name/class/mesh caches together. */
    fixture();r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    pointer(BASE+NAME_SLOT_RVA,AT(0xB000));pointer(AT(0xB000)+0xB8,AT(0x1000));
    integer(AT(0x61000)+3*12,21);integer(AT(0x61000)+4*12,22);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.names_ready);CHECK(fabsf(frame.entities[0].targets[0].z-165)<0.01f);era_snapshot_destroy(r);
    /* Loss must never publish the old frame; recovery is bounded/backed off. */
    fixture();r=reader();CHECK(era_snapshot_step(r,&frame)==ERA_READY);
    pointer(AT(0)+0xB8,0);CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);CHECK(!frame.count);CHECK(!frame.local_alive);CHECK(!frame.names_ready);
    pointer(AT(0)+0xB8,AT(0x1000));for(int i=0;i<63;i++)CHECK(era_snapshot_step(r,&frame)==ERA_FINDING_NAMES);
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.names_ready);era_snapshot_destroy(r);
}
static void test_decoded_target_integration(void){
    fixture();scene(AT(0x41000),(EraVec3){1000,0,100},0);
    EraSnapshotReader*r=reader();EraFrame frame={0};
    CHECK(era_snapshot_step(r,&frame)==ERA_READY);CHECK(frame.names_ready);
    EraConfig config;era_config_defaults(&config);config.aim_enabled=1;
    config.aim_fov_degrees=1;config.aim_smooth=1;config.aim_part=1;
    EraAimState state={0};EraMotion motion={0};
    /* The decoded neck is inside this narrow cone; the head is outside it. */
    CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    CHECK(motion.target==frame.entities[0].id);CHECK(motion.dx==0);
    CHECK(motion.dy<0&&motion.dy>=-6);
    config.aim_part=0;
    CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    CHECK(motion.dx==0&&motion.dy==0);era_snapshot_destroy(r);
}
int main(void){test_valid();test_invalid();test_chunk_boundary();test_validation_and_retry();test_vitals();test_engine_replacement();test_world_generation_replacement();test_mesh_read_budget_recovery();test_private_region_bounds();test_name_locator();test_decoded_target_integration();printf("snapshot (Neo getter and SDK-field simulation): %d assertions passed\n",assertions);return 0;}
