"""Build/run real Win32 INI regressions with a forced documented-zero flush.

The console test includes the actual desktop save/commit/profile functions but
never calls either desktop entry point or starts GUI/readers/game processes.
A temporary legacy mutation demonstrates that the regression rejects the old
flush-return condition. No product source is modified.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,shutil,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
LEGACY='''static int save_settings(const wchar_t*path){
    wchar_t temporary[1200];if(swprintf(temporary,ARRAY_COUNT(temporary),L"%ls.tmp",path)<0)return 0;
    DeleteFileW(temporary);
    for(int i=0;i<ARRAY_COUNT(settings);i++){
        wchar_t value[32];swprintf(value,ARRAY_COUNT(value),L"%d",*setting_value(i));
        if(!WritePrivateProfileStringW(L"settings",settings[i].key,value,temporary)){DeleteFileW(temporary);return 0;}
    }
    if(!WritePrivateProfileStringW(NULL,NULL,NULL,temporary)||!MoveFileExW(temporary,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){
        DeleteFileW(temporary);return 0;
    }
    return 1;
}
'''
def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig',default='/tmp/era-build-venv/lib/python3.12/site-packages/ziglang/zig')
    parser.add_argument('--wine',default='/tmp/stelex-wine/usr/lib/wine/wine64')
    parser.add_argument('--negative-control',action='store_true')
    args=parser.parse_args();rows=[]
    env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/tmp/neo-settings-zig-global');env.setdefault('ZIG_LOCAL_CACHE_DIR','/tmp/neo-settings-zig-local')
    env.setdefault('WINEPREFIX','/tmp/stelex-wineprefix');env.setdefault('WINEARCH','win64');env.setdefault('WINEDEBUG','-all');env.setdefault('WINEDLLOVERRIDES','mscoree,mshtml=');env.setdefault('XDG_CACHE_HOME','/tmp/stelex-winecache')
    env.setdefault('LD_LIBRARY_PATH','/tmp/stelex-wine/usr/lib/x86_64-linux-gnu:/tmp/stelex-wine/usr/lib/x86_64-linux-gnu/wine/x86_64-unix')
    report={'passed':False,'windows_api_under_wine':True,'true_windows_machine_tested':False,'live_neo_tested':False,'forced_flush_zero':True,'checks':rows}
    source=ROOT/'source/era_desktop.c';report['desktop_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
    with tempfile.TemporaryDirectory(prefix='neo-settings-windows-') as temp:
        directory=Path(temp)
        variants=['current','legacy_negative'] if args.negative_control else ['current']
        for variant in variants:
            executable=directory/(variant+'.exe')
            command=[args.zig,'cc','-target','x86_64-windows-gnu','-std=c11','-O2','-Wall','-Wextra','-Werror','-municode','-Wl,--subsystem,console','-I'+str(ROOT/'source'),str(ROOT/'tests/test_settings_windows.c')]
            if variant!='current':
                original=source.read_text();start=original.index('static int save_settings(');end=original.index('static int load_settings(',start)
                mutated=directory/'era_desktop_legacy.c';mutated.write_text(original[:start]+LEGACY+original[end:])
                command+=['-DERA_DESKTOP_SOURCE="'+str(mutated)+'"']
            command+=[str(ROOT/'source'/n) for n in ['era_memory.c','era_snapshot.c','era_core.c','era_identity.c','era_startup.c']]
            command+=['-luser32','-lgdi32','-lshell32','-lversion','-lwinmm','-o',str(executable)]
            built=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True,timeout=240)
            rows.append({'name':variant+' compile','passed':built.returncode==0,'exit_code':built.returncode,'stdout':built.stdout,'stderr':built.stderr})
            if built.returncode:print(built.stderr);continue
            result=subprocess.run([args.wine,str(executable)],cwd=ROOT,env=env,text=True,capture_output=True,timeout=60)
            match=re.search(r'ERA Windows settings: (\d+) assertions, (\d+) failures; forced-zero flushes: (\d+); normal writes: (\d+)',result.stdout)
            expected_success=variant=='current';passed=(result.returncode==0)==expected_success and match is not None
            row={'name':variant+' execute','passed':passed,'expected_success':expected_success,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
            if match:row.update(assertions=int(match[1]),failures=int(match[2]),forced_zero_flushes=int(match[3]),normal_writes=int(match[4]))
            rows.append(row);print(('PASS' if passed else 'FAIL')+' '+variant);print(match[0] if match else result.stdout[-500:]);
    report['passed']=all(row['passed'] for row in rows)
    (ROOT/'research/SETTINGS_TEST_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
