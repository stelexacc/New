/* Exercise era_memory.c itself with bounded Win32 doubles, not a parallel
 * implementation of the reader. No process is opened by this executable. */
#include "win32_stub/windows.h"
#include "../source/era_memory.h"
#include "../source/era_snapshot.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#define BASE UINT64_C(0x140000000)
static unsigned char image[0x4000],disk[4096];
static DWORD error_code,pid=77;static uint64_t tick,path_delay,decode_delay;
static int process_exists,process_alive,deny_open,module_present,fail_module_snapshot,path_ok,disk_ok;
static int header_denied,header_partial,section_denied;
static int open_calls,module_calls,read_calls,path_calls,disk_calls,process_closes,decoder_created,decoder_destroyed,decoder_calls,decoder_no_memory;
static EraStatus decoded_status;
static int checks,failures;
#define CHECK(c) do {checks++;if(!(c)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#c);failures++;}}while(0)
static void copy_w(wchar_t*d,const wchar_t*s){do{*d=*s;}while(*s++&&d++);}
static void fixture(void){
 memset(image,0,sizeof(image));memset(disk,0,sizeof(disk));error_code=0;pid=77;tick=100;path_delay=decode_delay=0;
 process_exists=process_alive=module_present=path_ok=1;deny_open=fail_module_snapshot=disk_ok=header_denied=header_partial=section_denied=0;
 open_calls=module_calls=read_calls=path_calls=disk_calls=process_closes=decoder_created=decoder_destroyed=decoder_calls=decoder_no_memory=0;decoded_status=ERA_WAITING_MATCH;
 IMAGE_DOS_HEADER dos={0};dos.e_magic=IMAGE_DOS_SIGNATURE;dos.e_lfanew=0x80;memcpy(image,&dos,sizeof(dos));
 IMAGE_NT_HEADERS64 nt={0};nt.Signature=IMAGE_NT_SIGNATURE;nt.FileHeader.Machine=IMAGE_FILE_MACHINE_AMD64;nt.FileHeader.NumberOfSections=1;nt.FileHeader.SizeOfOptionalHeader=sizeof(IMAGE_OPTIONAL_HEADER64);nt.OptionalHeader.Magic=IMAGE_NT_OPTIONAL_HDR64_MAGIC;nt.OptionalHeader.SizeOfImage=0x08000000;nt.OptionalHeader.SizeOfHeaders=0x1000;memcpy(image+0x80,&nt,sizeof(nt));
 IMAGE_SECTION_HEADER section={0};section.Misc.VirtualSize=0x1000;section.VirtualAddress=0x2000;section.Characteristics=IMAGE_SCN_MEM_READ;memcpy(image+0x80+sizeof(nt),&section,sizeof(section));
 uint16_t numbers[]={4,23,0};uint32_t cl=9380822;uint64_t branch=BASE+0x2f00;uint16_t text[80];const char*name="++Fortnite+Release-10.40";int n=0;do{text[n]=(uint16_t)(unsigned char)name[n];}while(name[n++]);
 memcpy(image+0x2100,numbers,sizeof(numbers));memcpy(image+0x2108,&cl,4);memcpy(image+0x2110,&branch,8);memcpy(image+0x2118,&n,4);memcpy(image+0x211c,&n,4);memcpy(image+0x2f00,text,(size_t)n*2);
 static const char marker[]="++Fortnite+Release-10.40-CL-9380822";memcpy(disk+1024,marker,sizeof(marker));
}
DWORD GetLastError(void){return error_code;}
int _wcsicmp(const wchar_t*a,const wchar_t*b){while(*a&&*b){wchar_t x=*a++,y=*b++;if(x>=L'A'&&x<=L'Z')x+=32;if(y>=L'A'&&y<=L'Z')y+=32;if(x!=y)return x<y?-1:1;}return *a==*b?0:*a?1:-1;}
int _snwprintf(wchar_t*d,size_t n,const wchar_t*f,...){(void)f;if(n)d[0]=0;return 0;}
HANDLE CreateToolhelp32Snapshot(DWORD flags,DWORD target){(void)target;if(flags==TH32CS_SNAPPROCESS)return (HANDLE)1;module_calls++;if(fail_module_snapshot){error_code=ERROR_BAD_LENGTH;return INVALID_HANDLE_VALUE;}return (HANDLE)2;}
BOOL Process32FirstW(HANDLE s,PROCESSENTRY32W*e){(void)s;if(!process_exists)return 0;e->th32ProcessID=pid;copy_w(e->szExeFile,L"FortniteClient-Win64-Shipping.exe");return 1;}
BOOL Process32NextW(HANDLE s,PROCESSENTRY32W*e){(void)s;(void)e;return 0;}
BOOL Module32FirstW(HANDLE s,MODULEENTRY32W*e){(void)s;if(!module_present)return 0;e->modBaseAddr=(BYTE*)(uintptr_t)BASE;e->modBaseSize=0x08000000;copy_w(e->szModule,L"FortniteClient-Win64-Shipping.exe");return 1;}
BOOL Module32NextW(HANDLE s,MODULEENTRY32W*e){(void)s;(void)e;return 0;}
BOOL CloseHandle(HANDLE h){if((uintptr_t)h>=1000)process_closes++;return 1;}
BOOL EnumWindows(BOOL(CALLBACK*cb)(HWND,LPARAM),LPARAM p){cb((HWND)99,p);return 1;}
DWORD GetWindowThreadProcessId(HWND h,DWORD*p){(void)h;*p=pid;return 1;}
BOOL IsWindowVisible(HWND h){(void)h;return 1;}HWND GetWindow(HWND h,UINT relation){(void)h;(void)relation;return NULL;}
BOOL GetClientRect(HWND h,RECT*r){(void)h;*r=(RECT){0,0,1280,720};return 1;}BOOL IsWindow(HWND h){return h==(HWND)99;}
HANDLE CreateFileW(const wchar_t*p,DWORD access,DWORD share,void*security,DWORD creation,DWORD attr,HANDLE templ){(void)p;(void)share;(void)security;(void)creation;(void)attr;(void)templ;assert(access==GENERIC_READ);disk_calls++;return disk_ok?(HANDLE)3:INVALID_HANDLE_VALUE;}
BOOL GetFileSizeEx(HANDLE h,LARGE_INTEGER*s){(void)h;s->QuadPart=sizeof(disk);return 1;}
HANDLE CreateFileMappingW(HANDLE h,void*s,DWORD protect,DWORD high,DWORD low,const wchar_t*n){(void)h;(void)s;(void)high;(void)low;(void)n;assert(protect==PAGE_READONLY);return (HANDLE)4;}
void*MapViewOfFile(HANDLE h,DWORD access,DWORD high,DWORD low,SIZE_T size){(void)h;(void)high;(void)low;(void)size;assert(access==FILE_MAP_READ);return disk;}
BOOL UnmapViewOfFile(const void*p){(void)p;return 1;}
BOOL QueryFullProcessImageNameW(HANDLE h,DWORD flags,wchar_t*out,DWORD*size){(void)h;(void)flags;path_calls++;tick+=path_delay;if(!path_ok){error_code=ERROR_ACCESS_DENIED;return 0;}copy_w(out,L"C:\\ERA\\FortniteClient-Win64-Shipping.exe");*size=0;while(out[*size])(*size)++;return 1;}
DWORD GetFileVersionInfoSizeW(const wchar_t*p,DWORD*ignored){(void)p;(void)ignored;return 0;}
BOOL GetFileVersionInfoW(const wchar_t*p,DWORD ignored,DWORD bytes,void*out){(void)p;(void)ignored;(void)bytes;(void)out;return 0;}
BOOL VerQueryValueW(const void*d,const wchar_t*q,LPVOID*v,UINT*n){(void)d;(void)q;(void)v;(void)n;return 0;}
uint64_t GetTickCount64(void){return tick;}
BOOL GetExitCodeProcess(HANDLE h,DWORD*code){(void)h;*code=process_alive?STILL_ACTIVE:0;return 1;}
HANDLE OpenProcess(DWORD access,BOOL inherit,DWORD target){assert(access==(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ));assert(!inherit);assert(target==pid);open_calls++;if(deny_open){error_code=ERROR_ACCESS_DENIED;return NULL;}return (HANDLE)(uintptr_t)(1000+target);}
BOOL ReadProcessMemory(HANDLE h,const void*address,void*out,SIZE_T bytes,SIZE_T*received){
 assert((uintptr_t)h>=1000);read_calls++;uint64_t at=(uint64_t)(uintptr_t)address;*received=0;
 if((header_denied&&at<BASE+0x1000)||(section_denied&&at>=BASE+0x2000)){error_code=ERROR_ACCESS_DENIED;return 0;}
 if(header_partial&&at==BASE){error_code=0;*received=bytes-1;memcpy(out,image,bytes-1);return 1;}
 if(at<BASE||at>BASE+sizeof(image)||bytes>BASE+sizeof(image)-at){error_code=ERROR_PARTIAL_COPY;return 0;}
 memcpy(out,image+(size_t)(at-BASE),bytes);*received=bytes;return 1;
}
struct EraSnapshotReader {int tag;};
EraSnapshotReader*era_snapshot_create(EraReadMemory read,void*context,uint64_t base){(void)read;(void)context;assert(base==BASE);decoder_created++;if(decoder_no_memory)return NULL;return calloc(1,sizeof(EraSnapshotReader));}
void era_snapshot_destroy(EraSnapshotReader*r){if(r){decoder_destroyed++;free(r);}}
EraStatus era_snapshot_step(EraSnapshotReader*r,EraFrame*f){assert(r);decoder_calls++;tick+=decode_delay;uint32_t saved_pid=f->pid;uint64_t captured=f->captured_ms,sequence=f->sequence;uintptr_t window=f->game_window;memset(f,0,sizeof(*f));f->pid=saved_pid;f->captured_ms=captured;f->sequence=sequence;f->game_window=window;return f->status=decoded_status;}
static void alter_cl(uint32_t value){memcpy(image+0x2108,&value,4);}
int main(void){
 CHECK(sizeof(wchar_t)==2);CHECK(sizeof(IMAGE_DOS_HEADER)==64);CHECK(sizeof(IMAGE_NT_HEADERS64)==264);CHECK(sizeof(IMAGE_SECTION_HEADER)==40);
 EraFrame frame;EraReader*r;
 fixture();r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_WAITING_MATCH);CHECK(frame.pid==77);CHECK(frame.module_base==BASE);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);CHECK(frame.game_window==(uintptr_t)99);CHECK(decoder_created==1);CHECK(decoder_calls==1);
 decoded_status=ERA_READY;tick+=16;era_reader_poll(r,&frame);CHECK(frame.status==ERA_READY);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);CHECK(frame.module_base==BASE);CHECK(open_calls==1);CHECK(decoder_created==1);era_reader_destroy(r);CHECK(process_closes==1);CHECK(decoder_destroyed==1);
 /* Slow discovery must not pre-age a new snapshot; slow game reads must. */
 fixture();path_delay=2000;decoded_status=ERA_READY;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_READY);CHECK(frame.captured_ms==2100);CHECK(tick-frame.captured_ms==0);CHECK(path_calls==1);
 decode_delay=300;tick+=16;era_reader_poll(r,&frame);CHECK(frame.status==ERA_READY);CHECK(frame.captured_ms==2116);CHECK(tick-frame.captured_ms==300);CHECK(path_calls==1);era_reader_destroy(r);
 /* A missing path must not block independent remote FEngineVersion evidence. */
 fixture();path_ok=0;r=era_reader_create();era_reader_poll(r,&frame);CHECK(path_calls==1);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);CHECK(frame.status==ERA_WAITING_MATCH);CHECK(!frame.windows_error);CHECK(!disk_calls);era_reader_destroy(r);
 /* Access denial and its PID/code survive retry backoff, with no false attach. */
 fixture();deny_open=1;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_OPEN_DENIED);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);CHECK(frame.pid==77);CHECK(!frame.attach_flags);CHECK(!frame.module_base);CHECK(!read_calls);tick+=100;era_reader_poll(r,&frame);CHECK(frame.status==ERA_OPEN_DENIED);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);CHECK(open_calls==1);deny_open=0;tick+=2000;era_reader_poll(r,&frame);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);CHECK(open_calls==2);era_reader_destroy(r);
 /* A path/disk marker is insufficient when the actual module cannot be read. */
 fixture();disk_ok=1;header_denied=1;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);CHECK(!path_calls);CHECK(!decoder_created);int previous_reads=read_calls;tick+=100;era_reader_poll(r,&frame);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);CHECK(read_calls==previous_reads);header_denied=0;tick+=1000;era_reader_poll(r,&frame);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);era_reader_destroy(r);
 fixture();header_partial=1;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.windows_error==ERROR_PARTIAL_COPY);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);era_reader_destroy(r);
 /* Plausible header is required, not just bytes at a Toolhelp base. */
 for(int bad=0;bad<6;bad++){
  fixture();IMAGE_NT_HEADERS64*nt=(IMAGE_NT_HEADERS64*)(void*)(image+0x80);
  if(bad==0)image[0]=0;else if(bad==1)nt->Signature=0;else if(bad==2)nt->FileHeader.Machine=0x14c;else if(bad==3)nt->OptionalHeader.Magic=0x10b;else if(bad==4)nt->OptionalHeader.SizeOfHeaders=1;else nt->OptionalHeader.SizeOfImage=4096;
  r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.windows_error==ERROR_BAD_EXE_FORMAT);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);CHECK(!decoder_created);era_reader_destroy(r);
 }
 /* Module failure is throttled, retains error, and can recover. */
 fixture();fail_module_snapshot=1;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.windows_error==ERROR_BAD_LENGTH);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);CHECK(!frame.module_base);tick+=100;era_reader_poll(r,&frame);CHECK(module_calls==1);CHECK(frame.windows_error==ERROR_BAD_LENGTH);fail_module_snapshot=0;tick+=1000;era_reader_poll(r,&frame);CHECK(module_calls==2);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);era_reader_destroy(r);
 fixture();module_present=0;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.windows_error==ERROR_MOD_NOT_FOUND);CHECK(frame.attach_flags==ERA_ATTACH_PROCESS);era_reader_destroy(r);
 /* Wrong CL cannot release the menu; remote errors remain visible on backoff. */
 fixture();alter_cl(9380823);r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_BUILD_UNVERIFIED);CHECK(frame.attach_flags==(ERA_ATTACH_PROCESS|ERA_ATTACH_MODULE));CHECK(!decoder_created);tick+=100;era_reader_poll(r,&frame);CHECK(frame.status==ERA_BUILD_UNVERIFIED);CHECK(frame.attach_flags==3);CHECK(path_calls==1);alter_cl(9380822);tick+=3000;era_reader_poll(r,&frame);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);era_reader_destroy(r);
 fixture();section_denied=1;path_ok=0;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_BUILD_UNVERIFIED);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);tick+=100;era_reader_poll(r,&frame);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);CHECK(frame.attach_flags==3);era_reader_destroy(r);
 /* A file marker remains a supported independent build source after header proof. */
 fixture();alter_cl(9380823);disk_ok=1;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.attach_flags==ERA_ATTACH_COMPLETE);CHECK(disk_calls==1);era_reader_destroy(r);
 /* Losing header access after attachment revokes flags and decoder immediately. */
 fixture();r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.attach_flags==7);header_denied=1;tick+=16;era_reader_poll(r,&frame);CHECK(frame.attach_flags==1);CHECK(frame.windows_error==ERROR_ACCESS_DENIED);CHECK(decoder_destroyed==1);header_denied=0;tick+=1000;era_reader_poll(r,&frame);CHECK(frame.attach_flags==7);CHECK(decoder_created==2);era_reader_destroy(r);
 /* Old handles and decoder must be discarded before attaching to a new PID. */
 fixture();r=era_reader_create();era_reader_poll(r,&frame);process_alive=process_exists=0;tick+=16;era_reader_poll(r,&frame);CHECK(frame.status==ERA_NOT_RUNNING);CHECK(!frame.attach_flags);CHECK(!frame.module_base);CHECK(process_closes==1);CHECK(decoder_destroyed==1);process_alive=process_exists=1;pid=88;tick+=2100;era_reader_poll(r,&frame);CHECK(frame.pid==88);CHECK(frame.attach_flags==7);CHECK(open_calls==2);CHECK(decoder_created==2);era_reader_destroy(r);
 fixture();decoder_no_memory=1;r=era_reader_create();era_reader_poll(r,&frame);CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.windows_error==ERROR_OUTOFMEMORY);CHECK(frame.attach_flags==7);era_reader_destroy(r);
 fixture();era_reader_poll(NULL,&frame);CHECK(frame.status==ERA_READ_FAILED);CHECK(frame.windows_error==ERROR_OUTOFMEMORY);CHECK(!frame.attach_flags);era_reader_poll(NULL,NULL);
 printf("ERA memory reader: %d assertions, %d failures\n",checks,failures);return failures?1:0;
}
