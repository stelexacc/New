#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdio.h>
#include <string.h>
static BOOL WINAPI ignore_control(DWORD kind){return kind==CTRL_C_EVENT||kind==CTRL_BREAK_EVENT;}
int main(int argc,char**argv){
    if(argc!=3)return 2;
    FILE*f=fopen(argv[2],"wb");if(!f)return 3;
    HWND menu=FindWindowW(L"STELEX_NEO_1040_MENU",NULL),overlay=FindWindowW(L"STELEX_NEO_1040_OVERLAY",NULL);
    HWND console=FindWindowW(NULL,L"STELEX NEO | 10.40-CL-9380822 | Testbuild 1 | Verbindung und Logs");
    DWORD pid=0;DWORD_PTR protocol=0;if(menu){GetWindowThreadProcessId(menu,&pid);SendMessageTimeoutW(menu,WM_APP+3,0,0,SMTO_ABORTIFHUNG,500,&protocol);}
    if(!strcmp(argv[1],"show")&&menu){SendMessageW(menu,WM_APP+1,0,0);Sleep(100);}
    fprintf(f,"{\"console_exists\":%s,\"console_visible\":%s,\"menu_exists\":%s,\"menu_visible\":%s,\"overlay_visible\":%s,\"pid\":%lu,\"protocol\":%lu",console?"true":"false",console&&IsWindowVisible(console)?"true":"false",menu?"true":"false",menu&&IsWindowVisible(menu)?"true":"false",overlay&&IsWindowVisible(overlay)?"true":"false",(unsigned long)pid,(unsigned long)protocol);
    if(!strcmp(argv[1],"close")&&menu)PostMessageW(menu,WM_APP+2,0,0);
    if((!strcmp(argv[1],"ctrl")||!strcmp(argv[1],"break"))&&pid){
        FreeConsole();BOOL attached=AttachConsole(pid);BOOL ignored=FALSE,generated=FALSE;
        if(attached){ignored=SetConsoleCtrlHandler(ignore_control,TRUE);generated=GenerateConsoleCtrlEvent(!strcmp(argv[1],"break")?CTRL_BREAK_EVENT:CTRL_C_EVENT,0);Sleep(150);}
        fprintf(f,",\"console_attached\":%s,\"control_ignored_by_helper\":%s,\"ctrl_c_generated\":%s",attached?"true":"false",ignored?"true":"false",generated?"true":"false");
    }
    fprintf(f,"}\n");fclose(f);return menu?0:4;
}
