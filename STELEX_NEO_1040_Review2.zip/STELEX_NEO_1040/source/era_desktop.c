#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#include <windows.h>
#include <windowsx.h>
#include <shlobj.h>
#include <shellapi.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
#include "era_types.h"
#include "era_memory.h"
#include "era_startup.h"

#define MENU_TIMER 41
#define ERA_DESKTOP_PROTOCOL 0x4E454F31UL
#define ARRAY_COUNT(a) ((int)(sizeof(a)/sizeof((a)[0])))
#define COL(r,g,b) RGB(r,g,b)
#define MAX(a,b) ((a)>(b)?(a):(b))
#define CLAMP(v,a,b) ((v)<(a)?(a):((v)>(b)?(b):(v)))
static const COLORREF C_BG=COL(10,10,13),C_SIDE=COL(15,14,18),C_CARD=COL(24,23,28);
static const COLORREF C_HEAD=COL(20,17,23),C_RED=COL(202,35,56),C_LIGHT=COL(255,103,120);
static const COLORREF C_WHITE=COL(247,244,248),C_MUTED=COL(170,165,176),C_LINE=COL(49,44,53),C_OFF=COL(57,49,58);
static const COLORREF C_ENEMY=COL(255,63,83),C_TEAM=COL(91,152,255),C_KEY=COL(1,2,3);

typedef struct {HDC dc;HBITMAP bitmap;HGDIOBJ original;int width,height;} Canvas;
typedef struct {const wchar_t*key,*label;size_t offset;int kind,min,max;} Setting;
enum {K_TOGGLE=1,K_SLIDER,K_KEY};
#define SET(field,label,kind,lo,hi) {L"" #field,label,offsetof(EraConfig,field),kind,lo,hi}
static const Setting settings[]={
    SET(aim_enabled,L"Aimbot aktiv",K_TOGGLE,0,1),
    SET(aim_key,L"Zieltaste",K_KEY,1,254),
    SET(aim_part,L"Zielpunkt: 0 Kopf / 1 Hals / 2 Brust",K_SLIDER,0,2),
    SET(aim_team_filter,L"Team herausfiltern",K_TOGGLE,0,1),
    SET(aim_hard_lock,L"Ziel halten (Hard Lock)",K_TOGGLE,0,1),
    SET(aim_fov_degrees,L"Zielbereich in Grad",K_SLIDER,1,45),
    SET(aim_smooth,L"Glaettung",K_SLIDER,1,30),
    SET(aim_strength,L"Lockstaerke",K_SLIDER,1,100),
    SET(aim_gain_percent,L"Mausverstaerkung in Prozent",K_SLIDER,10,200),
    SET(esp_enabled,L"Visual ESP aktiv",K_TOGGLE,0,1),
    SET(esp_box,L"Box",K_TOGGLE,0,1),
    SET(esp_corner,L"Ecken statt voller Box",K_TOGGLE,0,1),
    SET(esp_skeleton,L"Skelett",K_TOGGLE,0,1),
    SET(esp_health,L"Lebenspunkte",K_TOGGLE,0,1),
    SET(esp_shield,L"Schild",K_TOGGLE,0,1),
    SET(esp_names,L"Spielernamen",K_TOGGLE,0,1),
    SET(esp_distance,L"Entfernung",K_TOGGLE,0,1),
    SET(esp_tracers,L"Linien von unten",K_TOGGLE,0,1),
    SET(esp_head_dot,L"Kopfpunkt",K_TOGGLE,0,1),
    SET(esp_team,L"Team anzeigen",K_TOGGLE,0,1),
    SET(esp_max_distance_m,L"Maximale Entfernung (Meter)",K_SLIDER,1,2000),
    SET(crosshair_enabled,L"Fadenkreuz aktiv",K_TOGGLE,0,1),
    SET(crosshair_preset,L"Form: 0 Kreuz / 1 Punkt / 2 Kreis",K_SLIDER,0,2),
    SET(crosshair_length,L"Laenge",K_SLIDER,1,40),
    SET(crosshair_gap,L"Abstand",K_SLIDER,0,30),
    SET(crosshair_thickness,L"Staerke",K_SLIDER,1,10),
    SET(crosshair_outline,L"Dunkle Kontur",K_TOGGLE,0,1),
    SET(crosshair_dot,L"Mittelpunkt",K_TOGGLE,0,1),
    SET(crosshair_red,L"Rot",K_SLIDER,0,255),
    SET(crosshair_green,L"Gruen",K_SLIDER,0,255),
    SET(crosshair_blue,L"Blau",K_SLIDER,0,255)
};
#undef SET

typedef struct {RECT r;int kind,value,setting;} Hit;
static Hit hits[96];static int hit_count;
static HWND menu_window,overlay_window;static int menu_shown=0,selected,scroll[5],scroll_max[5],drag=-1,capturing_key,capture_release;
static int insert_down,f9_down,profile_slot,config_dirty,closing;
static HFONT font_regular,font_bold,font_small,font_brand;
static Canvas menu_canvas,overlay_canvas;
typedef struct {HPEN handle;COLORREF color;int width;unsigned age;} CachedPen;
static CachedPen cached_pens[32];static unsigned pen_age;
static EraConfig config;
static EraFrame shared_frame,display_frame;
static EraAimState aim_state;
static CRITICAL_SECTION frame_lock;
static HANDLE stop_event,worker_handle,single_instance;
static wchar_t config_folder[1024],config_file[1100],log_file[1100],notice[192];
static uint64_t last_tick;
static EraStartupState startup_state;
static CRITICAL_SECTION log_lock;
static HANDLE shutdown_complete;
static volatile LONG console_stop;
static int log_failed_once;

static const wchar_t*tab_names[]={L"Aimbot",L"Visual ESP",L"Fadenkreuz",L"Profile",L"Verbindung"};
static const wchar_t*tab_notes[]={L"Zieltaste, Zielbereich und Bewegung",L"Spielerdaten und klare Anzeigen",L"Form, Farbe und Kontur",L"Drei lokale Einstellungsprofile",L"Clientstatus und Diagnose"};

static int*setting_value(int index){return (int*)((unsigned char*)&config+settings[index].offset);}
static int setting_index(size_t offset){for(int i=0;i<ARRAY_COUNT(settings);i++)if(settings[i].offset==offset)return i;return -1;}
#define FIELD(name) setting_index(offsetof(EraConfig,name))
static void notify(const wchar_t*text){wcsncpy(notice,text,ARRAY_COUNT(notice)-1);notice[ARRAY_COUNT(notice)-1]=0;if(menu_window)InvalidateRect(menu_window,NULL,FALSE);}
static void log_status(const wchar_t*text,DWORD error){
    char utf8[2048],line[3072];SYSTEMTIME t;GetLocalTime(&t);
    int bytes=WideCharToMultiByte(CP_UTF8,0,text,-1,utf8,sizeof(utf8),NULL,NULL);
    if(bytes<=0)strcpy(utf8,"Logtext konnte nicht kodiert werden.");
    int n=snprintf(line,sizeof(line),"%04u-%02u-%02u %02u:%02u:%02u | %s | Win32=%lu\r\n",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond,utf8,(unsigned long)error);
    if(n<0)return;if(n>=(int)sizeof(line))n=(int)sizeof(line)-1;
    EnterCriticalSection(&log_lock);
    HANDLE output=GetStdHandle(STD_OUTPUT_HANDLE);DWORD written=0;
    if(output&&output!=INVALID_HANDLE_VALUE)WriteFile(output,line,(DWORD)n,&written,NULL);
    if(log_file[0]){
        FILE*f=_wfopen(log_file,L"ab");
        if(f){if(fwrite(line,1,(size_t)n,f)!=(size_t)n&&!log_failed_once){log_failed_once=1;const char*warning="[ERROR] runtime.log konnte nicht vollstaendig geschrieben werden.\r\n";WriteFile(output,warning,(DWORD)strlen(warning),&written,NULL);}fclose(f);}
        else if(!log_failed_once){log_failed_once=1;const char*warning="[ERROR] runtime.log kann nicht geoeffnet werden. Konsolenmeldungen bleiben aktiv.\r\n";WriteFile(output,warning,(DWORD)strlen(warning),&written,NULL);}
    }
    LeaveCriticalSection(&log_lock);
}
static BOOL WINAPI console_control(DWORD control){
    if(control!=CTRL_C_EVENT&&control!=CTRL_BREAK_EVENT&&control!=CTRL_CLOSE_EVENT&&control!=CTRL_LOGOFF_EVENT&&control!=CTRL_SHUTDOWN_EVENT)return FALSE;
    InterlockedExchange(&console_stop,1);
    if(menu_window)PostMessageW(menu_window,WM_APP+2,0,0);
    if(control!=CTRL_C_EVENT&&control!=CTRL_BREAK_EVENT&&shutdown_complete)WaitForSingleObject(shutdown_complete,4000);
    return TRUE;
}
static void log_config(void){
    static EraConfig previous;static int initialized;
    for(int i=0;i<ARRAY_COUNT(settings);i++){
        int value=*setting_value(i),old=*(int*)((unsigned char*)&previous+settings[i].offset);
        if(!initialized||old!=value){wchar_t message[256];swprintf(message,ARRAY_COUNT(message),L"[SETTING] %ls=%d",settings[i].key,value);log_status(message,0);}
    }
    previous=config;initialized=1;
}
static int init_paths(void){
    wchar_t local[MAX_PATH];if(SHGetFolderPathW(NULL,CSIDL_LOCAL_APPDATA,NULL,SHGFP_TYPE_CURRENT,local)!=S_OK)return 0;
    if(swprintf(config_folder,ARRAY_COUNT(config_folder),L"%ls\\STELEX_NEO_1040",local)<0)return 0;
    if(!CreateDirectoryW(config_folder,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return 0;
    swprintf(config_file,ARRAY_COUNT(config_file),L"%ls\\settings.ini",config_folder);
    swprintf(log_file,ARRAY_COUNT(log_file),L"%ls\\runtime.log",config_folder);return 1;
}
static int save_settings(const wchar_t*path){
    wchar_t temporary[1200];if(swprintf(temporary,ARRAY_COUNT(temporary),L"%ls.tmp",path)<0)return 0;
    DeleteFileW(temporary);
    for(int i=0;i<ARRAY_COUNT(settings);i++){
        wchar_t value[32];swprintf(value,ARRAY_COUNT(value),L"%d",*setting_value(i));
        if(!WritePrivateProfileStringW(L"settings",settings[i].key,value,temporary)){DeleteFileW(temporary);return 0;}
    }
    /* Microsoft documents zero for a successful INI cache flush as well.
       Its return value must not reject a successfully written configuration. */
    WritePrivateProfileStringW(NULL,NULL,NULL,temporary);
    if(!MoveFileExW(temporary,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){
        DWORD error=GetLastError();DeleteFileW(temporary);SetLastError(error);return 0;
    }
    return 1;
}
static int load_settings(const wchar_t*path,int require_exists){
    DWORD attributes=GetFileAttributesW(path);
    if(attributes==INVALID_FILE_ATTRIBUTES||(attributes&FILE_ATTRIBUTE_DIRECTORY))return !require_exists;
    for(int i=0;i<ARRAY_COUNT(settings);i++)*setting_value(i)=(int)GetPrivateProfileIntW(L"settings",settings[i].key,*setting_value(i),path);
    era_config_clamp(&config);return 1;
}
static void commit_config(void){
    if(!config_dirty)return;era_config_clamp(&config);log_config();
    if(save_settings(config_file)){config_dirty=0;notify(L"Einstellungen lokal gespeichert");}
    else{notify(L"Speichern fehlgeschlagen; runtime.log pruefen");log_status(L"Konfiguration nicht gespeichert",GetLastError());}
}
static void profile_action(int load){
    wchar_t path[1100];swprintf(path,ARRAY_COUNT(path),L"%ls\\profile_%d.ini",config_folder,profile_slot+1);
    if(load){
        if(!load_settings(path,1)){notify(L"Dieser Profilplatz ist noch leer");return;}
        config_dirty=1;commit_config();era_aim_reset(&aim_state);notify(L"Profil geladen");
    }else if(save_settings(path))notify(L"Profil lokal gespeichert");
    else notify(L"Profil konnte nicht gespeichert werden");
}
static int canvas_prepare(Canvas*c,HDC target,int width,int height){
    if(width<1||height<1)return 0;
    if(c->dc&&c->width==width&&c->height==height)return 1;
    if(c->dc){SelectObject(c->dc,c->original);DeleteObject(c->bitmap);DeleteDC(c->dc);*c=(Canvas){0};}
    HDC dc=CreateCompatibleDC(target);if(!dc)return 0;
    HBITMAP bitmap=CreateCompatibleBitmap(target,width,height);if(!bitmap){DeleteDC(dc);return 0;}
    HGDIOBJ old=SelectObject(dc,bitmap);if(!old||old==HGDI_ERROR){DeleteObject(bitmap);DeleteDC(dc);return 0;}
    *c=(Canvas){dc,bitmap,old,width,height};SetBkMode(dc,TRANSPARENT);return 1;
}
static void canvas_close(Canvas*c){if(c->dc){SelectObject(c->dc,c->original);DeleteObject(c->bitmap);DeleteDC(c->dc);*c=(Canvas){0};}}
static void fill(HDC dc,int x,int y,int w,int h,COLORREF color){if(w<=0||h<=0)return;RECT r={x,y,x+w,y+h};SetDCBrushColor(dc,color);FillRect(dc,&r,(HBRUSH)GetStockObject(DC_BRUSH));}
static void rounded(HDC dc,int x,int y,int w,int h,int radius,COLORREF color){
    if(w<=0||h<=0)return;HGDIOBJ b=SelectObject(dc,GetStockObject(DC_BRUSH)),p=SelectObject(dc,GetStockObject(DC_PEN));
    SetDCBrushColor(dc,color);SetDCPenColor(dc,color);RoundRect(dc,x,y,x+w,y+h,radius,radius);SelectObject(dc,b);SelectObject(dc,p);
}
static void text(HDC dc,const wchar_t*s,int x,int y,int w,int h,COLORREF color,HFONT font,UINT alignment){
    if(w<=0||h<=0)return;RECT r={x,y,x+w,y+h};HGDIOBJ old=SelectObject(dc,font);SetTextColor(dc,color);
    DrawTextW(dc,s,-1,&r,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|alignment);SelectObject(dc,old);
}
static HPEN drawing_pen(COLORREF color,int width){
    int slot=-1;
    for(int i=0;i<ARRAY_COUNT(cached_pens);i++){
        if(cached_pens[i].handle&&cached_pens[i].color==color&&cached_pens[i].width==width){cached_pens[i].age=++pen_age;return cached_pens[i].handle;}
        if(!cached_pens[i].handle)slot=i;
    }
    if(slot<0){slot=0;for(int i=1;i<ARRAY_COUNT(cached_pens);i++)if(cached_pens[i].age<cached_pens[slot].age)slot=i;}
    HPEN handle=CreatePen(PS_SOLID,width,color);if(!handle)return NULL;
    if(cached_pens[slot].handle)DeleteObject(cached_pens[slot].handle);
    cached_pens[slot]=(CachedPen){handle,color,width,++pen_age};return handle;
}
static void stroke(HDC dc,int x,int y,int xx,int yy,COLORREF color,int thickness){
    HPEN pen=drawing_pen(color,thickness);if(!pen)return;HGDIOBJ old=SelectObject(dc,pen);
    MoveToEx(dc,x,y,NULL);LineTo(dc,xx,yy);SelectObject(dc,old);
}
static void outlined_line(HDC dc,int x,int y,int xx,int yy,COLORREF color,int thickness){stroke(dc,x,y,xx,yy,COL(3,3,4),thickness+2);stroke(dc,x,y,xx,yy,color,thickness);}
static void disc(HDC dc,int x,int y,int radius,COLORREF color){
    HGDIOBJ b=SelectObject(dc,GetStockObject(DC_BRUSH)),p=SelectObject(dc,GetStockObject(DC_PEN));
    SetDCBrushColor(dc,color);SetDCPenColor(dc,color);Ellipse(dc,x-radius,y-radius,x+radius+1,y+radius+1);SelectObject(dc,b);SelectObject(dc,p);
}
static void ring(HDC dc,int x,int y,int radius,COLORREF color,int thickness){
    if(radius<1||radius>10000)return;HPEN pen=drawing_pen(color,thickness);if(!pen)return;
    HGDIOBJ p=SelectObject(dc,pen),b=SelectObject(dc,GetStockObject(NULL_BRUSH));
    Ellipse(dc,x-radius,y-radius,x+radius+1,y+radius+1);SelectObject(dc,b);SelectObject(dc,p);
}
static void hit(int x,int y,int w,int h,int kind,int value,int index){if(hit_count<ARRAY_COUNT(hits))hits[hit_count++]=(Hit){{x,y,x+w,y+h},kind,value,index};}
static int inside(const RECT*r,int x,int y){return x>=r->left&&x<r->right&&y>=r->top&&y<r->bottom;}
static void button(HDC dc,int x,int y,int width,const wchar_t*label,int kind,int value,int active){
    rounded(dc,x,y,width,34,9,active?C_RED:C_OFF);text(dc,label,x+6,y,width-12,34,C_WHITE,font_small,DT_CENTER);hit(x,y,width,34,kind,value,-1);
}
static int card_begin(HDC dc,int x,int y,int width,int height,const wchar_t*label){
    rounded(dc,x,y,width,height,12,C_LINE);rounded(dc,x+1,y+1,width-2,height-2,11,C_CARD);
    fill(dc,x+16,y+20,3,18,C_RED);text(dc,label,x+29,y+12,width-48,32,C_WHITE,font_bold,DT_LEFT);return y+57;
}
static void key_name(int key,wchar_t*out,int count){
    const wchar_t*mouse=key==VK_LBUTTON?L"Linke Maustaste":key==VK_RBUTTON?L"Rechte Maustaste":key==VK_MBUTTON?L"Mausrad":key==VK_XBUTTON1?L"Maustaste 4":key==VK_XBUTTON2?L"Maustaste 5":NULL;
    if(mouse){wcsncpy(out,mouse,(size_t)count-1);out[count-1]=0;return;}
    UINT scan=MapVirtualKeyW((UINT)key,MAPVK_VK_TO_VSC);if(!GetKeyNameTextW((LONG)(scan<<16),out,count))swprintf(out,(size_t)count,L"Taste %d",key);
}
static int setting_row(HDC dc,int index,int x,int y,int width){
    if(index<0)return y;const Setting*s=&settings[index];int value=*setting_value(index);
    if(s->kind==K_TOGGLE){
        text(dc,s->label,x,y,width-88,34,C_WHITE,font_regular,DT_LEFT);
        rounded(dc,x+width-64,y+5,49,24,24,value?C_RED:C_OFF);disc(dc,x+width-64+(value?36:12),y+17,8,value?C_WHITE:C_MUTED);
        hit(x,y,width,34,1,0,index);return y+40;
    }
    if(s->kind==K_KEY){
        wchar_t label[80];if(capturing_key)wcscpy(label,L"Taste druecken (ESC: abbrechen)");else key_name(value,label,ARRAY_COUNT(label));
        text(dc,s->label,x,y,width,27,C_MUTED,font_small,DT_LEFT);rounded(dc,x,y+29,width,32,8,capturing_key?C_RED:C_OFF);
        text(dc,label,x+8,y+29,width-16,32,C_WHITE,font_small,DT_CENTER);hit(x,y+29,width,32,2,0,index);return y+72;
    }
    wchar_t number[32];swprintf(number,ARRAY_COUNT(number),L"%d",value);
    text(dc,s->label,x,y,width-66,27,C_WHITE,font_small,DT_LEFT);rounded(dc,x+width-61,y,60,25,7,C_HEAD);
    text(dc,number,x+width-61,y,60,25,C_LIGHT,font_bold,DT_CENTER);
    int rail=width-20,position=(value-s->min)*rail/(s->max-s->min);
    rounded(dc,x+7,y+38,rail,5,5,C_OFF);rounded(dc,x+7,y+38,position,5,5,C_RED);disc(dc,x+7+position,y+40,6,C_LIGHT);
    hit(x+2,y+24,width-4,34,3,0,index);return y+64;
}
static void draw_aim(HDC dc,int x,int y,int width,int*bottom){
    int gap=16,col=(width-gap)/2,l=card_begin(dc,x,y,col,284,L"Aktivierung und Ziel"),r=card_begin(dc,x+col+gap,y,col,284,L"Zielbereich und Bewegung");
    l=setting_row(dc,FIELD(aim_enabled),x+17,l,col-34);l=setting_row(dc,FIELD(aim_key),x+17,l,col-34);
    l=setting_row(dc,FIELD(aim_part),x+17,l,col-34);setting_row(dc,FIELD(aim_team_filter),x+17,l,col-34);
    r=setting_row(dc,FIELD(aim_fov_degrees),x+col+gap+17,r,col-34);r=setting_row(dc,FIELD(aim_smooth),x+col+gap+17,r,col-34);
    setting_row(dc,FIELD(aim_gain_percent),x+col+gap+17,r,col-34);
    l=card_begin(dc,x,y+300,col,194,L"Hard Lock");l=setting_row(dc,FIELD(aim_hard_lock),x+17,l,col-34);setting_row(dc,FIELD(aim_strength),x+17,l,col-34);
    r=card_begin(dc,x+col+gap,y+300,col,194,L"Aktivierung");
    text(dc,L"Menue schliessen und Zieltaste halten.",x+col+gap+17,r,col-34,29,C_WHITE,font_small,DT_LEFT);
    text(dc,L"Nur bei Spielfokus und frischen Daten.",x+col+gap+17,r+39,col-34,29,C_MUTED,font_small,DT_LEFT);
    text(dc,L"Verlorener Hard Lock: Taste loslassen.",x+col+gap+17,r+78,col-34,29,C_MUTED,font_small,DT_LEFT);*bottom=y+494;
}
static void draw_esp(HDC dc,int x,int y,int width,int*bottom){
    int gap=16,col=(width-gap)/2,l=card_begin(dc,x,y,col,326,L"Spieleranzeigen"),r=card_begin(dc,x+col+gap,y,col,326,L"Informationen");
    const int left[]={FIELD(esp_enabled),FIELD(esp_box),FIELD(esp_corner),FIELD(esp_skeleton),FIELD(esp_head_dot),FIELD(esp_team)};
    const int right[]={FIELD(esp_health),FIELD(esp_shield),FIELD(esp_names),FIELD(esp_distance),FIELD(esp_tracers)};
    for(int i=0;i<ARRAY_COUNT(left);i++)l=setting_row(dc,left[i],x+17,l,col-34);
    for(int i=0;i<ARRAY_COUNT(right);i++)r=setting_row(dc,right[i],x+col+gap+17,r,col-34);
    l=card_begin(dc,x,y+342,col,144,L"Entfernung");setting_row(dc,FIELD(esp_max_distance_m),x+17,l,col-34);
    r=card_begin(dc,x+col+gap,y+342,col,144,L"Farben");disc(dc,x+col+gap+24,r+14,5,C_ENEMY);text(dc,L"Gegner: Rot",x+col+gap+39,r,col-56,29,C_WHITE,font_regular,DT_LEFT);
    disc(dc,x+col+gap+24,r+53,5,C_TEAM);text(dc,L"Team: Blau",x+col+gap+39,r+39,col-56,29,C_WHITE,font_regular,DT_LEFT);*bottom=y+486;
}
static void crosshair_draw(HDC dc,int cx,int cy){
    int length=config.crosshair_length,gap=config.crosshair_gap,thickness=config.crosshair_thickness;
    COLORREF color=COL(config.crosshair_red,config.crosshair_green,config.crosshair_blue);
    if(config.crosshair_preset==1){if(config.crosshair_outline)disc(dc,cx,cy,thickness+2,COL(3,3,4));disc(dc,cx,cy,thickness,color);return;}
    if(config.crosshair_preset==2){if(config.crosshair_outline)ring(dc,cx,cy,length,COL(3,3,4),thickness+2);ring(dc,cx,cy,length,color,thickness);}
    else{
        const int d[4][4]={{-gap-length,0,-gap,0},{gap,0,gap+length,0},{0,-gap-length,0,-gap},{0,gap,0,gap+length}};
        for(int i=0;i<4;i++){if(config.crosshair_outline)outlined_line(dc,cx+d[i][0],cy+d[i][1],cx+d[i][2],cy+d[i][3],color,thickness);else stroke(dc,cx+d[i][0],cy+d[i][1],cx+d[i][2],cy+d[i][3],color,thickness);}
    }
    if(config.crosshair_dot){if(config.crosshair_outline)disc(dc,cx,cy,thickness+2,COL(3,3,4));disc(dc,cx,cy,thickness,color);}
}
static void draw_crosshair(HDC dc,int x,int y,int width,int*bottom){
    int gap=16,col=(width-gap)/2,l=card_begin(dc,x,y,col,475,L"Fadenkreuz");
    const int controls[]={FIELD(crosshair_enabled),FIELD(crosshair_preset),FIELD(crosshair_length),FIELD(crosshair_gap),FIELD(crosshair_thickness),FIELD(crosshair_outline),FIELD(crosshair_dot)};
    for(int i=0;i<ARRAY_COUNT(controls);i++)l=setting_row(dc,controls[i],x+17,l,col-34);
    int r=card_begin(dc,x+col+gap,y,col,290,L"Farbe");
    r=setting_row(dc,FIELD(crosshair_red),x+col+gap+17,r,col-34);r=setting_row(dc,FIELD(crosshair_green),x+col+gap+17,r,col-34);setting_row(dc,FIELD(crosshair_blue),x+col+gap+17,r,col-34);
    r=card_begin(dc,x+col+gap,y+306,col,169,L"Vorschau");
    rounded(dc,x+col+gap+17,r,col-34,92,9,C_BG);crosshair_draw(dc,x+col+gap+col/2,r+46);*bottom=y+475;
}
static void draw_profiles(HDC dc,int x,int y,int width,int*bottom){
    int gap=16,col=(width-gap)/2,l=card_begin(dc,x,y,col,271,L"Lokale Profile"),r=card_begin(dc,x+col+gap,y,col,271,L"Speichern und Start");
    int bw=(col-48)/3;for(int i=0;i<3;i++){wchar_t label[24];swprintf(label,ARRAY_COUNT(label),L"Profil %d",i+1);button(dc,x+17+i*(bw+7),l,bw,label,4,i,profile_slot==i);}
    button(dc,x+17,l+62,col-34,L"Aktuelle Auswahl speichern",5,0,1);button(dc,x+17,l+113,col-34,L"Ausgewaehltes Profil laden",5,1,0);
    text(dc,L"Alle drei Master-Schalter starten aus.",x+col+gap+17,r,col-34,29,C_WHITE,font_small,DT_LEFT);
    text(dc,L"Ein Profil kann sie bewusst einschalten.",x+col+gap+17,r+42,col-34,29,C_MUTED,font_small,DT_LEFT);
    text(dc,L"Regler werden beim Loslassen gespeichert.",x+col+gap+17,r+84,col-34,29,C_MUTED,font_small,DT_LEFT);
    text(dc,L"Ordner: LocalAppData / STELEX_NEO_1040",x+col+gap+17,r+126,col-34,29,C_MUTED,font_small,DT_LEFT);*bottom=y+271;
}
static void draw_connection(HDC dc,int x,int y,int width,int*bottom){
    int gap=16,col=(width-gap)/2,l=card_begin(dc,x,y,col,316,L"Client und Daten"),r=card_begin(dc,x+col+gap,y,col,316,L"Bedienung");
    text(dc,L"Zielbuild: " L"10.40-CL-9380822",x+17,l,col-34,28,C_WHITE,font_bold,DT_LEFT);
    text(dc,era_status_text(display_frame.status),x+17,l+43,col-34,29,C_LIGHT,font_small,DT_LEFT);
    wchar_t value[96];swprintf(value,ARRAY_COUNT(value),L"PID: %lu | Spieler: %d",(unsigned long)display_frame.pid,display_frame.count);
    text(dc,value,x+17,l+83,col-34,29,C_WHITE,font_small,DT_LEFT);
    swprintf(value,ARRAY_COUNT(value),L"Windows-Fehler: %lu",(unsigned long)display_frame.windows_error);text(dc,value,x+17,l+123,col-34,29,C_MUTED,font_small,DT_LEFT);
    int target_count=0;for(int i=0;i<display_frame.count&&i<ERA_MAX_ENTITIES;i++)if(display_frame.entities[i].target_mask&(1U<<(unsigned)config.aim_part))target_count++;
    swprintf(value,ARRAY_COUNT(value),L"Spieler mit gewaehltem Zielpunkt: %d",target_count);text(dc,value,x+17,l+151,col-34,26,target_count?C_WHITE:C_LIGHT,font_small,DT_LEFT);
    button(dc,x+17,l+180,col-34,L"Diagnoseprotokoll oeffnen",6,0,0);
    const wchar_t*lines[]={L"INSERT: Menue ein- / ausblenden",L"F9: Visual-ESP-Menue ein / aus",L"ESC: Menue schliessen",L"Fensterrahmen: verschieben / schliessen",L"Kein verbundener Client = keine Anzeigen"};
    for(int i=0;i<ARRAY_COUNT(lines);i++)text(dc,lines[i],x+col+gap+17,r+i*40,col-34,30,i?C_MUTED:C_WHITE,font_small,DT_LEFT);
    int yy=card_begin(dc,x,y+332,width,121,L"Verbindungsgrenze");
    text(dc,L"Standard-Windows-Zugriff. Keine EAC-Umgehung; verweigerter Zugriff bleibt gesperrt.",x+17,yy,width-34,29,C_WHITE,font_small,DT_LEFT);
    text(dc,L"Diese Portierung ist nicht mit einem laufenden Neo-Client validiert.",x+17,yy+31,width-34,27,C_MUTED,font_small,DT_LEFT);*bottom=y+453;
}
static void draw_menu(HDC dc,int width,int height){
    hit_count=0;fill(dc,0,0,width,height,C_BG);fill(dc,0,0,212,height,C_SIDE);fill(dc,211,0,1,height,C_LINE);
    text(dc,L"STELEX",23,28,171,47,C_WHITE,font_brand,DT_LEFT);text(dc,L"NEO / TESTBUILD 1",25,76,170,29,C_LIGHT,font_small,DT_LEFT);
    text(dc,L"10.40-CL-9380822",25,107,170,24,C_MUTED,font_small,DT_LEFT);
    for(int i=0;i<5;i++){int y=166+i*57;rounded(dc,13,y,185,45,10,i==selected?C_RED:C_SIDE);text(dc,tab_names[i],32,y,156,45,C_WHITE,i==selected?font_bold:font_regular,DT_LEFT);hit(13,y,185,45,7,i,-1);}
    text(dc,L"INSERT  /  F9",25,height-71,170,25,C_MUTED,font_small,DT_LEFT);text(dc,L"Externe Windows-Anbindung",25,height-43,177,25,C_MUTED,font_small,DT_LEFT);
    fill(dc,212,0,width-212,124,C_HEAD);fill(dc,212,123,width-212,1,C_LINE);
    text(dc,tab_names[selected],238,24,width-263,37,C_WHITE,font_brand,DT_LEFT);text(dc,tab_notes[selected],240,65,width-265,28,C_MUTED,font_regular,DT_LEFT);
    text(dc,notice,240,96,width-265,22,C_LIGHT,font_small,DT_LEFT);
    int saved=SaveDC(dc);IntersectClipRect(dc,212,124,width,height-43);
    int bottom=0,x=230,y=142-scroll[selected],content=width-249;
    if(selected==0)draw_aim(dc,x,y,content,&bottom);else if(selected==1)draw_esp(dc,x,y,content,&bottom);else if(selected==2)draw_crosshair(dc,x,y,content,&bottom);else if(selected==3)draw_profiles(dc,x,y,content,&bottom);else draw_connection(dc,x,y,content,&bottom);
    scroll_max[selected]=MAX(0,bottom+scroll[selected]-(height-55));RestoreDC(dc,saved);
    if(scroll_max[selected]>0){int track=height-181;int thumb=MAX(26,track*track/(track+scroll_max[selected]));int at=(track-thumb)*scroll[selected]/scroll_max[selected];rounded(dc,width-10,137,4,track,4,C_LINE);rounded(dc,width-10,137+at,4,thumb,4,C_RED);}
    fill(dc,212,height-43,width-212,43,C_HEAD);fill(dc,212,height-43,width-212,1,C_LINE);
    disc(dc,238,height-21,4,display_frame.status==ERA_READY?C_RED:C_MUTED);
    text(dc,era_status_text(display_frame.status),252,height-37,width-272,31,C_WHITE,font_small,DT_LEFT);
}
static int frame_window_rect(const EraFrame*frame,RECT*out){
    HWND game=(HWND)frame->game_window;if(!game||!IsWindow(game)||!IsWindowVisible(game)||IsIconic(game)||GetForegroundWindow()!=game)return 0;
    DWORD owner=0;if(!GetWindowThreadProcessId(game,&owner)||owner!=frame->pid)return 0;
    RECT r;if(!GetClientRect(game,&r)||r.right<1||r.bottom<1)return 0;POINT p={0,0};if(!ClientToScreen(game,&p))return 0;
    *out=(RECT){p.x,p.y,p.x+r.right,p.y+r.bottom};return r.right<=32768&&r.bottom<=32768;
}
static int fresh_frame(const EraFrame*frame,uint64_t now){return frame->status==ERA_READY&&frame->captured_ms<=now&&now-frame->captured_ms<250&&frame->count>=0&&frame->count<=ERA_MAX_ENTITIES&&era_camera_valid(&frame->camera);}
static void draw_box(HDC dc,int left,int top,int right,int bottom,COLORREF color){
    if(config.esp_corner){int w=(right-left)/4,h=(bottom-top)/4;const int lines[8][4]={{left,top,left+w,top},{left,top,left,top+h},{right,top,right-w,top},{right,top,right,top+h},{left,bottom,left+w,bottom},{left,bottom,left,bottom-h},{right,bottom,right-w,bottom},{right,bottom,right,bottom-h}};for(int i=0;i<8;i++)outlined_line(dc,lines[i][0],lines[i][1],lines[i][2],lines[i][3],color,1);}
    else{outlined_line(dc,left,top,right,top,color,1);outlined_line(dc,right,top,right,bottom,color,1);outlined_line(dc,right,bottom,left,bottom,color,1);outlined_line(dc,left,bottom,left,top,color,1);}
}
static int project_point(EraVec3 position,int width,int height,EraPoint*out){
    return era_project(&display_frame.camera,position,width,height,out)&&
        isfinite(out->x)&&isfinite(out->y)&&fabsf(out->x)<1000000.0f&&fabsf(out->y)<1000000.0f;
}
static void draw_overlay(HDC dc,int width,int height){
    fill(dc,0,0,width,height,C_KEY);
    if(!fresh_frame(&display_frame,GetTickCount64()))return;
    int cx=width/2,cy=height/2;
    if(config.crosshair_enabled)crosshair_draw(dc,cx,cy);
    if(config.aim_enabled){double radius=tan((double)config.aim_fov_degrees*0.017453292519943295)*((double)width*0.5)/tan((double)display_frame.camera.fov*0.008726646259971648);if(radius>0&&radius<10000)ring(dc,cx,cy,(int)radius,C_LIGHT,1);}
    if(!config.esp_enabled)return;
    for(int i=0;i<display_frame.count;i++){
        const EraEntity*e=&display_frame.entities[i];if(!e->alive||e->id==display_frame.local_pawn||!era_vec_valid(e->root))continue;
        int team=display_frame.local_team>=0&&e->team>=0&&e->team==display_frame.local_team;
        if(team&&!config.esp_team)continue;
        float meters=era_distance(e->root,display_frame.camera.location)*0.01f;if(!isfinite(meters)||meters>(float)config.esp_max_distance_m)continue;
        EraPoint head={0},root={0},feet={0};int head_valid=0,feet_valid=0;
        if(!project_point(e->root,width,height,&root))continue;
        if(e->bone_mask&(1u<<ERA_HEAD))head_valid=project_point(e->bones[ERA_HEAD],width,height,&head);
        else if(e->target_mask&1u)head_valid=project_point(e->targets[0],width,height,&head);
        const int foot_slots[]={ERA_L_FOOT,ERA_R_FOOT};
        for(int slot=0;slot<ARRAY_COUNT(foot_slots);slot++){int foot=foot_slots[slot];if(e->bone_mask&(1u<<foot)){
            EraPoint p;if(project_point(e->bones[foot],width,height,&p)&&(!feet_valid||p.y>feet.y)){feet=p;feet_valid=1;}
        }}
        float box_height=head_valid&&feet_valid?feet.y-head.y:0.0f;
        int box_valid=isfinite(box_height)&&box_height>=4.0f&&box_height<=(float)(height*3);
        int box_h=box_valid?(int)box_height:0,box_w=box_h/2;
        int left=(int)(head_valid?head.x:root.x)-box_w/2,right=left+box_w;
        int upper=(int)(head_valid?head.y:root.y)-3,lower=(int)(feet_valid?feet.y:root.y);
        COLORREF color=team?C_TEAM:C_ENEMY;
        if(config.esp_box&&box_valid)draw_box(dc,left,upper,right,lower,color);
        if(config.esp_tracers)outlined_line(dc,cx,height-1,(int)root.x,(int)root.y,color,2);
        if(config.esp_head_dot&&head_valid){disc(dc,(int)head.x,(int)head.y,4,COL(3,3,4));disc(dc,(int)head.x,(int)head.y,2,color);}
        if(config.esp_health&&box_valid&&e->health_valid&&isfinite(e->health)&&isfinite(e->max_health)&&e->max_health>0){int filled=(int)((float)box_h*CLAMP(e->health/e->max_health,0.0f,1.0f));fill(dc,left-7,upper,4,box_h+2,COL(3,3,4));fill(dc,left-6,lower-filled,2,filled,COL(77,224,131));}
        if(config.esp_shield&&box_valid&&e->shield_valid&&isfinite(e->shield)&&isfinite(e->max_shield)&&e->max_shield>0){int filled=(int)((float)box_w*CLAMP(e->shield/e->max_shield,0.0f,1.0f));fill(dc,left,lower+5,box_w,4,COL(3,3,4));fill(dc,left+1,lower+6,MAX(0,filled-2),2,COL(91,169,255));}
        if(config.esp_shield&&e->shield_valid&&isfinite(e->shield)){wchar_t shield[48];swprintf(shield,ARRAY_COUNT(shield),L"Schild: %.0f",(double)e->shield);text(dc,shield,left-40,lower+(config.esp_distance?35:13),box_w+80,22,COL(91,169,255),font_small,DT_CENTER);}
        if(config.esp_names&&e->name[0]){wchar_t name[96];int length=0;while(length<(int)sizeof(e->name)&&e->name[length])length++;int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,e->name,length,name,ARRAY_COUNT(name)-1);if(n>0){name[n]=0;text(dc,name,left-75,upper-24,box_w+150,23,COL(3,3,4),font_small,DT_CENTER);text(dc,name,left-76,upper-25,box_w+150,23,C_WHITE,font_small,DT_CENTER);}}
        if(config.esp_distance){wchar_t label[40];swprintf(label,ARRAY_COUNT(label),L"%.0f m%ls",(double)meters,e->downed?L" | DBNO":L"");text(dc,label,left-40,lower+13,box_w+80,22,C_WHITE,font_small,DT_CENTER);}
        /* Bone order is declared by the reader, never guessed from raw bone IDs. */
        if(config.esp_skeleton){
            static const unsigned char links[][2]={
                {ERA_HEAD,ERA_NECK},{ERA_NECK,ERA_CHEST},{ERA_CHEST,ERA_SPINE_02},
                {ERA_SPINE_02,ERA_SPINE_01},{ERA_SPINE_01,ERA_PELVIS},
                {ERA_CHEST,ERA_L_CLAVICLE},{ERA_L_CLAVICLE,ERA_L_UPPERARM},{ERA_L_UPPERARM,ERA_L_FOREARM},{ERA_L_FOREARM,ERA_L_HAND},
                {ERA_CHEST,ERA_R_CLAVICLE},{ERA_R_CLAVICLE,ERA_R_UPPERARM},{ERA_R_UPPERARM,ERA_R_FOREARM},{ERA_R_FOREARM,ERA_R_HAND},
                {ERA_PELVIS,ERA_L_THIGH},{ERA_L_THIGH,ERA_L_CALF},{ERA_L_CALF,ERA_L_FOOT},
                {ERA_PELVIS,ERA_R_THIGH},{ERA_R_THIGH,ERA_R_CALF},{ERA_R_CALF,ERA_R_FOOT}};
            for(int j=0;j<ARRAY_COUNT(links);j++){int a=links[j][0],b=links[j][1];EraPoint p,q;if((e->bone_mask&(1u<<a))&&(e->bone_mask&(1u<<b))&&project_point(e->bones[a],width,height,&p)&&project_point(e->bones[b],width,height,&q))outlined_line(dc,(int)p.x,(int)p.y,(int)q.x,(int)q.y,color,1);}
        }
    }
}
static DWORD WINAPI reader_worker(void*unused){
    (void)unused;EraReader*reader=era_reader_create();EraFrame next={0};
    if(!reader){next.status=ERA_READ_FAILED;next.windows_error=ERROR_NOT_ENOUGH_MEMORY;EnterCriticalSection(&frame_lock);shared_frame=next;LeaveCriticalSection(&frame_lock);return 1;}
    while(WaitForSingleObject(stop_event,0)==WAIT_TIMEOUT){
        era_reader_poll(reader,&next);EnterCriticalSection(&frame_lock);shared_frame=next;LeaveCriticalSection(&frame_lock);
        if(WaitForSingleObject(stop_event,16)!=WAIT_TIMEOUT)break;
    }
    era_reader_destroy(reader);return 0;
}
static void set_menu_visible(int shown){
    if(shown&&!era_startup_can_show(&display_frame,GetTickCount64())){
        log_status(L"[MENU] Gesperrt: Prozesszugriff, lesbarer Modulheader und passender Build muessen bestaetigt sein.",display_frame.windows_error);
        HWND console=GetConsoleWindow();if(console){ShowWindow(console,SW_RESTORE);SetForegroundWindow(console);}return;
    }
    if(shown!=menu_shown)log_status(shown?L"[MENU] Geoeffnet nach verifiziertem Attach.":L"[MENU] Verborgen.",0);

    if(!shown){capturing_key=0;drag=-1;commit_config();ReleaseCapture();}
    menu_shown=shown;ShowWindow(menu_window,shown?SW_SHOW:SW_HIDE);if(shown){SetForegroundWindow(menu_window);InvalidateRect(menu_window,NULL,FALSE);}era_aim_reset(&aim_state);
}
static void slider_move(int index,int mouse_x){
    if(index<0||index>=hit_count||hits[index].kind!=3)return;
    Hit*h=&hits[index];const Setting*s=&settings[h->setting];int rail=h->r.right-h->r.left-16,off=CLAMP(mouse_x-h->r.left-5,0,rail);
    int value=s->min+off*(s->max-s->min)/MAX(1,rail);
    if(value!=*setting_value(h->setting)){*setting_value(h->setting)=value;config_dirty=1;InvalidateRect(menu_window,NULL,FALSE);}
}
static void capture_tick(void){
    if(!capturing_key)return;
    if(capture_release){if(!(GetAsyncKeyState(VK_LBUTTON)&0x8000))capture_release=0;return;}
    for(int key=1;key<255;key++)if(GetAsyncKeyState(key)&0x8000){if(key!=VK_ESCAPE&&key!=VK_INSERT&&key!=VK_F9){config.aim_key=key;config_dirty=1;commit_config();}capturing_key=0;InvalidateRect(menu_window,NULL,FALSE);break;}
}
static int esp_features_selected(void){
    return config.esp_box||config.esp_skeleton||config.esp_health||config.esp_shield||
        config.esp_names||config.esp_distance||config.esp_tracers||config.esp_head_dot;
}
static void timer_tick(void){
    EnterCriticalSection(&frame_lock);display_frame=shared_frame;LeaveCriticalSection(&frame_lock);
    /* Sample after the copy: a worker can publish a newer capture while the
       UI waits for frame_lock. Sampling first makes valid data look future-dated. */
    uint64_t now=GetTickCount64();double seconds=last_tick?(double)(now-last_tick)*0.001:0.016;last_tick=now;
    int transition=era_startup_update(&startup_state,&display_frame,now);
    if(transition==ERA_STARTUP_ATTACHED||transition==ERA_STARTUP_REPLACED){
        log_status(L"[ATTACH] Bestaetigt: Prozesshandle, lesbarer PE-Modulheader und Zielbuild. Das beweist noch keine lesbaren Spielerdaten.",0);
        set_menu_visible(1);
    }else if(transition==ERA_STARTUP_DETACHED){
        log_status(L"[ATTACH] Verbindung/Lesenachweis verloren. Menue und Overlay werden verborgen.",display_frame.windows_error);
        set_menu_visible(0);ShowWindow(overlay_window,SW_HIDE);
    }
    static uint64_t logged_module,heartbeat;static uint32_t logged_flags,logged_pid;
    if(display_frame.module_base!=logged_module||display_frame.attach_flags!=logged_flags||display_frame.pid!=logged_pid||now-heartbeat>=5000){
        logged_module=display_frame.module_base;logged_flags=display_frame.attach_flags;logged_pid=display_frame.pid;heartbeat=now;
        int targets=0,bones=0;for(int i=0;i<display_frame.count&&i<ERA_MAX_ENTITIES;i++){if(display_frame.entities[i].target_mask&(1U<<(unsigned)config.aim_part))targets++;if(display_frame.entities[i].bone_mask)bones++;}
        uint64_t age=display_frame.captured_ms<=now?now-display_frame.captured_ms:UINT64_MAX;
        wchar_t detail[1024];swprintf(detail,ARRAY_COUNT(detail),L"[STATE NEO] PID=%lu Modul=0x%llx Handle=%d Header=%d Build=%d | %ls | Age=%llums Kamera=%d Namen=%d Pawn=0x%llx Alive=%d Spieler=%d Zielmodus=%d Ziele=%d Knochen=%d | Aim=%d ESP=%d ESPAnzeigen=%d Menue=%d Fokus=%d Taste=%d Seq=%llu",
            (unsigned long)display_frame.pid,(unsigned long long)display_frame.module_base,!!(display_frame.attach_flags&ERA_ATTACH_PROCESS),!!(display_frame.attach_flags&ERA_ATTACH_MODULE),!!(display_frame.attach_flags&ERA_ATTACH_BUILD),era_status_text(display_frame.status),(unsigned long long)age,era_camera_valid(&display_frame.camera),display_frame.names_ready,(unsigned long long)display_frame.local_pawn,display_frame.local_alive,display_frame.count,config.aim_part,targets,bones,config.aim_enabled,config.esp_enabled,esp_features_selected(),menu_shown,GetForegroundWindow()==(HWND)display_frame.game_window,!!(GetAsyncKeyState(config.aim_key)&0x8000),(unsigned long long)display_frame.sequence);
        log_status(detail,display_frame.windows_error);
    }
    static uint32_t previous_pid;static uint64_t previous_pawn;
    if(previous_pid!=display_frame.pid||previous_pawn!=display_frame.local_pawn)era_aim_reset(&aim_state);
    previous_pid=display_frame.pid;previous_pawn=display_frame.local_pawn;
    static unsigned menu_refresh;if(menu_shown&&++menu_refresh>=15){menu_refresh=0;InvalidateRect(menu_window,NULL,FALSE);}
    static EraStatus logged=(EraStatus)-1;static DWORD logged_error=0;
    if(display_frame.status!=logged||display_frame.windows_error!=logged_error){logged=display_frame.status;logged_error=display_frame.windows_error;log_status(era_status_text(logged),logged_error);InvalidateRect(menu_window,NULL,FALSE);}
    int insert=(GetAsyncKeyState(VK_INSERT)&0x8000)!=0,f9=(GetAsyncKeyState(VK_F9)&0x8000)!=0;
    if(!capturing_key){if(insert&&!insert_down)set_menu_visible(!menu_shown);if(f9&&!f9_down){if(menu_shown&&selected==1)set_menu_visible(0);else{selected=1;set_menu_visible(1);}}}
    insert_down=insert;f9_down=f9;capture_tick();
    RECT game_rect={0};int valid=fresh_frame(&display_frame,now)&&frame_window_rect(&display_frame,&game_rect);
    int show=startup_state.attached&&valid&&((config.esp_enabled&&esp_features_selected())||config.crosshair_enabled||config.aim_enabled);
    int reason=!startup_state.attached?0:!fresh_frame(&display_frame,now)?1:!frame_window_rect(&display_frame,&game_rect)?2:!show?3:4;
    static int overlay_reason=-1;if(reason!=overlay_reason){overlay_reason=reason;const wchar_t*reasons[]={L"[OVERLAY] Warte auf bestaetigtes Attach.",L"[OVERLAY] Keine aktuellen gueltigen Kamera-/Spielerdaten.",L"[OVERLAY] Spielfenster fehlt, ist minimiert oder hat keinen Fokus.",L"[OVERLAY] Keine Anzeige ausgewaehlt: Master und Unteranzeigen pruefen.",L"[OVERLAY] Anzeigen aktiv; Spielwirkung separat pruefen."};log_status(reasons[reason],0);}

    if(show){
        static RECT previous={0};if(!EqualRect(&game_rect,&previous)){SetWindowPos(overlay_window,HWND_TOPMOST,game_rect.left,game_rect.top,game_rect.right-game_rect.left,game_rect.bottom-game_rect.top,SWP_NOACTIVATE);previous=game_rect;}
        ShowWindow(overlay_window,SW_SHOWNOACTIVATE);InvalidateRect(overlay_window,NULL,FALSE);
    }else ShowWindow(overlay_window,SW_HIDE);
    static int esp_warning=-1;int empty_esp=config.esp_enabled&&!esp_features_selected();
    if(empty_esp!=esp_warning){esp_warning=empty_esp;if(empty_esp)log_status(L"[ESP] Master ist EIN, aber alle Unteranzeigen sind AUS. Zum Beispiel Box, Namen oder Linien einschalten.",0);}
    EraMotion motion={0};int held=(GetAsyncKeyState(config.aim_key)&0x8000)!=0;
    int active=valid&&!menu_shown&&display_frame.local_alive&&!capturing_key&&held;
    int has_target=era_aim_update(&display_frame,&config,&aim_state,game_rect.right-game_rect.left,game_rect.bottom-game_rect.top,CLAMP(seconds,0.001,0.05),active,&motion);
    int aim_reason=!config.aim_enabled?0:!startup_state.attached?1:!fresh_frame(&display_frame,now)?2:!valid?3:menu_shown||capturing_key?4:!display_frame.local_alive?5:!held?6:!has_target?7:8;
    static int logged_aim=-1;if(aim_reason!=logged_aim){logged_aim=aim_reason;const wchar_t*messages[]={L"[AIM] Aus.",L"[AIM] Warte auf Prozessanbindung.",L"[AIM] Gesperrt: Kamera-/Spielerdaten fehlen oder Aufnahme ist zu alt.",L"[AIM] Gesperrt: Spielfenster fehlt/minimiert oder nicht fokussiert.",L"[AIM] Menue/Tastenaufnahme schliessen (INSERT/ESC).",L"[AIM] Lokaler Spieler nicht als lebend bestaetigt; Health-/Pawn-Daten pruefen.",L"[AIM] Gewaehlte Zieltaste halten.",L"[AIM] Kein passendes Ziel: Zielpunkte, Teamfilter, Entfernung und Zielbereich pruefen.",L"[AIM] Ziel berechnet; Eingabeuebernahme im Spiel nicht bestaetigt."};log_status(messages[aim_reason],display_frame.windows_error);}
    if(has_target&&(motion.dx||motion.dy)){
        INPUT input={0};input.type=INPUT_MOUSE;input.mi.dx=motion.dx;input.mi.dy=motion.dy;input.mi.dwFlags=MOUSEEVENTF_MOVE;
        /* SendInput may fail without setting LastError. Discard stale errors. */
        SetLastError(ERROR_SUCCESS);
        if(SendInput(1,&input,sizeof(input))!=1){static uint64_t reported;if(now-reported>3000){reported=now;log_status(L"Mauseingabe nicht uebernommen",GetLastError());notify(L"Mauseingabe wurde von Windows nicht uebernommen");}era_aim_reset(&aim_state);}
    }

}
static LRESULT CALLBACK overlay_proc(HWND hwnd,UINT message,WPARAM wp,LPARAM lp){
    if(message==WM_NCHITTEST)return HTTRANSPARENT;
    if(message==WM_MOUSEACTIVATE)return MA_NOACTIVATE;
    if(message==WM_ERASEBKGND)return 1;
    if(message==WM_PAINT){PAINTSTRUCT ps;HDC target=BeginPaint(hwnd,&ps);RECT r;GetClientRect(hwnd,&r);
        if(canvas_prepare(&overlay_canvas,target,r.right,r.bottom)){draw_overlay(overlay_canvas.dc,r.right,r.bottom);BitBlt(target,0,0,r.right,r.bottom,overlay_canvas.dc,0,0,SRCCOPY);}else{SetDCBrushColor(target,C_KEY);FillRect(target,&r,(HBRUSH)GetStockObject(DC_BRUSH));}
        EndPaint(hwnd,&ps);return 0;}
    return DefWindowProcW(hwnd,message,wp,lp);
}
static LRESULT CALLBACK menu_proc(HWND hwnd,UINT message,WPARAM wp,LPARAM lp){
    if(message==WM_APP+3)return ERA_DESKTOP_PROTOCOL;
    if(message==WM_APP+2){log_status(L"[EXIT] Beenden ueber Konsole angefordert.",0);DestroyWindow(hwnd);return 0;}

    if(message==WM_APP+1){set_menu_visible(1);return 0;}
    if(message==WM_ERASEBKGND)return 1;
    if(message==WM_GETMINMAXINFO){MINMAXINFO*info=(MINMAXINFO*)lp;info->ptMinTrackSize=(POINT){1040,700};return 0;}
    if(message==WM_TIMER&&wp==MENU_TIMER){timer_tick();return 0;}
    if(message==WM_PAINT){PAINTSTRUCT ps;HDC target=BeginPaint(hwnd,&ps);RECT r;GetClientRect(hwnd,&r);
        if(canvas_prepare(&menu_canvas,target,r.right,r.bottom)){draw_menu(menu_canvas.dc,r.right,r.bottom);BitBlt(target,0,0,r.right,r.bottom,menu_canvas.dc,0,0,SRCCOPY);}else FillRect(target,&r,(HBRUSH)GetStockObject(BLACK_BRUSH));
        EndPaint(hwnd,&ps);return 0;}
    if(message==WM_SIZE){InvalidateRect(hwnd,NULL,FALSE);return 0;}
    if(message==WM_KEYDOWN&&wp==VK_ESCAPE){if(capturing_key){capturing_key=0;InvalidateRect(hwnd,NULL,FALSE);}else set_menu_visible(0);return 0;}
    if(message==WM_MOUSEWHEEL){POINT p={GET_X_LPARAM(lp),GET_Y_LPARAM(lp)};ScreenToClient(hwnd,&p);if(p.x>=212){scroll[selected]=CLAMP(scroll[selected]-GET_WHEEL_DELTA_WPARAM(wp)/3,0,scroll_max[selected]);drag=-1;commit_config();InvalidateRect(hwnd,NULL,FALSE);}return 0;}
    if(message==WM_LBUTTONDOWN){
        int x=GET_X_LPARAM(lp),y=GET_Y_LPARAM(lp);RECT client;GetClientRect(hwnd,&client);
        for(int i=hit_count-1;i>=0;i--){Hit*h=&hits[i];if(!inside(&h->r,x,y))continue;if(h->kind!=7&&(y<124||y>=client.bottom-43))continue;
            if(h->kind==7){commit_config();selected=h->value;capturing_key=0;drag=-1;InvalidateRect(hwnd,NULL,FALSE);}
            else if(h->kind==1){*setting_value(h->setting)=!*setting_value(h->setting);config_dirty=1;commit_config();}
            else if(h->kind==2){capturing_key=!capturing_key;capture_release=1;InvalidateRect(hwnd,NULL,FALSE);}
            else if(h->kind==3){drag=i;SetCapture(hwnd);slider_move(i,x);}
            else if(h->kind==4){profile_slot=h->value;InvalidateRect(hwnd,NULL,FALSE);}
            else if(h->kind==5)profile_action(h->value);
            else if(h->kind==6)ShellExecuteW(hwnd,L"open",log_file,NULL,NULL,SW_SHOWNORMAL);
            break;
        }return 0;
    }
    if(message==WM_MOUSEMOVE&&drag>=0){slider_move(drag,GET_X_LPARAM(lp));return 0;}
    if(message==WM_LBUTTONUP){drag=-1;commit_config();ReleaseCapture();return 0;}
    if(message==WM_CAPTURECHANGED||message==WM_CANCELMODE){drag=-1;commit_config();return 0;}
    if(message==WM_CLOSE){DestroyWindow(hwnd);return 0;}
    if(message==WM_DESTROY){closing=1;KillTimer(hwnd,MENU_TIMER);commit_config();if(stop_event)SetEvent(stop_event);if(overlay_window)ShowWindow(overlay_window,SW_HIDE);PostQuitMessage(0);return 0;}
    return DefWindowProcW(hwnd,message,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,PWSTR command,int show){
    (void)previous;(void)command;(void)show;
    log_status(L"[BOOT] STELEX NEO | Testbuild 1",0);

    single_instance=CreateMutexW(NULL,FALSE,L"Local\\STELEX_NEO_1040_DESKTOP");
    if(!single_instance){log_status(L"[ERROR] Instanzverwaltung fehlgeschlagen.",GetLastError());return 1;}
    if(GetLastError()==ERROR_ALREADY_EXISTS){
        HWND existing=FindWindowW(L"STELEX_NEO_1040_MENU",NULL);DWORD_PTR reply=0;
        if(!existing||!SendMessageTimeoutW(existing,WM_APP+3,0,0,SMTO_ABORTIFHUNG,1000,&reply)||reply!=ERA_DESKTOP_PROTOCOL){
            log_status(L"[ERROR] Alte, inkompatible oder noch startende Neo-Instanz blockiert den Start. Alle alten STELEX_NEO_1040.exe beenden.",ERROR_ALREADY_EXISTS);
            MessageBoxW(NULL,L"Eine alte oder noch startende Neo-Instanz blockiert den Start. Alte STELEX_NEO_1040.exe beenden und START.cmd erneut starten.",L"STELEX NEO - Versionskonflikt",MB_ICONWARNING);
            CloseHandle(single_instance);return ERROR_ALREADY_EXISTS;
        }
        PostMessageW(existing,WM_APP+1,0,0);log_status(L"[INFO] Passende Instanz benachrichtigt; deren Konsole zeigt den aktuellen Status.",0);CloseHandle(single_instance);return 0;
    }
    SetProcessDPIAware();
    if(!init_paths()){log_status(L"[ERROR] Lokaler Protokoll-/Konfigurationsordner fehlt oder ist nicht schreibbar.",GetLastError());MessageBoxW(NULL,L"Lokaler Konfigurationsordner konnte nicht angelegt werden.",L"STELEX NEO",MB_OK|MB_ICONERROR);CloseHandle(single_instance);return 2;}
    era_config_defaults(&config);load_settings(config_file,0);config.aim_enabled=0;config.esp_enabled=0;config.crosshair_enabled=0;
    wcscpy(notice,L"INSERT: Menue | F9: Visual ESP | Mausrad: scrollen");
    log_status(L"[START] STELEX NEO 10.40-CL-9380822 | Testbuild 1 - Speichern und Aktivierung",0);
    log_status(log_file,0);log_status(L"[WAIT] Projekt Neo normal starten. Menue bleibt bis zum bestaetigten Attach verborgen. STRG+C oder Konsolen-X beendet das Tool.",0);log_config();
    InitializeCriticalSection(&frame_lock);stop_event=CreateEventW(NULL,TRUE,FALSE,NULL);
    if(!stop_event){log_status(L"[ERROR] Stop-Ereignis konnte nicht angelegt werden.",GetLastError());DeleteCriticalSection(&frame_lock);CloseHandle(single_instance);return 3;}
    font_regular=CreateFontW(18,0,0,0,400,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    font_bold=CreateFontW(19,0,0,0,650,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    font_small=CreateFontW(15,0,0,0,400,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    font_brand=CreateFontW(29,0,0,0,700,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    if(!font_regular)font_regular=(HFONT)GetStockObject(DEFAULT_GUI_FONT);if(!font_bold)font_bold=(HFONT)GetStockObject(DEFAULT_GUI_FONT);if(!font_small)font_small=(HFONT)GetStockObject(DEFAULT_GUI_FONT);if(!font_brand)font_brand=(HFONT)GetStockObject(DEFAULT_GUI_FONT);
    WNDCLASSEXW cls={0};cls.cbSize=sizeof(cls);cls.hInstance=instance;cls.hCursor=LoadCursorW(NULL,IDC_ARROW);cls.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(101));if(!cls.hIcon)cls.hIcon=LoadIconW(NULL,IDI_APPLICATION);cls.hIconSm=cls.hIcon;cls.lpfnWndProc=menu_proc;cls.lpszClassName=L"STELEX_NEO_1040_MENU";
    int result=0;DWORD startup_error=0;const wchar_t*startup_stage=L"[ERROR] Start fehlgeschlagen.";
    if(!RegisterClassExW(&cls)){startup_error=GetLastError();startup_stage=L"[ERROR] Menue-Fensterklasse nicht registriert.";result=4;goto cleanup;}
    cls.lpfnWndProc=overlay_proc;cls.lpszClassName=L"STELEX_NEO_1040_OVERLAY";if(!RegisterClassExW(&cls)){startup_error=GetLastError();startup_stage=L"[ERROR] Overlay-Fensterklasse nicht registriert.";result=4;goto cleanup;}
    RECT work;int menu_width=1120,menu_height=790,menu_x=100,menu_y=70;
    if(SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0)){
        if(menu_width>work.right-work.left)menu_width=work.right-work.left;
        if(menu_height>work.bottom-work.top)menu_height=work.bottom-work.top;
        menu_x=work.left+(work.right-work.left-menu_width)/2;menu_y=work.top+(work.bottom-work.top-menu_height)/2;
    }
    menu_window=CreateWindowExW(WS_EX_APPWINDOW,L"STELEX_NEO_1040_MENU",L"STELEX NEO | 10.40-CL-9380822 | Testbuild 1",WS_OVERLAPPEDWINDOW,menu_x,menu_y,menu_width,menu_height,NULL,NULL,instance,NULL);
    if(!menu_window){startup_error=GetLastError();startup_stage=L"[ERROR] Menue-Fenster konnte nicht angelegt werden.";result=5;goto cleanup;}
    overlay_window=CreateWindowExW(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,L"STELEX_NEO_1040_OVERLAY",L"STELEX NEO Overlay",WS_POPUP,0,0,1,1,NULL,NULL,instance,NULL);
    if(!overlay_window){startup_error=GetLastError();startup_stage=L"[ERROR] Overlay-Fenster konnte nicht angelegt werden.";result=5;goto cleanup;}
    if(!SetLayeredWindowAttributes(overlay_window,C_KEY,255,LWA_COLORKEY)){startup_error=GetLastError();startup_stage=L"[ERROR] Overlay-Transparenz konnte nicht eingerichtet werden.";result=5;goto cleanup;}
    worker_handle=CreateThread(NULL,0,reader_worker,NULL,0,NULL);if(!worker_handle){startup_error=GetLastError();startup_stage=L"[ERROR] Reader-Thread konnte nicht gestartet werden.";result=6;goto cleanup;}
    if(!SetTimer(menu_window,MENU_TIMER,16,NULL)){startup_error=GetLastError();startup_stage=L"[ERROR] Fenstertimer konnte nicht gestartet werden.";result=7;goto cleanup;}
    insert_down=(GetAsyncKeyState(VK_INSERT)&0x8000)!=0;f9_down=(GetAsyncKeyState(VK_F9)&0x8000)!=0;
    ShowWindow(menu_window,SW_HIDE);UpdateWindow(menu_window);
    log_status(L"[WAIT] Konsole und Reader laufen; Menue ist bis zum Attach gesperrt.",0);
    if(InterlockedCompareExchange(&console_stop,0,0))PostMessageW(menu_window,WM_APP+2,0,0);
    MSG message;int received;while((received=GetMessageW(&message,NULL,0,0))>0){TranslateMessage(&message);DispatchMessageW(&message);}if(received<0){startup_error=GetLastError();startup_stage=L"[ERROR] Fenster-Nachrichtenschleife fehlgeschlagen.";result=8;}
cleanup:
    if(result){log_status(startup_stage,startup_error);MessageBoxW(NULL,L"Start fehlgeschlagen. Protokoll unter LocalAppData\\STELEX_NEO_1040\\runtime.log.",L"STELEX NEO",MB_OK|MB_ICONERROR);}
    if(stop_event)SetEvent(stop_event);if(worker_handle){WaitForSingleObject(worker_handle,INFINITE);CloseHandle(worker_handle);}
    if(menu_window&&IsWindow(menu_window)&&!closing)DestroyWindow(menu_window);if(overlay_window&&IsWindow(overlay_window))DestroyWindow(overlay_window);
    canvas_close(&menu_canvas);canvas_close(&overlay_canvas);
    for(int i=0;i<ARRAY_COUNT(cached_pens);i++)if(cached_pens[i].handle)DeleteObject(cached_pens[i].handle);
    HFONT fallback=(HFONT)GetStockObject(DEFAULT_GUI_FONT);if(font_regular&&font_regular!=fallback)DeleteObject(font_regular);if(font_bold&&font_bold!=fallback)DeleteObject(font_bold);if(font_small&&font_small!=fallback)DeleteObject(font_small);if(font_brand&&font_brand!=fallback)DeleteObject(font_brand);
    if(stop_event)CloseHandle(stop_event);DeleteCriticalSection(&frame_lock);if(single_instance)CloseHandle(single_instance);log_status(L"[EXIT] Worker und Fenster beendet.",0);return result;
}

/* Console subsystem creates a console before this entry runs when launched
   from Explorer; an existing terminal keeps its normal output redirection. */
int wmain(void){
    InitializeCriticalSection(&log_lock);
    DWORD console_pid=0;int console_available=GetConsoleWindow()!=NULL||GetConsoleProcessList(&console_pid,1)>0;
    if(!console_available){
        HANDLE device=CreateFileW(L"CONOUT$",GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
        if(device!=INVALID_HANDLE_VALUE){console_available=1;CloseHandle(device);}
    }
    if(!console_available&&!AllocConsole()){
        DWORD error=GetLastError();log_status(L"[ERROR] Startkonsole konnte nicht erzeugt werden.",error);
        MessageBoxW(NULL,L"Startkonsole konnte nicht erzeugt werden. START.cmd verwenden.",L"STELEX NEO",MB_ICONERROR);DeleteCriticalSection(&log_lock);return 10;
    }
    SetConsoleTitleW(L"STELEX NEO | 10.40-CL-9380822 | Testbuild 1 | Verbindung und Logs");SetConsoleOutputCP(CP_UTF8);
    shutdown_complete=CreateEventW(NULL,TRUE,FALSE,NULL);
    if(!shutdown_complete||!SetConsoleCtrlHandler(console_control,TRUE)){log_status(L"[ERROR] Konsolen-Beenden konnte nicht eingerichtet werden.",GetLastError());DeleteCriticalSection(&log_lock);return 11;}
    int result=wWinMain(GetModuleHandleW(NULL),NULL,GetCommandLineW(),SW_HIDE);
    SetEvent(shutdown_complete);SetConsoleCtrlHandler(console_control,FALSE);DeleteCriticalSection(&log_lock);return result;
}
