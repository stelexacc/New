#ifndef STELEX_ERA_SNAPSHOT_H
#define STELEX_ERA_SNAPSHOT_H
#include <stddef.h>
#include "era_types.h"
typedef int (*EraReadMemory)(void*context,uint64_t address,void*output,size_t bytes);
typedef struct EraSnapshotReader EraSnapshotReader;
/* The caller verifies executable identity and owns the process handle. A read
   callback succeeds only when every requested byte was read. No writes occur. */
EraSnapshotReader*era_snapshot_create(EraReadMemory read,void*context,uint64_t module_base);
void era_snapshot_destroy(EraSnapshotReader*reader);
/* Game fields are replaced on every call. Platform metadata is preserved. */
EraStatus era_snapshot_step(EraSnapshotReader*reader,EraFrame*frame);
#endif
