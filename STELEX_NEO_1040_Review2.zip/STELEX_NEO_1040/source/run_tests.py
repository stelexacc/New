"""Run bounded portable tests. These do not start Windows or connect to Fortnite."""
from __future__ import annotations
import argparse,json,os,shlex,subprocess,tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sanitize',action='store_true')
    args=parser.parse_args();results=[]
    env=os.environ.copy()
    if args.sanitize:
        env['ASAN_OPTIONS']='detect_leaks=0'
        env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
    compiler=shlex.split(env.get('CC','gcc'))
    def run(name:str,command:list[str])->bool:
        try:
            result=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True,timeout=120)
            row={'name':name,'passed':result.returncode==0,'exit_code':result.returncode,
                 'stdout':result.stdout,'stderr':result.stderr}
        except (OSError,subprocess.TimeoutExpired) as error:row={'name':name,'passed':False,'error':str(error)}
        results.append(row);print(('PASS ' if row['passed'] else 'FAIL ')+name,flush=True)
        for stream in ['stdout','stderr','error']:
            if row.get(stream):print(row[stream].rstrip(),flush=True)
        return row['passed']
    with tempfile.TemporaryDirectory(prefix='neo1040-tests-') as temporary:
        for suite in ['core','snapshot','identity','startup','memory']:
            executable=str(Path(temporary)/suite)
            flags=['-std=c11','-Wall','-Wextra','-Werror','-pedantic','-g']
            if args.sanitize:flags+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
            sources=[str(ROOT/'source/era_core.c'),str(ROOT/'tests'/('test_'+suite+'.c'))]
            if suite=='snapshot':sources.append(str(ROOT/'source/era_snapshot.c'))
            if suite=='identity':sources.append(str(ROOT/'source/era_identity.c'))
            if suite=='startup':sources.append(str(ROOT/'source/era_startup.c'))
            if suite=='memory':
                flags+=['-D_WIN32','-fshort-wchar','-I'+str(ROOT/'tests/win32_stub')]
                sources=[str(ROOT/'source/era_memory.c'),str(ROOT/'source/era_identity.c'),str(ROOT/'tests/test_memory.c')]
            if run('compile '+suite,compiler+flags+sources+['-lm','-o',executable]):run(suite,[executable])
    report={'passed':all(row['passed'] for row in results),'sanitizers':args.sanitize,
            'windows_started':False,'live_fortnite_validated':False,'checks':results}
    (ROOT/'research/TEST_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
