OVERLAYBUILD 4: Zuerst START_HIER_DE.txt lesen. Neuer Zielkreis-Schalter und Client-Bericht sind dort beschrieben.

STELEX NEO 10.40-CL-9380822 - Testbuild 1
======================================

START
1. Alte Neo-Tool-Instanzen schliessen. ZIP vollstaendig in einen neuen,
   schreibbaren Ordner entpacken und START.cmd oeffnen.
2. Die Konsole zeigt Verbindungsstatus und laufende Logs. Neo wie gewohnt
   starten und einer Runde beitreten.
3. Das Menue oeffnet erst bei bestaetigtem Prozesszugriff, lesbarem Modulheader
   und passender Buildkennung. INSERT oeffnet/schliesst es; F9 zeigt Visual ESP.
4. Aimbot einschalten, Zielpunkt/Taste waehlen, Menue schliessen und die
   Zieltaste bei fokussiertem Spiel halten. Standard: Hals und rechte Maustaste.
   Fuer das Overlay Fenster- oder rahmenlosen Fenstermodus verwenden.
5. Fuer ESP den Hauptschalter UND eine Unteranzeige einschalten, etwa Linien,
   Entfernung oder Boxen. Der Hauptschalter allein zeichnet nichts.

Aim, ESP und Fadenkreuz starten ausgeschaltet. Die Konsole bleibt auch nach
Oeffnen des Menues aktiv. STRG+C beendet das Tool. Einstellungen/Profile
werden unter %LOCALAPPDATA%\STELEX_NEO_1040 gespeichert. Derselbe Ordner
enthaelt runtime.log; DIAGNOSE.cmd sammelt die letzten Meldungen in eine TXT.

WAS UEBERTRAGEN WURDE
Eigenes Neo-Programm mit eigener Konfiguration und Instanzkennung; ERA bleibt
unveraendert. Das Menue enthaelt Aimbot mit Kopf/Hals/Brust, Zieltaste,
Zielbereich, Glaettung, Mausverstaerkung, Teamfilter und einstellbarem Hard Lock;
Visual ESP mit Boxen, Skelett, HP/Schild, Namen, Entfernung, Linien von unten
und Kopfpunkt; Fadenkreuz mit Form, Farbe, Kontur und Staerke; drei Profile.

Die Spieler-, Kamera-, Team-, Gesundheits- und Posefelder stammen aus dem
passenden SDK 4.23.0-9380822+++Fortnite+Release-10.40. Dein Dateibericht zeigt
den separaten Namenscontainer mit 16384 Eintraegen je Chunk und Tabelle bei
Container+0xB8. Die alte ERA-Namensadresse wird nicht mehr verwendet.

Der gelesene AppendString-Aufruf begrenzt die Suche auf den Namenscontainer-
Getter. Das Tool liest dessen Code; es ruft die fremde Funktion nicht auf.
Eine Kandidatenadresse wird erst mit fuenf festen Anfangsnamen, eindeutiger
Struktur und stabilen Zeigerlesungen verwendet. Namen=1 in [STATE NEO] zeigt,
dass diese Pruefung in der aktuellen Aufnahme bestanden wurde.

DIAGNOSE
[STATE NEO] nennt Prozess/Modul/Build, Namen, Kamera, lokalen Pawn,
Spieler-/Zielpunkt-/Knochenanzahl, Aufnahmealter, Fokus, Menue und Zieltaste.
[AIM] nennt die jeweilige Aktivierungssperre. Namen=0 bzw. die Meldung zum
Namenspool bedeuten, dass Code, Zugriff oder Anfangseintraege nicht passen.
Fehlende gepruefte Posen ergeben keine geratenen Ersatz-Zielpunkte. Linien,
Namen und Entfernung koennen mit gueltigen Wurzelpositionen gezeichnet werden;
Boxen und Skelett benoetigen die jeweiligen geprueften Knochen.
Win32=5 zeigt einen verweigerten Windows-Lesezugriff; dann fehlen Spielerdaten.

PRUEFUNG UND GRENZEN
Hosttests mit ASan/UBSan: research/TEST_RESULTS.json. Sie pruefen Decoder,
Namenscontainer-Kandidaten, Verluste/Wiederanbindung, Zielauswahl und die
Verbindung vom dekodierten Hals-Zielpunkt zur berechneten Bewegung.
Weitere Berichte unterscheiden echte Win32-Dateioperationen unter Wine,
den tatsaechlichen Konsolenstart und separate simulierte Menuefreigaben.
Eine simulierte Speicherabbildung ist kein laufender Neo-Client.

Dieser Testbuild wurde hier nicht in einer echten Neo-Runde ausgefuehrt.
Zugriff auf deinen laufenden Client, Pose-Aktualitaet, Zielbewegung und die
Annahme von Eingaben durch Neo sind weiterhin nicht live bestaetigt.
Es gibt deshalb keine Zusage fuer Fehlerfreiheit oder Trefferlage. Der
Prozess wird ueber normale Windows-Lesezugriffe gelesen; das Tool enthaelt
keinen Treiber und keine Fernaufrufe in den Client.

QUELLEN UND BUILD
research/SDK_FACTS.json und SDK_SOURCE_RESEARCH.json dokumentieren gepinnte
SDK-Metadaten. CLIENT_NAME_LAYOUT.json trennt statische Berichtsbelege von
Pruefungen, die erst am laufenden Client bestaetigt werden koennen. Der
vollstaendige hochgeladene Client-Codeauszug wird nicht mitverteilt.

Python 3.10+ und Zig 0.15.2:
  python source/build.py --zig PFAD_ZU_ZIG
Hosttests mit GCC:
  python source/run_tests.py --sanitize
