@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "STELEX_PROBE_ROOT=%~dp0"
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; $dir=Join-Path $env:STELEX_PROBE_ROOT 'ClientProbeV2'; $probe=Join-Path $dir 'NEO_Client_Probe.exe'; if(!(Test-Path -LiteralPath $probe -PathType Leaf)){throw 'ClientProbeV2\NEO_Client_Probe.exe fehlt. ZIP vollstaendig entpacken.'}; $expected='763a8c93ec4f631fe5e8b094766333a5fb668684613bfa552db795ef28a5cb33'; if((Get-FileHash -LiteralPath $probe -Algorithm SHA256).Hash -ne $expected){throw 'SHA-256 der Client Probe stimmt nicht. Bitte die vollstaendige unveraenderte ZIP neu entpacken.'}; $paths=@(Get-Process -Name 'FortniteClient-Win64-Shipping' -ErrorAction SilentlyContinue | ForEach-Object { $stream=$null; try { $candidate=$_.Path; if($candidate -and ([IO.Path]::GetFileName($candidate) -ieq 'FortniteClient-Win64-Shipping.exe') -and (Test-Path -LiteralPath $candidate -PathType Leaf)){ $stream=[IO.File]::Open($candidate,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)); $candidate } } catch {} finally { if($null -ne $stream){$stream.Dispose()} } } | Sort-Object -Unique); if($paths.Count -eq 1){Write-Host 'Offline-Bericht fuer den gefundenen Client wird erstellt.'; & $probe $paths[0]}else{Write-Host 'Clientdatei im folgenden Dateidialog auswaehlen (nicht den Launcher).'; & $probe '--choose-file'}; exit $LASTEXITCODE"
set "STELEX_PROBE_CODE=%ERRORLEVEL%"
if not "%STELEX_PROBE_CODE%"=="0" (
  echo.
  echo Client-Bericht konnte nicht gestartet werden. Die Fehlermeldung steht oben.
  pause
)
exit /b %STELEX_PROBE_CODE%
