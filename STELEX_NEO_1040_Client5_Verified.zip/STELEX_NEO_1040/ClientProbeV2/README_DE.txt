NEO CLIENT PROBE V2 - lokale Dateipruefung
========================================

1. ZIP vollstaendig in einen schreibbaren Ordner entpacken.
2. NEO_Client_Probe.exe starten und "Clientdatei pruefen" anklicken.
3. Im Neo-Spielordner FortniteClient-Win64-Shipping.exe auswaehlen.
   Bitte die eigentliche Clientdatei waehlen, nicht den Neo-Launcher.
4. Die neue TXT-Datei mit _v2_ im Namen aus Reports neben der Probe-EXE
   weitergeben. Im Fenstertitel muss Client Probe v2 stehen.

Alternativ die Clientdatei ins Fenster ziehen oder als einziges
Kommandozeilenargument uebergeben. Die ausgewaehlte Datei wird ausschliesslich
als Daten gelesen. Sie wird nicht gestartet oder veraendert.

Der Bericht enthaelt Dateiname, SHA-256, Dateigroesse, PE-Metadaten, Sektionen
und drei explizit begrenzte statische Codefenster. Der Bezug fuer das erste
Fenster ist das oeffentliche SDK fuer 10.40-CL-9380822: AppendString RVA
0x0214EC80. Die beiden Zusatzfenster dokumentieren zuvor fehlende Abschnitte:

  Start-RVA     Laenge       Letzte RVA (einschliesslich)
  0x0214E000    0x4000       0x02151FFF
  0x02152D00    0x0400       0x021530FF
  0x017B1900    0x2000       0x017B38FF

Zusammen sind das genau 25 KiB Datei-Bytes. Jedes Fenster wird nur erfasst,
wenn es eindeutig und vollstaendig in einer ausfuehrbaren AMD64-PE32+-Sektion
mit echten Datei-Bytes liegt. Fehlende Fenster erhalten WINDOW_UNAVAILABLE;
andere gueltige Fenster koennen trotzdem im Bericht stehen. Nur wenn alle
drei Fenster vollstaendig sind, endet der Bericht mit NEO_PROBE_V2_COMPLETE.
Die Zusatzfenster werden keinen internen Variablen automatisch zugeordnet.

Eine RVA ist ein relativer Dateibezug zur Image-Basis, keine gemessene Adresse
eines laufenden Spiels. Der Bericht bestaetigt weder den Client-Build noch
Namenpool oder Spiel-Offsets. Das Tool ist eine separate Diagnosehilfe.
Es gibt keine Anbindung an laufende Prozesse und keine Netzwerkfunktion.

Die V2-Dateinamen enthalten _v2_; fruehere Reports werden nicht ersetzt.
Berichte bleiben unter 150 KiB. Maximal 1 GiB Eingabedatei, 96 Sektionen.
Bei fehlenden Schreibrechten das Tool in einen eigenen Ordner verschieben.
Die TXT-Datei kann ueber "TXT oeffnen" oder "Kopieren" weitergegeben werden.
Beim Schliessen waehrend der Pruefung wird zuerst der Bericht fertiggestellt.

NEU BAUEN
Python 3.10+ und Zig 0.15.2 oder neuer:
  python source/build.py --zig PFAD_ZU_ZIG
Die EXE wird unter dist erzeugt. BUILD.cmd nutzt Zig aus dem PATH.

Die Quellreferenz fuer den SDK-Bezug steht in research/SCOPE_AND_REFERENCE.json.
Pruefberichte unterscheiden Hosttests, Wine-Start und echte Clientdaten.

GEBUENDELTER START
CLIENT_BERICHT.cmd im uebergeordneten STELEX-Ordner prueft die SHA-256
der Probe-EXE. Bei genau einem lesbaren Clientpfad aus den gewoehnlichen
Windows-Prozessmetadaten wird nur diese Datei offline analysiert. Andernfalls
oeffnet --choose-file direkt die Dateiauswahl. Der Launcher startet den
Spielclient nicht und fordert keine Administratorrechte an.
Den neuen _v2_-Bericht aus ClientProbeV2\Reports weitergeben.
