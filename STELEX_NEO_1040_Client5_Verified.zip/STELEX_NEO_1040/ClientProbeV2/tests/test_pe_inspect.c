#include "../source/pe_inspect.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static unsigned char image[4096];static char report[65536];
static void w16(unsigned at,unsigned value){image[at]=(unsigned char)value;image[at+1]=(unsigned char)(value>>8);}
static void w32(unsigned at,uint32_t value){for(unsigned i=0;i<4;i++)image[at+i]=(unsigned char)(value>>(i*8));}
static void w64(unsigned at,uint64_t value){for(unsigned i=0;i<8;i++)image[at+i]=(unsigned char)(value>>(i*8));}
static void fixture(int wide){
 memset(image,0,sizeof(image));image[0]='M';image[1]='Z';w32(60,0x80);w32(0x80,0x4550);w16(0x84,wide?0x8664:0x14c);w16(0x86,1);
 unsigned optional=wide?240:224;w16(0x94,optional);w16(0x98,wide?0x20b:0x10b);w32(0xa8,0x1000);
 if(wide)w64(0xb0,0x140000000ULL);else w32(0xb4,0x400000);
 w32(0xd0,0x2000);w32(0xd4,0x200);w32(wide?0x104:0xf4,16);
 unsigned s=0x98+optional;memcpy(image+s,".data",5);w32(s+8,0x800);w32(s+12,0x1000);w32(s+16,0x800);w32(s+20,0x200);w32(s+36,0xc0000040);
}
static unsigned dirs(int wide){return wide?0x108:0xf8;}
static void symbols(int wide){
 unsigned d=dirs(wide);w32(d,0x1100);w32(d+4,0x100);w32(d+8,0x1300);w32(d+12,40);
 /* Export function 0 is raw code/data, function 1 is a forwarder. */
 w32(0x310,1);w32(0x314,2);w32(0x318,1);w32(0x31c,0x1140);w32(0x320,0x1150);w32(0x324,0x1160);
 w32(0x340,0x1000);w32(0x344,0x1170);w32(0x350,0x1180);w16(0x360,0);memcpy(image+0x370,"OTHER.Forward",14);memcpy(image+0x380,"NamedExport",12);
 /* Normal import descriptor, its null terminator follows in the directory. */
 w32(0x500,0x1380);w32(0x50c,0x1360);w32(0x510,0x13c0);memcpy(image+0x560,"KERNEL32.dll",13);
 if(wide){w64(0x580,0x1400);w64(0x588,0x8000000000000007ULL);}else{w32(0x580,0x1400);w32(0x584,0x80000007);}
 w16(0x600,9);memcpy(image+0x602,"ExitProcess",12);
}
int main(void){
 assert(!pe_inspect(NULL,0,NULL,0));
 for(int wide=0;wide<2;wide++){
  fixture(wide);assert(pe_inspect(image,sizeof(image),report,sizeof(report)));assert(strstr(report,"EntryPoint RVA: 0x00001000 | Datei 0x00000200"));
  symbols(wide);assert(pe_inspect(image,sizeof(image),report,sizeof(report)));assert(strstr(report,"NamedExport | Ordinal 1"));assert(strstr(report,"OTHER.Forward"));assert(strstr(report,"KERNEL32.dll"));assert(strstr(report,"ExitProcess"));assert(strstr(report,"Ordinal 7"));assert(strstr(report,wide?"IAT RVA 0x000013C8":"IAT RVA 0x000013C4"));
  /* All truncations within the declared file-backed section must fail. */
  for(unsigned n=0;n<0xa00;n++)assert(!pe_inspect(image,n,report,sizeof(report)));
  /* Every output capacity preserves both canaries and a trailing zero. */
  for(unsigned n=0;n<128;n++){unsigned char guarded[130];memset(guarded,0xa5,sizeof(guarded));assert(pe_inspect(image,sizeof(image),(char*)guarded+1,n));assert(guarded[0]==0xa5&&guarded[n+1]==0xa5);if(n)assert(guarded[n]==0);}
  w16(0x360,2);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));w16(0x360,0);
  w32(0x350,0xfffffff0);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));w32(0x350,0x1180);
  w32(dirs(wide)+12,20);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));w32(dirs(wide)+12,40);
  w32(0x500,0xfffffff0);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));w32(0x500,0x1380);
  /* Bound IAT without original lookup can contain absolute addresses. */
  w32(0x500,0);if(wide)w64(0x5c0,0x7ff000001234ULL);else w32(0x5c0,0x70001234);assert(pe_inspect(image,sizeof(image),report,sizeof(report)));assert(strstr(report,"gebundener IAT-Wert"));
  fixture(wide);unsigned s=0x98+(wide?240:224);w32(s+20,0xfffffff0);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));
  fixture(wide);w32(60,0xfffffff0);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));
  fixture(wide);w16(0x86,97);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));
  fixture(wide);w32(wide?0x104:0xf4,0xffffffff);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));
  fixture(wide);w16(0x86,2);s=0x98+(wide?240:224);memcpy(image+s+40,image+s,40);assert(!pe_inspect(image,sizeof(image),report,sizeof(report)));
 }
 /* Deterministic mutation fuzzing exercises arbitrary fields without a game. */
 uint32_t seed=0xc001d00d;
 for(unsigned trial=0;trial<10000;trial++){
  fixture(trial&1);symbols(trial&1);
  for(unsigned n=0;n<8;n++){seed=seed*1664525+1013904223;unsigned off=seed%sizeof(image);seed=seed*1664525+1013904223;image[off]^=(unsigned char)(seed>>16);}
  int result=pe_inspect(image,sizeof(image),report,sizeof(report));assert(result==0||result==1);assert(memchr(report,0,sizeof(report))!=NULL);
 }
 puts("PASS: PE32/PE32+, named/ordinal imports, exports/forwarders, bound IAT, truncations, canaries, malformed ranges, 10000 mutations");return 0;
}
