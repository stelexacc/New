#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
int main(int argc,char **argv){
    if(argc!=3)return 2;
    FILE *out=fopen(argv[2],"wb");if(!out)return 3;
    HWND window=FindWindowW(L"NEO_CLIENT_PROBE_V2_OFFLINE",NULL);
    HWND picker=FindWindowW(L"#32770",L"Neo-Client auswaehlen: FortniteClient-Win64-Shipping.exe (nicht Launcher)");
    HWND editor=window?GetDlgItem(window,200):NULL;
    DWORD_PTR remote_length=0;
    if(editor)SendMessageTimeoutW(editor,WM_GETTEXTLENGTH,0,0,SMTO_ABORTIFHUNG,1000,&remote_length);
    int length=remote_length<160000?(int)remote_length:0,complete=0;
    if(length>0&&length<160000){
        wchar_t *text=calloc((size_t)length+1,sizeof(*text));
        if(text){DWORD_PTR copied=0;
            if(SendMessageTimeoutW(editor,WM_GETTEXT,(WPARAM)(length+1),(LPARAM)text,SMTO_ABORTIFHUNG,1000,&copied))complete=wcsstr(text,L"NEO_PROBE_V2_COMPLETE")!=NULL;
            free(text);}
    }
    fprintf(out,"{\"window_exists\":%s,\"window_visible\":%s,\"picker_visible\":%s,\"editor_chars\":%d,\"complete_in_editor\":%s}\n",window?"true":"false",window&&IsWindowVisible(window)?"true":"false",picker&&IsWindowVisible(picker)?"true":"false",length,complete?"true":"false");
    fclose(out);
    if(!strcmp(argv[1],"cancel")&&picker)PostMessageW(picker,WM_COMMAND,IDCANCEL,0);
    if(!strcmp(argv[1],"close")&&window)PostMessageW(window,WM_CLOSE,0,0);
    return window?0:4;
}
