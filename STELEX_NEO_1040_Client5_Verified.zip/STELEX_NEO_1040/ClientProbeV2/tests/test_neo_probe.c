#include "../source/pe_inspect.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HEADERS 0x1400U
#define FILE_BYTES 0x7800U
#define REPORT_BYTES (150U*1024U)
#define COMPLETE "NEO_PROBE_V2_COMPLETE"
#define INCOMPLETE "NEO_PROBE_V2_INCOMPLETE"

struct window { uint32_t rva,length,raw;unsigned mask; };
static const struct window windows[]={
    {0x0214E000U,0x4000U,0x1400U,0},
    {0x02152D00U,0x400U,0x5400U,0x80},
    {0x017B1900U,0x2000U,0x5800U,0x40}
};
static unsigned char image[FILE_BYTES+0x400],saved[FILE_BYTES+0x400];
static char report[REPORT_BYTES];
static unsigned assertions,failures,section_at;
#define CHECK(value) do { assertions++; if(!(value)) { \
    fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#value); failures++; \
} } while(0)

static void put16(unsigned char *p,unsigned at,unsigned value){
    p[at]=(unsigned char)value;p[at+1]=(unsigned char)(value>>8);
}
static void put32(unsigned char *p,unsigned at,uint32_t value){
    for(unsigned i=0;i<4;i++)p[at+i]=(unsigned char)(value>>(i*8));
}
static void w16(unsigned at,unsigned value){put16(image,at,value);}
static void w32(unsigned at,uint32_t value){put32(image,at,value);}
static void w64(unsigned at,uint64_t value){
    for(unsigned i=0;i<8;i++)image[at+i]=(unsigned char)(value>>(i*8));
}
static unsigned section(unsigned index){return section_at+index*40;}
static void fixture(int wide){
    memset(image,0,sizeof(image));image[0]='M';image[1]='Z';
    w32(60,0x80);w32(0x80,0x4550);w16(0x84,wide?0x8664:0x14c);w16(0x86,3);
    unsigned optional=wide?240:224;section_at=0x98+optional;
    w16(0x94,optional);w16(0x98,wide?0x20b:0x10b);w32(0xa8,windows[0].rva);
    if(wide)w64(0xb0,UINT64_C(0x140000000));else w32(0xb4,0x400000);
    w32(0xd0,0x02154000);w32(0xd4,HEADERS);w32(wide?0x104:0xf4,16);
    for(unsigned i=0;i<3;i++){
        unsigned s=section(i);memcpy(image+s,".text",5);image[s+5]=(unsigned char)('0'+i);
        w32(s+8,windows[i].length);w32(s+12,windows[i].rva);
        w32(s+16,windows[i].length);w32(s+20,windows[i].raw);w32(s+36,0x60000020);
        for(unsigned j=0;j<windows[i].length;j++)image[windows[i].raw+j]=(unsigned char)(j^windows[i].mask);
    }
}
static int probe(size_t bytes){
    memset(report,0xa5,sizeof(report));
    return neo_client_probe(image,bytes,report,sizeof(report));
}
static int has_row(uint32_t rva){
    char needle[32];snprintf(needle,sizeof(needle),"0x%08X:",rva);
    return strstr(report,needle)!=NULL;
}
static int has_window_marker(const char *kind,unsigned index){
    char needle[80];snprintf(needle,sizeof(needle),"%s RVA=0x%08X",kind,windows[index].rva);
    return strstr(report,needle)!=NULL;
}
static void expect_global_rejection(void){
    CHECK(!probe(FILE_BYTES));
    CHECK(strstr(report,COMPLETE)==NULL);
    CHECK(strstr(report,"BEGIN_STATIC_WINDOW")==NULL);
    for(unsigned i=0;i<3;i++){
        CHECK(!has_row(windows[i].rva));
        CHECK(!has_row(windows[i].rva+windows[i].length-16));
    }
}
static void expect_partial(unsigned missing){
    CHECK(!probe(FILE_BYTES));
    CHECK(strstr(report,COMPLETE)==NULL);
    CHECK(strstr(report,INCOMPLETE)!=NULL);
    for(unsigned i=0;i<3;i++){
        CHECK(has_row(windows[i].rva)==(i!=missing));
        CHECK(has_row(windows[i].rva+windows[i].length-16)==(i!=missing));
        CHECK(has_window_marker("BEGIN_STATIC_WINDOW",i)==(i!=missing));
        CHECK(has_window_marker("END_STATIC_WINDOW",i)==(i!=missing));
        CHECK(has_window_marker("WINDOW_UNAVAILABLE",i)==(i==missing));
    }
}
static void verify_success_text(void){
    CHECK(strstr(report,"NEO CLIENT PROBE V2")!=NULL);
    CHECK(strstr(report,"10.40-CL-9380822")!=NULL);
    CHECK(strstr(report,COMPLETE)!=NULL);
    CHECK(strstr(report,INCOMPLETE)==NULL);
    CHECK(strstr(report,"WINDOW_UNAVAILABLE")==NULL);
    for(unsigned i=0;i<3;i++){
        CHECK(has_window_marker("BEGIN_STATIC_WINDOW",i));
        CHECK(has_window_marker("END_STATIC_WINDOW",i));
        CHECK(has_row(windows[i].rva));
        CHECK(has_row(windows[i].rva+windows[i].length-16));
        CHECK(!has_row(windows[i].rva+windows[i].length));
    }
    CHECK(strstr(report,"0x0214E000: 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F")!=NULL);
    CHECK(strstr(report,"0x0214EC80: 80 81 82 83 84 85 86 87 88 89 8A 8B 8C 8D 8E 8F")!=NULL);
    CHECK(strstr(report,"0x02152D00: 80 81 82 83 84 85 86 87 88 89 8A 8B 8C 8D 8E 8F")!=NULL);
    CHECK(strstr(report,"0x017B1900: 40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F")!=NULL);
    CHECK(strstr(report,"IMPORTS")==NULL);CHECK(strstr(report,"EXPORTS")==NULL);
    unsigned rows=0;
    for(char *cursor=report;(cursor=strstr(cursor,"0x0"))!=NULL;cursor++)
        if(strlen(cursor)>10&&cursor[10]==':')rows++;
    CHECK(rows==(0x4000U+0x400U+0x2000U)/16);
}

int main(void){
    fixture(1);memcpy(saved,image,sizeof(image));
    CHECK(probe(FILE_BYTES));verify_success_text();
    CHECK(memcmp(saved,image,sizeof(image))==0);
    size_t full_length=strlen(report);CHECK(full_length+4096<REPORT_BYTES);

    /* Irrelevant import/export tables never add large symbol listings. */
    w32(0x108,0xfffffff0);w32(0x10c,0x4000);
    w32(0x110,0xfffffff0);w32(0x114,0x4000);
    CHECK(probe(FILE_BYTES));verify_success_text();

    /* An unavailable range must not suppress independent valid windows. */
    for(unsigned i=0;i<3;i++){
        fixture(1);w32(section(i)+36,0x40000040);expect_partial(i);
        fixture(1);w32(section(i)+12,windows[i].rva-0x100000);expect_partial(i);
        fixture(1);w32(section(i)+16,windows[i].length-1);expect_partial(i);
        fixture(1);w32(section(i)+8,windows[i].length-1);expect_partial(i);
        fixture(1);w32(section(i)+12,windows[i].rva+16);expect_partial(i);
        fixture(1);w32(section(i)+12,windows[i].rva-16);expect_partial(i);
        fixture(1);w32(section(i)+36,0x20000020);CHECK(probe(FILE_BYTES));
        fixture(1);w32(section(i)+8,0);CHECK(probe(FILE_BYTES));
    }

    /* A global malformed PE yields no window bytes at all. */
    fixture(1);w32(section(0)+12,0xfffff000);expect_global_rejection();
    fixture(1);w32(section(1)+20,0xfffffff0);expect_global_rejection();
    fixture(1);w32(section(2)+20,HEADERS-1);expect_global_rejection();
    fixture(1);w32(0xd0,windows[1].rva+windows[1].length-1);expect_global_rejection();
    fixture(1);w32(0xd0,0);expect_global_rejection();
    fixture(1);w16(0x84,0x14c);expect_global_rejection();
    fixture(1);w16(0x84,0xaa64);expect_global_rejection();
    fixture(0);expect_global_rejection();
    fixture(0);w16(0x84,0x8664);expect_global_rejection();
    fixture(1);w16(0x86,97);expect_global_rejection();
    fixture(1);w32(0xd4,section(2)+39);expect_global_rejection();
    fixture(1);w32(60,0xfffffff0);expect_global_rejection();

    /* Both virtual overlaps and duplicated raw spans are ambiguous. */
    fixture(1);w16(0x86,4);memcpy(image+section(3),image+section(0),40);expect_global_rejection();
    fixture(1);w16(0x86,4);memcpy(image+section(3),".extra",6);
    w32(section(3)+8,0x100);w32(section(3)+12,0x00100000);
    w32(section(3)+16,0x100);w32(section(3)+20,HEADERS);w32(section(3)+36,0x40000040);
    expect_global_rejection();
    fixture(1);w16(0x86,4);memcpy(image+section(3),".bss",4);
    w32(section(3)+8,0x100);w32(section(3)+12,windows[2].rva+0x100);
    w32(section(3)+36,0x40000040);expect_global_rejection();

    /* Adjacent sections cannot be joined to fake an individually mapped range. */
    fixture(1);w16(0x86,4);w32(section(0)+8,0x2000);w32(section(0)+16,0x2000);
    memcpy(image+section(3),image+section(0),40);
    w32(section(3)+12,windows[0].rva+0x2000);w32(section(3)+20,windows[0].raw+0x2000);
    expect_partial(0);

    /* All three may live in one executable section. A single bounded ~10MiB
       fixture covers the high-RVA gap without enlarging mutation fixtures. */
    fixture(1);
    uint32_t first=windows[2].rva,last=windows[1].rva+windows[1].length,span=last-first;
    size_t broad_size=(size_t)HEADERS+span;
    CHECK(broad_size<12U*1024U*1024U);
    unsigned char *broad=calloc(1,broad_size);CHECK(broad!=NULL);
    if(broad){
        memcpy(broad,image,HEADERS);put16(broad,0x86,1);
        put32(broad,0xa8,first);put32(broad,section(0)+8,span);
        put32(broad,section(0)+12,first);put32(broad,section(0)+16,span);
        put32(broad,section(0)+20,HEADERS);
        for(unsigned i=0;i<3;i++)memcpy(broad+HEADERS+windows[i].rva-first,image+windows[i].raw,windows[i].length);
        CHECK(neo_client_probe(broad,broad_size,report,sizeof(report)));verify_success_text();free(broad);
    }

    /* Maximum metadata with escaped 8-byte names plus app header allowance
       must remain below the promised 150KiB complete TXT budget. */
    fixture(1);w16(0x86,96);
    for(unsigned i=3;i<96;i++){
        for(unsigned j=0;j<8;j++)image[section(i)+j]=(unsigned char)(0x80+j);
        w32(section(i)+36,0xffffffff);
    }
    CHECK(probe(FILE_BYTES));verify_success_text();
    CHECK(strlen(report)+4096<REPORT_BYTES);

    /* Every truncation before the last declared raw byte is globally invalid. */
    fixture(1);
    for(size_t length=0;length<FILE_BYTES;length++){
        CHECK(!probe(length));CHECK(strstr(report,"BEGIN_STATIC_WINDOW")==NULL);
    }
    CHECK(probe(FILE_BYTES));
    CHECK(!neo_client_probe(NULL,0,report,sizeof(report)));
    CHECK(!neo_client_probe(NULL,FILE_BYTES,report,sizeof(report)));
    CHECK(!neo_client_probe(image,FILE_BYTES,NULL,REPORT_BYTES));

    fixture(1);
    unsigned char guarded[REPORT_BYTES+2];
    const size_t capacities[]={0,1,2,16,40,128,512,1024,4096,65536,full_length-16,full_length,full_length+1,REPORT_BYTES};
    for(unsigned i=0;i<sizeof(capacities)/sizeof(capacities[0]);i++){
        size_t capacity=capacities[i];memset(guarded,0xa5,sizeof(guarded));
        int result=neo_client_probe(image,FILE_BYTES,(char*)guarded+1,capacity);
        CHECK(result==(capacity>full_length));CHECK(guarded[0]==0xa5);CHECK(guarded[capacity+1]==0xa5);
        if(capacity){
            CHECK(memchr(guarded+1,0,capacity)!=NULL);
            CHECK((strstr((char*)guarded+1,COMPLETE)!=NULL)==result);
        }
    }

    uint32_t seed=0x9380822;
    for(unsigned trial=0;trial<2000;trial++){
        fixture(1);
        for(unsigned n=0;n<8;n++){
            seed=seed*1664525+1013904223;unsigned at=(trial&1)?seed%HEADERS:seed%FILE_BYTES;
            seed=seed*1664525+1013904223;image[at]^=(unsigned char)(seed>>16);
        }
        int result=probe(FILE_BYTES);CHECK(result==0||result==1);CHECK(memchr(report,0,sizeof(report))!=NULL);
        CHECK((strstr(report,COMPLETE)!=NULL)==result);
        if(result)for(unsigned i=0;i<3;i++){
            CHECK(has_row(windows[i].rva));CHECK(has_row(windows[i].rva+windows[i].length-16));
        }
    }
    printf("NEO V2 probe parser: %u assertions, %u failures; 2000 bounded mutations\n",assertions,failures);
    return failures?1:0;
}
