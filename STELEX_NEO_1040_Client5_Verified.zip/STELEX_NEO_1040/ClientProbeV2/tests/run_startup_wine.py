"""Exercise the rebuilt offline probe under Wine/Xvfb using synthetic data only.

Requires an initialized Wine64 prefix and DISPLAY. This never executes the
synthetic PE, a game client, or the original uploaded probe binary.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,struct,subprocess,tempfile,time
ROOT=Path(__file__).resolve().parent.parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--wine',required=True);p.add_argument('--zig',default='zig')
    p.add_argument('--prefix',type=Path);args=p.parse_args()
    env=os.environ.copy()
    if args.prefix:env['WINEPREFIX']=str(args.prefix.resolve())
    env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(ROOT/'build/zig-global-cache'))
    env.setdefault('ZIG_LOCAL_CACHE_DIR',str(ROOT/'build/zig-local-cache'))
    exe=ROOT/'NEO_Client_Probe.exe'
    report={'passed':False,'wine_started':True,'native_windows_tested':False,
            'real_neo_client_tested':False,'synthetic_input_only':True,
            'artifact_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'checks':[]}
    proc=None;counter=0
    zpath=lambda x:'Z:'+str(x).replace('/',chr(92))
    with tempfile.TemporaryDirectory(prefix='neo probe review ') as td:
        temp=Path(td);helper=temp/'window_probe.exe'
        log=(ROOT/'research/STARTUP_PROCESS.log').open('w')
        def expect(name,value,details=None):
            report['checks'].append({'name':name,'passed':bool(value),'details':details})
            if not value:raise AssertionError(name)
        def probe(mode='probe'):
            nonlocal counter
            counter+=1;out=temp/(str(counter)+'.json')
            run=subprocess.run([args.wine,str(helper),mode,zpath(out)],env=env,stdout=log,stderr=log,timeout=90)
            return json.loads(out.read_text()) if out.exists() else {'exit_code':run.returncode}
        def wait_for(predicate,seconds=30):
            until=time.monotonic()+seconds;last={}
            while time.monotonic()<until:
                last=probe()
                if predicate(last):return last
                if proc.poll() is not None:raise RuntimeError('Probe exited early: '+str(proc.returncode))
                time.sleep(.1)
            raise AssertionError('Window state timeout: '+str(last))
        try:
            zig=shutil.which(args.zig)
            if not zig:raise RuntimeError('Zig not found')
            built=subprocess.run([zig,'cc','-target','x86_64-windows-gnu','-std=c11','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests/window_probe.c'),'-luser32','-o',str(helper)],env=env,stdout=log,stderr=log,timeout=240)
            expect('UI helper compiled',built.returncode==0)
            expect('No stale probe window',not probe().get('window_exists'))
            proc=subprocess.Popen([args.wine,str(exe),'--choose-file'],env=env,stdout=log,stderr=log)
            state=wait_for(lambda s:s.get('window_visible') and s.get('picker_visible'))
            expect('Choose-file argument opens visible picker',state.get('picker_visible'),state)
            probe('cancel')
            state=wait_for(lambda s:s.get('window_exists') and not s.get('picker_visible'))
            expect('Cancelling picker preserves probe UI',state.get('window_visible'),state)
            probe('close');proc.wait(timeout=20)
            expect('Picker mode exits cleanly',proc.returncode==0)
            data=bytearray(0x7800)
            def w16(at,value):struct.pack_into('<H',data,at,value)
            def w32(at,value):struct.pack_into('<I',data,at,value)
            data[:2]=b'MZ';w32(60,0x80);w32(0x80,0x4550);w16(0x84,0x8664);w16(0x86,3)
            w16(0x94,240);w16(0x98,0x20b);w32(0xa8,0x214e000)
            struct.pack_into('<Q',data,0xb0,0x140000000);w32(0xd0,0x2154000);w32(0xd4,0x1400);w32(0x104,16)
            windows=[(0x214e000,0x4000,0x1400,0),(0x2152d00,0x400,0x5400,0x80),(0x17b1900,0x2000,0x5800,0x40)]
            for i,(rva,size,raw,mask) in enumerate(windows):
                at=0x188+i*40;data[at:at+6]=('.text'+str(i)).encode()
                w32(at+8,size);w32(at+12,rva);w32(at+16,size);w32(at+20,raw);w32(at+36,0x60000020)
                data[raw:raw+size]=bytes((j^mask)&255 for j in range(size))
            target=temp/'SYNTHETIC data only.bin';target.write_bytes(data)
            digest=hashlib.sha256(data).hexdigest()
            output=ROOT/'Reports'/(target.name+'_v2_'+digest[:16]+'.txt')
            if output.exists():output.unlink()
            proc=subprocess.Popen([args.wine,str(exe),zpath(target)],env=env,stdout=log,stderr=log)
            state=wait_for(lambda s:s.get('window_visible') and s.get('complete_in_editor'))
            expect('Synthetic report shown in UI',state.get('complete_in_editor'),state)
            expect('New v2 report written',output.is_file())
            raw=output.read_bytes();text=raw.decode('utf-8')
            expect('All three static windows complete',text.count('BEGIN_STATIC_WINDOW')==3 and 'NEO_PROBE_V2_COMPLETE' in text)
            expect('Report within 150 KiB bound',len(raw)<150*1024,{'bytes':len(raw)})
            expect('Report records exact input SHA256',digest in text)
            expect('Input left unchanged',hashlib.sha256(target.read_bytes()).hexdigest()==digest)
            (ROOT/'research/SYNTHETIC_STARTUP_REPORT.txt').write_bytes(raw)
            output.unlink();output.parent.rmdir()
            probe('close');proc.wait(timeout=20)
            expect('Report mode exits cleanly',proc.returncode==0)
            expect('Probe binary unchanged',hashlib.sha256(exe.read_bytes()).hexdigest()==report['artifact_sha256'])
            report['passed']=True
        except Exception as error:
            report['error']=type(error).__name__+': '+str(error)
        finally:
            if proc and proc.poll() is None:
                try:probe('cancel');probe('close');proc.wait(timeout=10)
                except Exception:proc.terminate()
            log.close()
    (ROOT/'research/STARTUP_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
