"""Run generic PE and bounded NEO code-window parser regressions on the host."""
from pathlib import Path
import hashlib,json,re,subprocess,tempfile
ROOT=Path(__file__).resolve().parent.parent

def main()->int:
    report={'passed':False,'sanitizers':['AddressSanitizer','UndefinedBehaviorSanitizer'],'actual_neo_client_tested':False,'windows_started':False,'checks':[]}
    report['inputs']={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in [ROOT/'source/pe_inspect.c',ROOT/'source/pe_inspect.h',ROOT/'tests/test_pe_inspect.c',ROOT/'tests/test_neo_probe.c']}
    with tempfile.TemporaryDirectory(prefix='neo-probe-host-tests-') as temp:
        for name in ['test_pe_inspect','test_neo_probe']:
            output=Path(temp)/name
            command=['gcc','-std=c11','-Wall','-Wextra','-Werror','-pedantic','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie',str(ROOT/'source/pe_inspect.c'),str(ROOT/'tests'/(name+'.c')),'-o',str(output)]
            for stage,args in [('compile',command),('run',[str(output)])]:
                done=subprocess.run(args,cwd=ROOT,text=True,capture_output=True,timeout=120)
                row={'name':name+' '+stage,'command':args,'passed':done.returncode==0,'exit_code':done.returncode,'stdout':done.stdout,'stderr':done.stderr}
                match=re.search(r'(\d+) assertions, (\d+) failures',done.stdout)
                if match:row.update(assertions=int(match[1]),failures=int(match[2]))
                report['checks'].append(row)
                print(('PASS' if row['passed'] else 'FAIL')+' '+row['name'],flush=True)
                if done.stdout:print(done.stdout.rstrip(),flush=True)
                if done.stderr:print(done.stderr.rstrip(),flush=True)
                if done.returncode:break
    report['passed']=len(report['checks'])==4 and all(row['passed'] for row in report['checks'])
    (ROOT/'research/TEST_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
