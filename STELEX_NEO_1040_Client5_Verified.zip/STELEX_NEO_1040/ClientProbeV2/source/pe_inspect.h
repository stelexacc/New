#ifndef PE_INSPECT_H
#define PE_INSPECT_H
#include <stddef.h>
/* Offline PE file metadata only. No process access or runtime discovery.
 * Returns 1 for a structurally valid supported PE; 0 with a report otherwise.
 * Output is always NUL terminated when capacity > 0. No heap/CRT dependencies.
 */
int pe_inspect(const unsigned char *data, size_t size, char *report, size_t capacity);
/* NEO diagnostic V2: strict AMD64 PE32+ metadata and three static executable
 * file windows only: RVA0x0214E000+0x4000, RVA0x02152D00+0x400 and
 * RVA0x017B1900+0x2000. No live addresses or offset discovery.
 * Returns1 only when all windows and the complete report fit. Missing windows
 * are explicitly marked; other valid windows may still be emitted. Returns0
 * on unsupported or incomplete input/output. NUL-terminated if capacity>0. */
int neo_client_probe(const unsigned char *data, size_t size, char *report, size_t capacity);
#endif
