/* NEO Client Probe - static local-file diagnostic, no game/process access. */
#include <stddef.h>
#include <stdint.h>
#include "pe_inspect.h"
#define API __declspec(dllimport)
#define WAPI __stdcall
typedef void *HANDLE,*HWND,*HINSTANCE,*HDC,*HBRUSH,*HFONT,*HGDIOBJ,*HPEN,*HICON,*HCURSOR,*HMENU;
typedef unsigned long DWORD; typedef unsigned int UINT; typedef int BOOL; typedef unsigned short WORD; typedef uintptr_t WPARAM;typedef intptr_t LPARAM,LRESULT;typedef const wchar_t *LPCWSTR;
typedef struct {long left,top,right,bottom;} RECT;
typedef struct {long x,y;} POINT;
typedef struct {HWND hwnd;UINT message;WPARAM wp;LPARAM lp;DWORD time;POINT point;DWORD private_data;} MSG;
typedef struct {HDC dc;BOOL erase;RECT paint;BOOL restore,update;unsigned char reserved[32];} PAINTSTRUCT;
typedef LRESULT(WAPI*WNDPROC)(HWND,UINT,WPARAM,LPARAM);
typedef struct {UINT size,style;WNDPROC proc;int cls_extra,wnd_extra;HINSTANCE instance;HICON icon;HCURSOR cursor;HBRUSH background;LPCWSTR menu,classname;HICON small_icon;} WNDCLASSEXW;
typedef struct {DWORD size;HWND owner;HINSTANCE instance;LPCWSTR filter;wchar_t *custom;DWORD custom_size,index;wchar_t *file;DWORD file_size;wchar_t *file_title;DWORD file_title_size;LPCWSTR initial_dir,title;DWORD flags;WORD file_offset,extension;LPCWSTR default_extension;LPARAM data;void *hook;LPCWSTR template_name;void *reserved;DWORD reserved_size,flags_ex;} OPENFILENAMEW;
typedef struct {UINT type,id,item,action,state;HWND window;HDC dc;RECT rect;uintptr_t data;} DRAWITEMSTRUCT;
typedef struct {WORD year,month,weekday,day,hour,minute,second,millis;} SYSTEMTIME;
typedef struct {POINT reserved,max_size,max_position,min_track,max_track;} MINMAXINFO;
API HINSTANCE WAPI GetModuleHandleW(LPCWSTR);API DWORD WAPI GetModuleFileNameW(HINSTANCE,wchar_t*,DWORD);API HANDLE WAPI GetProcessHeap(void);API void* WAPI HeapAlloc(HANDLE,DWORD,size_t);API BOOL WAPI HeapFree(HANDLE,DWORD,void*);
API HANDLE WAPI CreateFileW(LPCWSTR,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);API BOOL WAPI GetFileSizeEx(HANDLE,int64_t*);API HANDLE WAPI CreateFileMappingW(HANDLE,void*,DWORD,DWORD,DWORD,LPCWSTR);API void* WAPI MapViewOfFile(HANDLE,DWORD,DWORD,DWORD,size_t);API BOOL WAPI UnmapViewOfFile(const void*);API BOOL WAPI CloseHandle(HANDLE);API BOOL WAPI WriteFile(HANDLE,const void*,DWORD,DWORD*,void*);API BOOL WAPI CreateDirectoryW(LPCWSTR,void*);API DWORD WAPI GetLastError(void);API DWORD WAPI GetFileAttributesW(LPCWSTR);API void WAPI GetLocalTime(SYSTEMTIME*);API void WAPI ExitProcess(UINT);
API int WAPI MultiByteToWideChar(UINT,DWORD,const char*,int,wchar_t*,int);API int WAPI WideCharToMultiByte(UINT,DWORD,LPCWSTR,int,char*,int,const char*,BOOL*);API HANDLE WAPI CreateThread(void*,size_t,DWORD(WAPI*)(void*),void*,DWORD,DWORD*);API void* WAPI GlobalAlloc(UINT,size_t);API void* WAPI GlobalLock(void*);API BOOL WAPI GlobalUnlock(void*);API void* WAPI GlobalFree(void*);
API WORD WAPI RegisterClassExW(const WNDCLASSEXW*);API HWND WAPI CreateWindowExW(DWORD,LPCWSTR,LPCWSTR,DWORD,int,int,int,int,HWND,HMENU,HINSTANCE,void*);API LRESULT WAPI DefWindowProcW(HWND,UINT,WPARAM,LPARAM);API BOOL WAPI ShowWindow(HWND,int);API BOOL WAPI UpdateWindow(HWND);API BOOL WAPI GetMessageW(MSG*,HWND,UINT,UINT);API BOOL WAPI TranslateMessage(const MSG*);API LRESULT WAPI DispatchMessageW(const MSG*);API void WAPI PostQuitMessage(int);API BOOL WAPI PostMessageW(HWND,UINT,WPARAM,LPARAM);API LRESULT WAPI SendMessageW(HWND,UINT,WPARAM,LPARAM);API BOOL WAPI SetWindowTextW(HWND,LPCWSTR);API BOOL WAPI EnableWindow(HWND,BOOL);API BOOL WAPI MoveWindow(HWND,int,int,int,int,BOOL);API BOOL WAPI GetClientRect(HWND,RECT*);API BOOL WAPI InvalidateRect(HWND,const RECT*,BOOL);API HDC WAPI BeginPaint(HWND,PAINTSTRUCT*);API BOOL WAPI EndPaint(HWND,const PAINTSTRUCT*);API int WAPI FillRect(HDC,const RECT*,HBRUSH);API int WAPI DrawTextW(HDC,LPCWSTR,int,RECT*,UINT);API int WAPI MessageBoxW(HWND,LPCWSTR,LPCWSTR,UINT);API BOOL WAPI SetProcessDPIAware(void);API HCURSOR WAPI LoadCursorW(HINSTANCE,LPCWSTR);API HICON WAPI LoadIconW(HINSTANCE,LPCWSTR);API BOOL WAPI OpenClipboard(HWND);API BOOL WAPI EmptyClipboard(void);API HANDLE WAPI SetClipboardData(UINT,HANDLE);API BOOL WAPI CloseClipboard(void);
API HFONT WAPI CreateFontW(int,int,int,int,int,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,LPCWSTR);API HGDIOBJ WAPI SelectObject(HDC,HGDIOBJ);API BOOL WAPI DeleteObject(HGDIOBJ);API HBRUSH WAPI CreateSolidBrush(DWORD);API DWORD WAPI SetTextColor(HDC,DWORD);API DWORD WAPI SetBkColor(HDC,DWORD);API int WAPI SetBkMode(HDC,int);API BOOL WAPI RoundRect(HDC,int,int,int,int,int,int);API HPEN WAPI CreatePen(int,int,DWORD);
API BOOL WAPI GetOpenFileNameW(OPENFILENAMEW*);API DWORD WAPI CommDlgExtendedError(void);API void WAPI DragAcceptFiles(HWND,BOOL);API UINT WAPI DragQueryFileW(HANDLE,UINT,wchar_t*,UINT);API void WAPI DragFinish(HANDLE);API HINSTANCE WAPI ShellExecuteW(HWND,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,int);API wchar_t** WAPI CommandLineToArgvW(LPCWSTR,int*);API LPCWSTR WAPI GetCommandLineW(void);API HANDLE WAPI LocalFree(HANDLE);
API long WAPI BCryptOpenAlgorithmProvider(HANDLE*,LPCWSTR,LPCWSTR,DWORD);API long WAPI BCryptHash(HANDLE,unsigned char*,DWORD,unsigned char*,DWORD,unsigned char*,DWORD);API long WAPI BCryptCloseAlgorithmProvider(HANDLE,DWORD);
#define INVALID_HANDLE ((HANDLE)(intptr_t)-1)
#define RGB(r,g,b) ((DWORD)((r)|((g)<<8)|((b)<<16)))
#define REPORT_CAP (150*1024)
#define PE_CAP (144*1024)
#define PATH_CAP 32768
#define MAX_INPUT (1024*1024*1024)
#define DONE 0x8001
static HWND main_window,editor,buttons[4];static HINSTANCE instance;static HFONT font_title,font_ui,font_mono,font_small;static HBRUSH bg_brush,edit_brush;
static const DWORD BG=RGB(16,19,27),CARD=RGB(24,29,40),INK=RGB(232,237,247),MUTED=RGB(151,162,185),ACCENT=RGB(144,114,255);
static wchar_t input_path[PATH_CAP],exe_folder[PATH_CAP],report_folder[PATH_CAP],report_path[PATH_CAP],input_label[PATH_CAP],status_line[PATH_CAP];
static char pe_report[PE_CAP],report[REPORT_CAP];static wchar_t *display_report;static int busy,report_saved,job_ok,close_pending;static DWORD job_error;static const wchar_t *job_stage;
static size_t wl(LPCWSTR s){size_t n=0;while(s[n])n++;return n;}
static int weq(LPCWSTR a,LPCWSTR b){while(*a&&*a==*b){a++;b++;}return *a==*b;}
static void wc(wchar_t*d,LPCWSTR s,size_t cap){size_t i=0;if(!cap)return;while(s[i]&&i+1<cap){d[i]=s[i];i++;}d[i]=0;}
static int wa(wchar_t*d,LPCWSTR s,size_t cap){size_t i=wl(d),j=0;while(s[j]){if(i+1>=cap)return 0;d[i++]=s[j++];}d[i]=0;return 1;}
static LPCWSTR basename_w(LPCWSTR p){LPCWSTR b=p;for(size_t i=0;p[i];i++)if(p[i]=='\\'||p[i]=='/')b=p+i+1;return b;}
static void dec(char*out,uint64_t v){char t[24];int n=0;do{t[n++]=(char)('0'+v%10);v/=10;}while(v);int j=0;while(n)out[j++]=t[--n];out[j]=0;}
static void append(char*d,const char*s,size_t cap){size_t i=0,j=0;while(d[i])i++;while(s[j]&&i+1<cap)d[i++]=s[j++];d[i]=0;}
static void num(char*d,uint64_t v){char n[24];dec(n,v);append(d,n,REPORT_CAP);}
static void set_status(LPCWSTR s){wc(status_line,s,PATH_CAP);InvalidateRect(main_window,NULL,0);}
static void draw_text(HDC d,LPCWSTR t,RECT r,HFONT f,DWORD c,UINT flags){HGDIOBJ old=SelectObject(d,f);SetTextColor(d,c);SetBkMode(d,1);DrawTextW(d,t,-1,&r,flags);SelectObject(d,old);}
static void fill(HDC d,RECT r,DWORD c){HBRUSH b=CreateSolidBrush(c);FillRect(d,&r,b);DeleteObject(b);}
static void error_box(LPCWSTR stage,DWORD code){static wchar_t text[PATH_CAP];char a[24];wchar_t n[32];dec(a,code);MultiByteToWideChar(65001,0,a,-1,n,32);wc(text,stage,PATH_CAP);if(code){wa(text,L"\r\nWindows-Fehler: ",PATH_CAP);wa(text,n,PATH_CAP);}MessageBoxW(main_window,text,L"NEO Client Probe",0x10);}
static void toggle_controls(void){EnableWindow(buttons[0],!busy);EnableWindow(buttons[1],!busy&&report_saved);EnableWindow(buttons[2],!busy);EnableWindow(buttons[3],!busy&&display_report!=NULL);}
static DWORD WAPI inspect_worker(void*unused){
 (void)unused;HANDLE file=INVALID_HANDLE,mapping=NULL,alg=NULL;unsigned char*data=NULL;static unsigned char empty=0;int64_t size=0;unsigned char hash[32];char digest[65];static char name_utf8[1024];SYSTEMTIME now;
 report[0]=0;report_saved=0;job_ok=0;job_error=0;job_stage=L"Datei konnte nicht analysiert werden.";
 file=CreateFileW(input_path,0x80000000,1,NULL,3,0x80,NULL);if(file==INVALID_HANDLE){job_error=GetLastError();goto finish;}
 if(!GetFileSizeEx(file,&size)){job_error=GetLastError();goto finish;}
 if(size<0||size>MAX_INPUT){job_stage=L"Datei ist zu gross. Grenze: 1 GiB pro Datei.";goto finish;}
 if(size){mapping=CreateFileMappingW(file,NULL,2,0,0,NULL);if(!mapping){job_error=GetLastError();goto finish;}data=MapViewOfFile(mapping,4,0,0,0);if(!data){job_error=GetLastError();goto finish;}}
 if(BCryptOpenAlgorithmProvider(&alg,L"SHA256",NULL,0)<0||BCryptHash(alg,NULL,0,size?data:&empty,(DWORD)size,hash,32)<0){job_stage=L"SHA-256 konnte nicht berechnet werden.";goto finish;}
 for(int i=0;i<32;i++){digest[i*2]="0123456789abcdef"[hash[i]>>4];digest[i*2+1]="0123456789abcdef"[hash[i]&15];}digest[64]=0;
 job_ok=neo_client_probe(size?data:&empty,(size_t)size,pe_report,PE_CAP);
 append(report,"NEO CLIENT PROBE V2 | OFFLINE-DIAGNOSEBERICHT\r\n========================================\r\nZielbezeichnung: Fortnite 10.40-CL-9380822 (nicht automatisch bestaetigt).\r\n",REPORT_CAP);
 if(!WideCharToMultiByte(65001,0,basename_w(input_path),-1,name_utf8,1024,NULL,NULL))wc(input_label,L"Dateiname zu lang fuer Bericht",PATH_CAP);
 else{append(report,"Datei: ",REPORT_CAP);append(report,name_utf8,REPORT_CAP);append(report,"\r\n",REPORT_CAP);}
 append(report,"SHA-256: ",REPORT_CAP);append(report,digest,REPORT_CAP);append(report,"\r\nDateigroesse: ",REPORT_CAP);num(report,(uint64_t)size);append(report," Bytes\r\nAnalysezeit (lokale Uhr): ",REPORT_CAP);
 GetLocalTime(&now);num(report,now.year);append(report,"-",REPORT_CAP);num(report,now.month);append(report,"-",REPORT_CAP);num(report,now.day);append(report," ",REPORT_CAP);num(report,now.hour);append(report,":",REPORT_CAP);num(report,now.minute);append(report,":",REPORT_CAP);num(report,now.second);
 append(report,"\r\n\r\nNur Werte der ausgewaehlten Datei. RVA und Dateioffset sind nicht\r\nmit der Adresse eines laufenden Prozesses gleichzusetzen.\r\nEnthaelt nur statische Datei-Metadaten und den begrenzten SDK-Codebereich.\r\nDie Datei wurde nicht ausgefuehrt; Build, Namenpool und Spiel-Offsets sind damit nicht bestaetigt.\r\n\r\n",REPORT_CAP);append(report,pe_report,REPORT_CAP);
 if(!CreateDirectoryW(report_folder,NULL)&&GetLastError()!=183){job_stage=L"Berichtsordner neben der EXE ist nicht schreibbar.";job_error=GetLastError();goto finish;}
 wc(report_path,report_folder,PATH_CAP);if(!wa(report_path,L"\\",PATH_CAP)){job_stage=L"Berichtspfad zu lang.";goto finish;}
 {LPCWSTR b=basename_w(input_path);size_t at=wl(report_path);for(int i=0;b[i]&&i<96;i++){wchar_t ch=b[i];if(ch<32||ch=='<'||ch=='>'||ch==':'||ch=='"'||ch=='/'||ch=='\\'||ch=='|'||ch=='?'||ch=='*')ch='_';if(at+32>=PATH_CAP){job_stage=L"Berichtspfad zu lang.";goto finish;}report_path[at++]=ch;}report_path[at++]=L'_';report_path[at++]=L'v';report_path[at++]=L'2';report_path[at++]=L'_';for(int i=0;i<16;i++)report_path[at++]=(wchar_t)digest[i];report_path[at]=0;wa(report_path,L".txt",PATH_CAP);}
 {HANDLE output=CreateFileW(report_path,0x40000000,1,NULL,2,0x80,NULL);if(output==INVALID_HANDLE){job_stage=L"TXT-Bericht konnte nicht gespeichert werden.";job_error=GetLastError();goto finish;}DWORD wanted=0,written=0;while(report[wanted])wanted++;int ok=WriteFile(output,report,wanted,&written,NULL)&&written==wanted;job_error=ok?0:GetLastError();CloseHandle(output);if(!ok){job_stage=L"TXT-Bericht wurde nicht vollstaendig geschrieben.";goto finish;}}
 report_saved=1;
 finish:
 if(alg)BCryptCloseAlgorithmProvider(alg,0);if(data)UnmapViewOfFile(data);if(mapping)CloseHandle(mapping);if(file!=INVALID_HANDLE)CloseHandle(file);PostMessageW(main_window,DONE,0,0);return 0;
}
static void start_analysis(LPCWSTR path){
 if(busy)return;
 if(path!=input_path)wc(input_path,path,PATH_CAP);
 wc(input_label,basename_w(input_path),PATH_CAP);report_saved=0;report_path[0]=0;busy=1;toggle_controls();set_status(L"Analysiere lokale Datei und erstelle automatisch den TXT-Bericht ...");
 HANDLE t=CreateThread(NULL,0,inspect_worker,NULL,0,NULL);if(!t){busy=0;toggle_controls();set_status(L"Analyse konnte nicht gestartet werden.");error_box(L"Analyse-Thread konnte nicht erstellt werden.",GetLastError());}else CloseHandle(t);
}
static void choose_file(void){
 static wchar_t chosen[PATH_CAP];chosen[0]=0;OPENFILENAMEW o={0};o.size=sizeof(o);o.owner=main_window;o.filter=L"FortniteClient-Win64-Shipping.exe\0FortniteClient-Win64-Shipping.exe\0EXE-Dateien\0*.exe\0Alle Dateien\0*.*\0\0";o.file=chosen;o.file_size=PATH_CAP;o.title=L"Neo-Client auswaehlen: FortniteClient-Win64-Shipping.exe (nicht Launcher)";o.flags=0x00080000|0x1000|0x800|8;
 if(GetOpenFileNameW(&o))start_analysis(chosen);else{DWORD e=CommDlgExtendedError();if(e)error_box(L"Dateiauswahl fehlgeschlagen.",e);}
}
static void copy_report(void){
 if(!display_report)return;size_t size=(wl(display_report)+1)*sizeof(wchar_t);HANDLE h=GlobalAlloc(2,size);if(!h)return;wchar_t *p=GlobalLock(h);if(!p){GlobalFree(h);return;}for(size_t i=0;i<size/2;i++)p[i]=display_report[i];GlobalUnlock(h);if(!OpenClipboard(main_window)){GlobalFree(h);return;}EmptyClipboard();if(!SetClipboardData(13,h))GlobalFree(h);CloseClipboard();set_status(L"Bericht in die Zwischenablage kopiert.");
}
static void layout(void){RECT r;GetClientRect(main_window,&r);int w=r.right,h=r.bottom;MoveWindow(buttons[0],24,125,196,42,1);MoveWindow(buttons[1],232,125,180,42,1);MoveWindow(buttons[2],424,125,180,42,1);MoveWindow(buttons[3],616,125,124,42,1);MoveWindow(editor,24,244,w-48,h-305,1);InvalidateRect(main_window,NULL,0);}
static LRESULT WAPI window_proc(HWND w,UINT m,WPARAM a,LPARAM b){
 if(m==0x10&&busy){close_pending=1;set_status(L"Analyse wird abgeschlossen und der Bericht gespeichert. Fenster schliesst danach.");return 0;}
 if(m==0x02){PostQuitMessage(0);return 0;}
 if(m==0x24){MINMAXINFO*p=(MINMAXINFO*)b;p->min_track.x=900;p->min_track.y=600;return 0;}
 if(m==0x05){if(editor)layout();return 0;}
 if(m==0x14)return 1;
 if(m==0x111){UINT id=(UINT)(a&0xffff);if(busy)return 0;if(id==100)choose_file();else if(id==101&&report_saved){uintptr_t result=(uintptr_t)ShellExecuteW(w,L"open",report_path,NULL,NULL,1);if(result<=32)error_box(L"Bericht konnte nicht geoeffnet werden.",(DWORD)result);}else if(id==102){if(!CreateDirectoryW(report_folder,NULL)&&GetLastError()!=183)error_box(L"Berichtsordner konnte nicht erstellt werden.",GetLastError());else{DWORD attributes=GetFileAttributesW(report_folder);if(attributes==0xffffffff||!(attributes&0x10))error_box(L"Reports ist kein Verzeichnis.",0);else{uintptr_t result=(uintptr_t)ShellExecuteW(w,L"open",report_folder,NULL,NULL,1);if(result<=32)error_box(L"Berichtsordner konnte nicht geoeffnet werden.",(DWORD)result);}}}else if(id==103)copy_report();return 0;}
 if(m==0x233){HANDLE drop=(HANDLE)a;static wchar_t dropped[PATH_CAP];UINT count=DragQueryFileW(drop,0xffffffff,NULL,0);UINT n=count?DragQueryFileW(drop,0,NULL,0):0;if(count!=1||n>=PATH_CAP){DragFinish(drop);set_status(L"Bitte genau eine Datei hineinziehen.");return 0;}DragQueryFileW(drop,0,dropped,PATH_CAP);DragFinish(drop);start_analysis(dropped);return 0;}
 if(m==DONE){busy=0;if(display_report){HeapFree(GetProcessHeap(),0,display_report);display_report=NULL;}int n=report[0]?MultiByteToWideChar(65001,0,report,-1,NULL,0):0;if(n>0){display_report=HeapAlloc(GetProcessHeap(),0,(size_t)n*2);if(display_report)MultiByteToWideChar(65001,0,report,-1,display_report,n);}SetWindowTextW(editor,display_report?display_report:L"Kein Bericht verfuegbar.");SendMessageW(editor,0xb1,0,0);toggle_controls();if(report_saved){wc(status_line,job_ok?L"Alle drei statischen Codefenster gespeichert: ":L"Mindestens ein Codefenster fehlt / Datei unpassend. Diagnosebericht gespeichert: ",PATH_CAP);wa(status_line,report_path,PATH_CAP);InvalidateRect(w,NULL,0);}else{set_status(job_stage);if(!close_pending)error_box(job_stage,job_error);}if(close_pending)PostMessageW(w,0x10,0,0);return 0;}
 if(m==0x138||m==0x133){HDC d=(HDC)a;SetTextColor(d,INK);SetBkColor(d,CARD);return (LRESULT)edit_brush;}
 if(m==0x2b){DRAWITEMSTRUCT*d=(DRAWITEMSTRUCT*)b;if(d->id>=100&&d->id<=103){DWORD c=d->id==100?ACCENT:CARD;if(d->state&4)c=RGB(37,41,52);HBRUSH brush=CreateSolidBrush(c);HPEN pen=CreatePen(0,1,c);HGDIOBJ ob=SelectObject(d->dc,brush),op=SelectObject(d->dc,pen);RoundRect(d->dc,d->rect.left,d->rect.top,d->rect.right,d->rect.bottom,10,10);SelectObject(d->dc,ob);SelectObject(d->dc,op);DeleteObject(brush);DeleteObject(pen);const wchar_t *labels[]={L"Clientdatei pruefen",L"TXT oeffnen",L"Berichtsordner",L"Kopieren"};draw_text(d->dc,labels[d->id-100],d->rect,font_ui,d->state&4?MUTED:INK,0x25);return 1;}}
 if(m==0xf){PAINTSTRUCT ps;HDC d=BeginPaint(w,&ps);RECT r;GetClientRect(w,&r);fill(d,r,BG);RECT title={24,21,r.right-24,59};draw_text(d,L"NEO  /  CLIENT PROBE V2",title,font_title,INK,0x20);RECT sub={24,65,r.right-24,92};draw_text(d,L"Fortnite 10.40-CL-9380822  |  Drei statische Codefenster  |  TXT-Bericht",sub,font_ui,MUTED,0x20);RECT tag={r.right-175,27,r.right-24,52};draw_text(d,L"OFFLINE  \x00b7  v0.2",tag,font_small,ACCENT,0x22);RECT label={24,184,r.right-24,210};draw_text(d,input_label[0]?input_label:L"FortniteClient-Win64-Shipping.exe auswaehlen oder hineinziehen; nicht den Launcher",label,font_ui,INK,0x8020);RECT hint={24,211,r.right-24,233};draw_text(d,L"Nur lokale Datei-Bytes. Keine Ausfuehrung, kein Spielzugriff. Der Bericht bestaetigt keine Spiel-Offsets.",hint,font_small,MUTED,0x8020);RECT footer={24,r.bottom-44,r.right-24,r.bottom-15};draw_text(d,status_line,footer,font_small,report_saved?RGB(126,219,174):MUTED,0x8020);EndPaint(w,&ps);return 0;}
 return DefWindowProcW(w,m,a,b);
}
void mainCRTStartup(void){
 SetProcessDPIAware();instance=GetModuleHandleW(NULL);DWORD n=GetModuleFileNameW(NULL,exe_folder,PATH_CAP);if(!n||n>=PATH_CAP)ExitProcess(2);while(n&&exe_folder[n-1]!='\\'&&exe_folder[n-1]!='/')n--;exe_folder[n]=0;wc(report_folder,exe_folder,PATH_CAP);if(!wa(report_folder,L"Reports",PATH_CAP))ExitProcess(2);
 bg_brush=CreateSolidBrush(BG);edit_brush=CreateSolidBrush(CARD);font_title=CreateFontW(-27,0,0,0,650,0,0,0,0,0,0,5,0,L"Segoe UI");font_ui=CreateFontW(-17,0,0,0,400,0,0,0,0,0,0,5,0,L"Segoe UI");font_small=CreateFontW(-14,0,0,0,400,0,0,0,0,0,0,5,0,L"Segoe UI");font_mono=CreateFontW(-15,0,0,0,400,0,0,0,0,0,0,5,0,L"Consolas");
 WNDCLASSEXW c={0};c.size=sizeof(c);c.proc=window_proc;c.instance=instance;c.classname=L"NEO_CLIENT_PROBE_V2_OFFLINE";c.background=bg_brush;c.cursor=LoadCursorW(NULL,(LPCWSTR)(uintptr_t)32512);c.icon=c.small_icon=LoadIconW(NULL,(LPCWSTR)(uintptr_t)32512);if(!RegisterClassExW(&c))ExitProcess(3);
 main_window=CreateWindowExW(0,c.classname,L"NEO | Client Probe v2 | 10.40-CL-9380822",0x00cf0000,100,60,1200,850,NULL,NULL,instance,NULL);if(!main_window)ExitProcess(4);
 for(int i=0;i<4;i++){buttons[i]=CreateWindowExW(0,L"BUTTON",L"",0x5001000b,0,0,0,0,main_window,(HMENU)(uintptr_t)(100+i),instance,NULL);SendMessageW(buttons[i],0x30,(WPARAM)font_ui,1);}
 editor=CreateWindowExW(0x200,L"EDIT",L"1. Clientdatei pruefen anklicken.\r\n2. Im Neo-Spielordner FortniteClient-Win64-Shipping.exe waehlen, nicht den Launcher.\r\n3. Die TXT-Datei aus Reports neben dieser Probe-EXE weitergeben.\r\n\r\nAusgabe V2: SHA-256, PE-Metadaten, Sektionen und drei explizit begrenzte statische Codefenster (zusammen 25 KiB).\r\n\r\nEs wird kein Spiel gestartet und kein laufender Prozess gelesen.\r\nDer Bericht beweist keine korrekten Spiel-Offsets oder einen passenden Build.",0x503008c4,0,0,0,0,main_window,(HMENU)200,instance,NULL);SendMessageW(editor,0xc5,REPORT_CAP,0);SendMessageW(editor,0x30,(WPARAM)font_mono,1);DragAcceptFiles(main_window,1);set_status(L"Bereit. Keine Installation oder Administratorrechte erforderlich.");layout();toggle_controls();ShowWindow(main_window,1);UpdateWindow(main_window);
 int argc=0;wchar_t**argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(argv&&argc==2){if(weq(argv[1],L"--choose-file"))PostMessageW(main_window,0x111,100,0);else start_analysis(argv[1]);}if(argv)LocalFree(argv);
 MSG message;while(GetMessageW(&message,NULL,0,0)>0){TranslateMessage(&message);DispatchMessageW(&message);}ExitProcess(0);
}
