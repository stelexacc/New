#include "pe_inspect.h"
#include <stdint.h>

/* The parser reads bytes from a file buffer only.  An RVA is not a process
 * address, and this module intentionally contains no OS or process API. */
struct output { char *p; size_t cap, n; int truncated; };
struct image {
    const unsigned char *p; size_t size;
    uint32_t sections, headers, section_at, directories, directory_at;
    uint32_t entry, image_size, string_budget; uint64_t image_base; int wide;
    struct output out;
};
static void ch(struct output *o, char c) {
    if(o->cap && o->n < o->cap-1) { o->p[o->n++]=c; o->p[o->n]=0; }
    else o->truncated=1;
}
static void text(struct output *o,const char *s) { while(*s)ch(o,*s++); }
static void number(struct output *o,uint64_t value) {
    char digits[24]; unsigned n=0;
    do { digits[n++]=(char)('0'+value%10);value/=10; } while(value);
    while(n)ch(o,digits[--n]);
}
static void hex(struct output *o,uint64_t value,unsigned width) {
    static const char digits[]="0123456789ABCDEF";
    text(o,"0x");for(int i=(int)width-1;i>=0;i--)ch(o,digits[(value>>(i*4))&15]);
}
static void byte_text(struct output *o,unsigned c) {
    if(c>=32 && c<=126 && c!='\\')ch(o,(char)c);
    else {static const char d[]="0123456789ABCDEF";text(o,"\\x");ch(o,d[(c>>4)&15]);ch(o,d[c&15]);}
}
static int range(const struct image *p,uint64_t at,uint64_t n) { return at<=p->size && n<=p->size-(size_t)at; }
static uint16_t u16(const unsigned char *p) { return (uint16_t)((uint16_t)p[0]|((uint16_t)p[1]<<8)); }
static uint32_t u32(const unsigned char *p) { return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static uint64_t u64(const unsigned char *p) { return (uint64_t)u32(p)|((uint64_t)u32(p+4)<<32); }
static int error(struct image *p,const char *s) { text(&p->out,"\r\nFEHLER: ");text(&p->out,s);text(&p->out,"\r\n");return 0; }
/* A requested span must be in exactly one file-backed region.  Virtual-only
 * tails and overlapping RVA regions do not yield a guessed file offset. */
static int mapped(const struct image *p,uint32_t rva,uint64_t n,size_t *offset) {
    unsigned matches=0;size_t result=0;
    if((uint64_t)rva < p->headers && n<=(uint64_t)p->headers-rva && range(p,rva,n)){matches++;result=rva;}
    for(uint32_t i=0;i<p->sections;i++){
        const unsigned char *s=p->p+p->section_at+i*40;
        uint32_t va=u32(s+12),raw=u32(s+16),file=u32(s+20);
        if(rva>=va && (uint64_t)rva-va<raw && n<=(uint64_t)raw-(rva-va) && range(p,(uint64_t)file+rva-va,n)){
            matches++;result=(size_t)((uint64_t)file+rva-va);
        }
    }
    if(matches!=1)return 0;
    *offset=result;return 1;
}
static int string_rva(struct image *p,uint32_t rva,uint64_t max_length) {
    if(max_length>4096)max_length=4096;
    for(uint64_t i=0;i<max_length;i++){
        if(!p->string_budget)return 0;
        p->string_budget--;
        size_t at=0;if((uint64_t)rva+i>UINT32_MAX || !mapped(p,rva+(uint32_t)i,1,&at))return 0;
        unsigned c=p->p[at];if(!c)return 1;byte_text(&p->out,c);
    }
    return 0;
}
static void location(struct image *p,uint32_t rva){
    size_t at=0;hex(&p->out,rva,8);text(&p->out," | Datei ");
    if(mapped(p,rva,1,&at))hex(&p->out,at,8);else text(&p->out,"nicht eindeutig/dateigedeckt");
}
static int directory(const struct image *p,unsigned index,uint32_t *rva,uint32_t *length) {
    *rva=*length=0;if(index>=p->directories)return 1;
    size_t off=(size_t)p->directory_at+index*8;
    if(!range(p,off,8))return 0;
    *rva=u32(p->p+off);*length=u32(p->p+off+4);
    return ((!*rva && !*length)||(*rva && *length && (uint64_t)*rva+*length<=0x100000000ULL));
}
static int exports(struct image *p) {
    uint32_t rva=0,size=0;if(!directory(p,0,&rva,&size))return error(p,"Ungueltiges Export-Verzeichnis.");
    text(&p->out,"\r\nEXPORTS\r\n");if(!rva){text(&p->out,"Keine Exporttabelle.\r\n");return 1;}
    size_t at=0;if(size<40||!mapped(p,rva,size,&at))return error(p,"Export-Verzeichnis ausserhalb eines eindeutigen Dateibereichs.");
    const unsigned char *d=p->p+at;uint32_t base=u32(d+16),count=u32(d+20),names=u32(d+24);
    uint32_t funcs=u32(d+28),name_table=u32(d+32),ordinals=u32(d+36);
    if(count>16384||names>16384)return error(p,"Exportanzahl ueber dem Analyse-Limit 16384.");
    if((uint64_t)base+count>0x100000000ULL)return error(p,"Export-Ordinalueberlauf.");
    size_t ft=0,nt=0,ot=0;
    if((count&&!mapped(p,funcs,(uint64_t)count*4,&ft))||(names&&(!mapped(p,name_table,(uint64_t)names*4,&nt)||!mapped(p,ordinals,(uint64_t)names*2,&ot))))return error(p,"Export-Tabellen nicht vollstaendig dateigedeckt.");
    text(&p->out,"Ordinalbasis: ");number(&p->out,base);text(&p->out," | Adresstabelleneintraege: ");number(&p->out,count);text(&p->out,"\r\n");
    for(uint32_t i=0;i<count;i++){
        uint32_t value=u32(p->p+ft+i*4);if(!value)continue;
        text(&p->out,"  Ordinal ");number(&p->out,(uint64_t)base+i);text(&p->out," | RVA ");location(p,value);
        if(value>=rva && (uint64_t)value<(uint64_t)rva+size){
            text(&p->out," | Weiterleitung: ");if(!string_rva(p,value,(uint64_t)rva+size-value))return error(p,"Nicht terminierte Export-Weiterleitung.");
        }
        text(&p->out,"\r\n");
    }
    text(&p->out,"Namenszuordnung:\r\n");
    for(uint32_t i=0;i<names;i++){
        uint32_t name=u32(p->p+nt+i*4);unsigned index=u16(p->p+ot+i*2);
        if(index>=count)return error(p,"Exportname verweist auf ungueltigen Ordinalindex.");
        text(&p->out,"  ");if(!string_rva(p,name,4096))return error(p,"Ungueltiger oder nicht terminierter Exportname.");
        text(&p->out," | Ordinal ");number(&p->out,(uint64_t)base+index);text(&p->out," | RVA ");location(p,u32(p->p+ft+index*4));text(&p->out,"\r\n");
    }
    return 1;
}
static int imports(struct image *p) {
    uint32_t rva=0,size=0;if(!directory(p,1,&rva,&size))return error(p,"Ungueltiges Import-Verzeichnis.");
    text(&p->out,"\r\nIMPORTS (normale Importtabelle, keine Delay-Imports)\r\n");if(!rva){text(&p->out,"Keine normale Importtabelle.\r\n");return 1;}
    size_t start=0;if(size<20||!mapped(p,rva,size,&start))return error(p,"Import-Verzeichnis nicht eindeutig dateigedeckt.");
    uint32_t descriptors=size/20;if(descriptors>4096)return error(p,"Import-DLL-Anzahl ueber dem Analyse-Limit.");
    unsigned total=0;
    for(uint32_t i=0;i<descriptors;i++){
        const unsigned char *d=p->p+start+i*20;
        uint32_t original=u32(d),stamp=u32(d+4),chain=u32(d+8),name=u32(d+12),iat=u32(d+16);
        if(!original&&!stamp&&!chain&&!name&&!iat)return 1;
        if(!name||!iat)return error(p,"Unvollstaendiger Importdeskriptor.");
        text(&p->out,"DLL: ");if(!string_rva(p,name,4096))return error(p,"Ungueltiger DLL-Name.");text(&p->out,"\r\n");
        uint32_t thunk=original?original:iat;unsigned width=p->wide?8:4;int terminated=0;
        for(uint32_t j=0;j<16384;j++){
            if(++total>16384)return error(p,"Importanzahl ueber dem Analyse-Limit 16384.");
            uint64_t tr=(uint64_t)thunk+(uint64_t)j*width,ir=(uint64_t)iat+(uint64_t)j*width;
            size_t off=0;if(tr>UINT32_MAX||ir>UINT32_MAX||!mapped(p,(uint32_t)tr,width,&off))return error(p,"Import-Thunktabelle ungueltig oder nicht terminiert.");
            uint64_t value=p->wide?u64(p->p+off):u32(p->p+off);
            if(!value){terminated=1;break;}
            text(&p->out,"  IAT RVA ");location(p,(uint32_t)ir);text(&p->out," | ");
            uint64_t ordinal_flag=p->wide?0x8000000000000000ULL:0x80000000ULL;
            if(value&ordinal_flag){text(&p->out,"Ordinal ");number(&p->out,value&0xffff);}
            else {
                size_t hint=0;
                if(value>UINT32_MAX-2||!mapped(p,(uint32_t)value,2,&hint)){
                    if(original)return error(p,"Import-by-name-Zeiger ungueltig.");
                    text(&p->out,"gebundener IAT-Wert / kein Name: ");hex(&p->out,value,p->wide?16:8);
                }else{
                    text(&p->out,"Hint ");number(&p->out,u16(p->p+hint));text(&p->out," | ");
                    if(!string_rva(p,(uint32_t)value+2,4096))return error(p,"Ungueltiger Import-Funktionsname.");
                }
            }
            text(&p->out,"\r\n");
        }
        if(!terminated)return error(p,"Import-Thunktabelle ueberschreitet das Limit.");
    }
    return error(p,"Import-Verzeichnis ohne Null-Deskriptor.");
}
static void finish(struct output *o) {
    if(!o->truncated||!o->cap)return;
    static const char tail[]="\r\n[Bericht wegen Ausgabelimit gekuerzt.]\r\n";
    size_t length=sizeof(tail)-1;if(o->cap>length){size_t at=o->cap-length-1;for(size_t i=0;i<length;i++)o->p[at+i]=tail[i];o->p[o->cap-1]=0;}
}
struct probe_span {uint32_t start,length;};
static int probe_window(struct image *p,struct probe_span window) {
    uint32_t start=window.start,length=window.length;size_t offset=0;
    const char *reason=NULL;
    if((uint64_t)start+length>p->image_size)reason="Zielbereich liegt ausserhalb von SizeOfImage.";
    else if(!mapped(p,start,length,&offset))reason="Codefenster ist nicht vollstaendig und eindeutig dateigedeckt.";
    unsigned matches=0;
    if(!reason)for(uint32_t i=0;i<p->sections;i++){
        const unsigned char *s=p->p+p->section_at+i*40;
        uint32_t va=u32(s+12),raw=u32(s+16),virtual_size=u32(s+8),flags=u32(s+36);
        uint32_t span=virtual_size?virtual_size:raw;
        if(start>=va&&(uint64_t)start-va<span&&length<=(uint64_t)span-(start-va)&&
           (uint64_t)start-va<raw&&length<=(uint64_t)raw-(start-va)&&(flags&0x20000000U))matches++;
    }
    if(!reason&&matches!=1)reason="Codefenster liegt nicht vollstaendig in genau einer ausfuehrbaren Sektion.";
    text(&p->out,"\r\n");
    if(reason){
        text(&p->out,"WINDOW_UNAVAILABLE RVA=");hex(&p->out,start,8);
        text(&p->out," LENGTH=");hex(&p->out,length,8);return error(p,reason);
    }
    text(&p->out,"BEGIN_STATIC_WINDOW RVA=");hex(&p->out,start,8);
    text(&p->out," LENGTH=");hex(&p->out,length,8);text(&p->out," FILE_OFFSET=");hex(&p->out,offset,8);
    text(&p->out,"\r\nNur Datei-Bytes; kein Nachweis fuer Build, Namenpool oder funktionierende Spiel-Offsets.\r\n");
    static const char digits[]="0123456789ABCDEF";
    for(uint32_t row=0;row<length;row+=16){
        hex(&p->out,start+row,8);text(&p->out,": ");
        for(unsigned column=0;column<16;column++){
            unsigned value=p->p[offset+row+column];ch(&p->out,digits[value>>4]);ch(&p->out,digits[value&15]);
            if(column!=15)ch(&p->out,' ');
        }
        text(&p->out,"\r\n");
    }
    text(&p->out,"END_STATIC_WINDOW RVA=");hex(&p->out,start,8);text(&p->out,"\r\n");return 1;
}
static int probe_windows(struct image *p,uint16_t machine) {
    if(machine!=0x8664||!p->wide)return error(p,"Client-Codeauszuege erfordern AMD64 PE32+.");
    static const struct probe_span windows[]={
        {0x0214E000U,0x4000U},{0x02152D00U,0x400U},{0x017B1900U,0x2000U}
    };
    text(&p->out,"\r\nSTATISCHE CLIENT-CODEAUSZUEGE V2\r\n");
    text(&p->out,"SDK-Bezug fuer das erste Fenster: AppendString RVA 0x0214EC80.\r\n");
    text(&p->out,"Die zwei Zusatzfenster dokumentieren explizit begrenzte fehlende Codebereiche.\r\n");
    int complete=1;
    for(unsigned i=0;i<sizeof(windows)/sizeof(windows[0]);i++)if(!probe_window(p,windows[i]))complete=0;
    return complete;
}
static int inspect(const unsigned char *data,size_t size,char *report,size_t capacity,int probe) {
    struct image p; p.p=data;p.size=size;p.sections=p.headers=p.section_at=p.directories=p.directory_at=0;
    p.entry=p.image_size=0;p.string_budget=1048576;p.image_base=0;p.wide=0;p.out=(struct output){report,report?capacity:0,0,0};if(p.out.cap)report[0]=0;
    if(probe)text(&p.out,"NEO CLIENT PROBE V2 | STATISCHE DATEIPRUEFUNG\r\nZielbezeichnung: 10.40-CL-9380822 (nicht automatisch bestaetigt).\r\nBitte FortniteClient-Win64-Shipping.exe aus dem Neo-Client waehlen, nicht den Launcher.\r\n");
    else text(&p.out,"STELEX OFFLINE PE-ANALYSE\r\n");
    text(&p.out,"Adressen sind Datei-RVAs bzw. bevorzugte ImageBase; keine aktuellen Prozessadressen.\r\nKeine Erkennung interner Spielvariablen und kein Zugriff auf laufende Prozesse.\r\n\r\n");
    int valid=0;
    if(!data||!range(&p,0,64)||data[0]!='M'||data[1]!='Z'){error(&p,"Keine gueltige DOS-/PE-Datei.");goto done;}
    uint32_t pe=u32(data+60);
    if(pe<64||!range(&p,pe,24)||u32(data+pe)!=0x4550){error(&p,"PE-Signatur oder Dateikopf ungueltig.");goto done;}
    const unsigned char *coff=data+pe+4;uint16_t machine=u16(coff),optional=u16(coff+16);p.sections=u16(coff+2);
    if(!p.sections||p.sections>96){error(&p,"Nicht unterstuetzte Sektionsanzahl (1..96).");goto done;}
    uint64_t opt=(uint64_t)pe+24;
    if(!range(&p,opt,optional)||optional<2){error(&p,"Optional Header unvollstaendig.");goto done;}
    uint16_t magic=u16(data+(size_t)opt);p.wide=magic==0x20b;
    unsigned minimum=p.wide?112:96;
    if((magic!=0x10b&&magic!=0x20b)||optional<minimum){error(&p,"Nur vollstaendige PE32-/PE32+-Header werden unterstuetzt.");goto done;}
    p.directories=u32(data+(size_t)opt+(p.wide?108:92));
    if(p.directories>16||minimum+(uint64_t)p.directories*8>optional){error(&p,"Data-Directory-Anzahl oder Headerlaenge ungueltig.");goto done;}
    p.directory_at=(uint32_t)(opt+minimum);p.headers=u32(data+(size_t)opt+60);p.image_size=u32(data+(size_t)opt+56);p.entry=u32(data+(size_t)opt+16);
    p.image_base=p.wide?u64(data+(size_t)opt+24):u32(data+(size_t)opt+28);
    uint64_t table=opt+optional;
    if(table>UINT32_MAX||!range(&p,table,(uint64_t)p.sections*40)||p.headers<table+(uint64_t)p.sections*40||!range(&p,0,p.headers)){
        error(&p,"Sektionstabelle oder SizeOfHeaders ausserhalb der Datei.");goto done;
    }
    p.section_at=(uint32_t)table;
    for(uint32_t i=0;i<p.sections;i++){
        const unsigned char *s=data+p.section_at+i*40;
        uint32_t vs=u32(s+8),va=u32(s+12),raw=u32(s+16),file=u32(s+20);
        uint64_t span=vs>raw?vs:raw;
        if((raw&&(!range(&p,file,raw)||file<p.headers))||(uint64_t)va+span>0x100000000ULL||(probe&&(uint64_t)va+span>p.image_size)){error(&p,"Sektionsbereich ungueltig oder uebergelaufen.");goto done;}
        if(span && va<p.headers){error(&p,"Virtueller Sektionsbereich ueberlappt die Header.");goto done;}
        for(uint32_t j=0;j<i;j++){
            const unsigned char *other=data+p.section_at+j*40;
            uint32_t ov=u32(other+12),oraw=u32(other+16),of=u32(other+20),ovs=u32(other+8);uint64_t os=ovs>oraw?ovs:oraw;
            if((span&&os&&(uint64_t)va<(uint64_t)ov+os&&(uint64_t)ov<(uint64_t)va+span)||(raw&&oraw&&(uint64_t)file<(uint64_t)of+oraw&&(uint64_t)of<(uint64_t)file+raw)){
                error(&p,"Ueberlappende Sektionen: Dateioffsets waeren mehrdeutig.");goto done;
            }
        }
    }
    text(&p.out,p.wide?"Format: PE32+ (64-bit Header)\r\n":"Format: PE32 (32-bit Header)\r\n");
    text(&p.out,"Machine: ");hex(&p.out,machine,4);text(&p.out,machine==0x8664?" (AMD64)":machine==0x14c?" (x86)":machine==0xaa64?" (ARM64)":"");
    text(&p.out,"\r\nDateigroesse: ");number(&p.out,size);text(&p.out," Bytes\r\nBevorzugte ImageBase: ");hex(&p.out,p.image_base,p.wide?16:8);
    text(&p.out,"\r\nSizeOfImage: ");hex(&p.out,p.image_size,8);text(&p.out,"\r\nEntryPoint RVA: ");location(&p,p.entry);
    text(&p.out,"\r\nCOFF TimeDateStamp (nicht garantiert Build-Datum): ");hex(&p.out,u32(coff+4),8);
    text(&p.out,"\r\n\r\nSEKTIONEN\r\n");
    for(uint32_t i=0;i<p.sections;i++){
        const unsigned char *s=data+p.section_at+i*40;
        text(&p.out,"  ");for(unsigned k=0;k<8&&s[k];k++)byte_text(&p.out,s[k]);
        text(&p.out," | RVA ");hex(&p.out,u32(s+12),8);text(&p.out," | virtuelle Groesse ");hex(&p.out,u32(s+8),8);
        text(&p.out," | Datei ");hex(&p.out,u32(s+20),8);text(&p.out," | Dateigroesse ");hex(&p.out,u32(s+16),8);
        uint32_t flags=u32(s+36);text(&p.out," | Flags ");hex(&p.out,flags,8);text(&p.out," [");if(flags&0x40000000)ch(&p.out,'R');if(flags&0x80000000)ch(&p.out,'W');if(flags&0x20000000)ch(&p.out,'X');text(&p.out,"]\r\n");
    }
    if(probe){
        valid=probe_windows(&p,machine);
        text(&p.out,"\r\nKeine automatische Namenpool-/Offsetbestaetigung.\r\n");
        if(!p.out.truncated)text(&p.out,valid?"NEO_PROBE_V2_COMPLETE\r\n":"NEO_PROBE_V2_INCOMPLETE\r\n");
    }else{
        if(!exports(&p)||!imports(&p))goto done;
        text(&p.out,"\r\nAnalyse abgeschlossen. Symbolnamen sind nur vorhanden, wenn die Datei sie enthaelt.\r\n");
        valid=1;
    }
done:if(probe&&p.out.truncated)valid=0;finish(&p.out);return valid;
}
int pe_inspect(const unsigned char *data,size_t size,char *report,size_t capacity){return inspect(data,size,report,capacity,0);}
int neo_client_probe(const unsigned char *data,size_t size,char *report,size_t capacity){return inspect(data,size,report,capacity,1);}
