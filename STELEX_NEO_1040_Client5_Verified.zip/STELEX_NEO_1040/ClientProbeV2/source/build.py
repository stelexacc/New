"""Build the offline NEO Client Probe with Zig 0.15.2 or newer."""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig',default=os.environ.get('ZIG','zig'))
    args=parser.parse_args();zig=shutil.which(args.zig)
    if not zig:print('Zig fehlt; --zig PFAD_ZU_ZIG verwenden.',file=sys.stderr);return 1
    build=ROOT/'build';build.mkdir(exist_ok=True)
    dist=ROOT/'dist';dist.mkdir(exist_ok=True)
    env=os.environ.copy()
    env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(build/'zig-global-cache'))
    env.setdefault('ZIG_LOCAL_CACHE_DIR',str(build/'zig-local-cache'))
    report={'passed':False,'artifact':'NEO_Client_Probe.exe','probe_version':2,'target':'x86_64-windows-gnu','offline_file_diagnostic':True,'windows_started':False,'wine_started':False,'neo_client_tested':False,'steps':[]}
    pending=build/'NEO_Client_Probe.pending.exe'
    def run(name,command,cwd):
        print(name,flush=True)
        done=subprocess.run(command,cwd=cwd,env=env,text=True,capture_output=True,timeout=240)
        report['steps'].append({'name':name,'command':command,'exit_code':done.returncode,'stdout':done.stdout,'stderr':done.stderr})
        if done.stdout:print(done.stdout.rstrip(),flush=True)
        if done.stderr:print(done.stderr.rstrip(),file=sys.stderr,flush=True)
        if done.returncode:raise RuntimeError(name+' failed')
    try:
        run('Zig version',[zig,'version'],ROOT)
        run('Compile manifest',[zig,'rc','/fo',str(build/'app.res'),'app.rc'],ROOT/'source')
        command=[zig,'cc','-target','x86_64-windows-gnu','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wno-missing-field-initializers','-ffreestanding','-fno-builtin','-fshort-wchar','-nostdlib','-Wl,-e,mainCRTStartup','-Wl,--subsystem,windows','-Wl,--dynamicbase','-Wl,--nxcompat',str(ROOT/'source/app.c'),str(ROOT/'source/pe_inspect.c'),str(build/'app.res'),'-lkernel32','-luser32','-lgdi32','-lshell32','-lcomdlg32','-lbcrypt','-o',str(pending)]
        run('Compile Windows x64 offline probe',command,ROOT)
        target=dist/'NEO_Client_Probe.exe';shutil.copyfile(pending,target)
        report['passed']=True;report['output']={'file':'dist/'+target.name,'bytes':target.stat().st_size,'sha256':sha(target)}
        report['inputs']={p.name:sha(p) for p in sorted((ROOT/'source').iterdir()) if p.suffix in {'.c','.h','.rc','.manifest'}}
        print('Build passed: '+str(target),flush=True);return 0
    except (OSError,RuntimeError,subprocess.TimeoutExpired) as error:
        report['error']=str(error);print(str(error),file=sys.stderr);return 1
    finally:
        (ROOT/'research/BUILD_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');pending.unlink(missing_ok=True)

if __name__=='__main__':raise SystemExit(main())
