"""Build the standalone Windows-x64 frontend with Zig 0.15.2 or newer."""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent

def digest(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig',default=os.environ.get('ZIG','zig'))
    args=parser.parse_args()
    readiness_path=ROOT/'research/TARGET_READINESS.json'
    try:
        readiness=json.loads(readiness_path.read_text())
    except (OSError,ValueError) as error:
        print('Neo build blocked: target readiness is unavailable: '+str(error),file=sys.stderr)
        return 2
    if readiness.get('release_blocked',True):
        print('Neo build blocked: '+readiness.get('blocker','target reader verification is incomplete'),file=sys.stderr)
        (ROOT/'research/BUILD_REPORT.json').write_text(json.dumps({
            'passed':False,'compilation_attempted':False,'target':'10.40-CL-9380822',
            'blocked':True,'reason':readiness.get('blocker'),
            'windows_started':False,'live_fortnite_validated':False},indent=2)+'\n')
        return 2
    zig=shutil.which(args.zig)
    if not zig:
        print('Zig not found; pass --zig /path/to/zig',file=sys.stderr);return 1
    build=ROOT/'build';build.mkdir(exist_ok=True)
    env=os.environ.copy()
    env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(build/'zig-global-cache'))
    env.setdefault('ZIG_LOCAL_CACHE_DIR',str(build/'zig-local-cache'))
    report={'passed':False,'target':'x86_64-windows-gnu','steps':[],
            'windows_started':False,'live_neo_validated':False,'live_fortnite_validated':False}
    pending=build/'STELEX_NEO_1040.pending.exe'
    def run(label:str,command:list[str],cwd:Path)->None:
        print(label,flush=True)
        result=subprocess.run(command,cwd=cwd,env=env,text=True,capture_output=True,timeout=240)
        report['steps'].append({'name':label,'command':command,'exit_code':result.returncode,
                                'stdout':result.stdout,'stderr':result.stderr})
        if result.stdout:print(result.stdout.rstrip(),flush=True)
        if result.stderr:print(result.stderr.rstrip(),file=sys.stderr,flush=True)
        if result.returncode:raise RuntimeError(label+' failed')
    try:
        run('Zig version',[zig,'version'],ROOT)
        run('Compile icon/manifest',[zig,'rc','/fo',str(build/'app.res'),'app.rc'],ROOT/'source')
        sources=['era_desktop.c','era_memory.c','era_snapshot.c','era_core.c','era_identity.c','era_startup.c','era_probe_launcher.c']
        command=[zig,'cc','-target','x86_64-windows-gnu','-std=c11','-O2','-Wall','-Wextra','-Werror',
                 '-municode','-Wl,--subsystem,console','-Wl,--dynamicbase','-Wl,--nxcompat',
                 *[str(ROOT/'source'/name) for name in sources],str(build/'app.res'),
                 '-luser32','-lgdi32','-lshell32','-lversion','-lwinmm','-ladvapi32','-o',str(pending)]
        run('Compile Windows x64',command,ROOT)
        target=ROOT/'STELEX_NEO_1040.exe';shutil.copyfile(pending,target)
        report['passed']=True
        report['output']={'file':target.name,'size':target.stat().st_size,'sha256':digest(target)}
        report['inputs']={p.name:digest(p) for p in (ROOT/'source').iterdir()
                          if p.suffix in {'.c','.h','.rc','.manifest','.ico'}}
        print('Build passed: '+str(target),flush=True)
        return 0
    except (OSError,RuntimeError,subprocess.TimeoutExpired) as error:
        report['error']=str(error);print(str(error),file=sys.stderr);return 1
    finally:
        (ROOT/'research/BUILD_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
        pending.unlink(missing_ok=True)

if __name__=='__main__':raise SystemExit(main())
