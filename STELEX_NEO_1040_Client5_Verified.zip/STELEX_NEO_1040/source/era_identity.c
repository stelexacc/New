#include "era_identity.h"
#include <string.h>

#define NEO_CL UINT32_C(9380822)

/* Release/CL match the supplied screenshot and Vincent1232/Fortnite-sdks,
   commit f53c167439fd3b7b5bfbcf7e88f01a672852a280, 10.40/SDK.hpp:
   4.23.0-9380822+++Fortnite+Release-10.40. No live Neo client was inspected. */

static int digit(unsigned value){return value>='0'&&value<='9';}
static int suffix(unsigned value){return value==0||value=='-'||value==' ';}
static int numeric_boundary(unsigned value){return !digit(value)&&value!='.';}

static int text_length(const uint16_t*text,size_t chars,size_t*out){
    if(!text||chars==0||chars>4096||text[chars-1]!=0)return 0;
    for(size_t i=0;i+1<chars;i++)if(text[i]==0)return 0;
    *out=chars-1;return 1;
}

static int text_equal(const uint16_t*text,size_t available,const char*expected){
    size_t length=strlen(expected);
    if(length>available)return 0;
    for(size_t i=0;i<length;i++)if(text[i]!=(unsigned char)expected[i])return 0;
    return 1;
}

static int has_number_token(const uint16_t*text,size_t length,const char*token){
    size_t count=strlen(token);if(count>length)return 0;
    for(size_t i=0;i<=length-count;i++){
        if(i&&!numeric_boundary(text[i-1]))continue;
        if(!text_equal(text+i,length-i,token))continue;
        size_t end=i+count;
        if(end==length||numeric_boundary(text[end]))return 1;
    }
    return 0;
}

static int has_engine_version(const uint16_t*text,size_t length){
    const char expected[]="4.23.0";const size_t count=sizeof(expected)-1;
    if(count>length)return 0;
    for(size_t i=0;i<=length-count;i++){
        if(i&&!numeric_boundary(text[i-1]))continue;
        if(!text_equal(text+i,length-i,expected))continue;
        size_t end=i+count;
        if(end==length||numeric_boundary(text[end]))return 1;
        /* Win32 file-version resources may store the CL as a fourth part. */
        if(text[end]=='.'&&text_equal(text+end+1,length-end-1,"9380822")){
            end+=8;
            if(end==length||numeric_boundary(text[end]))return 1;
        }
    }
    return 0;
}

int era_identity_text16(const uint16_t*text,size_t chars){
    size_t length=0;if(!text_length(text,chars,&length))return 0;
    int changelist=has_number_token(text,length,"9380822");
    /* The fourth numeric component has a dot prefix, unlike a standalone CL. */
    if(!changelist){
        const char numeric[]="4.23.0.9380822";const size_t count=sizeof(numeric)-1;
        if(count<=length)for(size_t i=0;i<=length-count;i++){
            if(i&&!numeric_boundary(text[i-1]))continue;
            if(!text_equal(text+i,length-i,numeric))continue;
            size_t end=i+count;
            if(end==length||numeric_boundary(text[end])){changelist=1;break;}
        }
    }
    return changelist&&(has_number_token(text,length,"10.40")||has_engine_version(text,length));
}

static int ascii_marker(const unsigned char*data,size_t size,const char*marker){
    size_t count=strlen(marker);if(count>size)return 0;
    for(size_t i=0;i<=size-count;i++){
        if(data[i]!=(unsigned char)marker[0]||(i&&!numeric_boundary(data[i-1])))continue;
        if(memcmp(data+i,marker,count)!=0)continue;
        if(i+count==size||suffix(data[i+count]))return 1;
    }
    return 0;
}

static int wide_marker(const unsigned char*data,size_t size,const char*marker){
    size_t characters=strlen(marker),count=characters*2;if(count>size)return 0;
    for(size_t i=0;i<=size-count;i++){
        if(data[i]!=(unsigned char)marker[0]||data[i+1]!=0)continue;
        if(i>=2&&data[i-1]==0&&!numeric_boundary(data[i-2]))continue;
        size_t k=0;
        while(k<characters&&data[i+k*2]==(unsigned char)marker[k]&&data[i+k*2+1]==0)k++;
        if(k!=characters)continue;
        size_t end=i+count;
        if(end==size)return 1;
        if(size-end>=2&&data[end+1]==0&&suffix(data[end]))return 1;
    }
    return 0;
}

int era_identity_image(const unsigned char*data,size_t size){
    if(!data||!size)return 0;
    static const char*markers[]={
        "++Fortnite+Release-10.40-CL-9380822",
        "4.23.0-9380822+++Fortnite+Release-10.40"
    };
    for(unsigned i=0;i<sizeof(markers)/sizeof(markers[0]);i++)
        if(ascii_marker(data,size,markers[i])||wide_marker(data,size,markers[i]))return 1;
    return 0;
}

int era_identity_engine(unsigned short major,unsigned short minor,unsigned short patch,
                        uint32_t raw_changelist,const uint16_t*branch,size_t chars){
    const char expected[]="++Fortnite+Release-10.40";size_t length=0;
    return major==4&&minor==23&&patch==0&&(raw_changelist&UINT32_C(0x7FFFFFFF))==NEO_CL&&
        text_length(branch,chars,&length)&&length==sizeof(expected)-1&&text_equal(branch,length,expected);
}
