#include "era_types.h"
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <string.h>

#define ERA_PI 3.14159265358979323846

static int integer_bound(int value,int low,int high){
    return value<low?low:value>high?high:value;
}

static double absolute(double value){return value<0.0?-value:value;}

int era_vec_valid(EraVec3 value){
    return isfinite(value.x)&&isfinite(value.y)&&isfinite(value.z)&&
        absolute(value.x)<=100000000.0&&absolute(value.y)<=100000000.0&&
        absolute(value.z)<=100000000.0;
}

float era_distance(EraVec3 a,EraVec3 b){
    if(!era_vec_valid(a)||!era_vec_valid(b))return INFINITY;
    double x=(double)a.x-b.x,y=(double)a.y-b.y,z=(double)a.z-b.z;
    double distance=sqrt(x*x+y*y+z*z);
    return distance<FLT_MAX?(float)distance:INFINITY;
}

static EraVec3 invalid_vector(void){return (EraVec3){NAN,NAN,NAN};}

static EraQuat quat_normalized(EraQuat q){
    double length=sqrt((double)q.x*q.x+(double)q.y*q.y+(double)q.z*q.z+(double)q.w*q.w);
    if(!isfinite(length)||length<0.000001)return (EraQuat){0,0,0,0};
    return (EraQuat){(float)(q.x/length),(float)(q.y/length),
        (float)(q.z/length),(float)(q.w/length)};
}

static EraQuat quat_product(EraQuat parent,EraQuat local){
    return quat_normalized((EraQuat){
        parent.w*local.x+parent.x*local.w+parent.y*local.z-parent.z*local.y,
        parent.w*local.y-parent.x*local.z+parent.y*local.w+parent.z*local.x,
        parent.w*local.z+parent.x*local.y-parent.y*local.x+parent.z*local.w,
        parent.w*local.w-parent.x*local.x-parent.y*local.y-parent.z*local.z});
}

static EraVec3 quat_rotate(EraQuat q,EraVec3 p){
    q=quat_normalized(q);
    double tx=2.0*((double)q.y*p.z-(double)q.z*p.y);
    double ty=2.0*((double)q.z*p.x-(double)q.x*p.z);
    double tz=2.0*((double)q.x*p.y-(double)q.y*p.x);
    return (EraVec3){
        (float)(p.x+q.w*tx+q.y*tz-q.z*ty),
        (float)(p.y+q.w*ty+q.z*tx-q.x*tz),
        (float)(p.z+q.w*tz+q.x*ty-q.y*tx)};
}

EraQuat era_rotation_quat(EraVec3 rotator){
    if(!era_vec_valid(rotator))return (EraQuat){0,0,0,0};
    /* Unreal rotators use pitch, yaw, roll; positive pitch raises +X. */
    double pitch=remainder((double)rotator.x,360.0)*ERA_PI/360.0;
    double yaw=remainder((double)rotator.y,360.0)*ERA_PI/360.0;
    double roll=remainder((double)rotator.z,360.0)*ERA_PI/360.0;
    double sp=sin(pitch),cp=cos(pitch),sy=sin(yaw),cy=cos(yaw),sr=sin(roll),cr=cos(roll);
    return quat_normalized((EraQuat){
        (float)(cr*sp*sy-sr*cp*cy),(float)(-cr*sp*cy-sr*cp*sy),
        (float)(cr*cp*sy-sr*sp*cy),(float)(cr*cp*cy+sr*sp*sy)});
}

int era_transform_valid(const EraTransform*transform){
    if(!transform||!era_vec_valid(transform->translation)||!era_vec_valid(transform->scale))return 0;
    EraQuat q=transform->rotation;
    double norm=(double)q.x*q.x+(double)q.y*q.y+(double)q.z*q.z+(double)q.w*q.w;
    return isfinite(norm)&&norm>=0.5&&norm<=1.5&&
        absolute(transform->scale.x)>=0.00001&&absolute(transform->scale.x)<=1000.0&&
        absolute(transform->scale.y)>=0.00001&&absolute(transform->scale.y)<=1000.0&&
        absolute(transform->scale.z)>=0.00001&&absolute(transform->scale.z)<=1000.0;
}

EraVec3 era_transform_point(const EraTransform*transform,EraVec3 point){
    if(!era_transform_valid(transform)||!era_vec_valid(point))return invalid_vector();
    EraVec3 scaled={point.x*transform->scale.x,point.y*transform->scale.y,point.z*transform->scale.z};
    EraVec3 value=quat_rotate(transform->rotation,scaled);
    value.x+=transform->translation.x;value.y+=transform->translation.y;value.z+=transform->translation.z;
    return era_vec_valid(value)?value:invalid_vector();
}

EraTransform era_transform_combine(const EraTransform*parent,const EraTransform*local){
    EraTransform result={0};
    if(!era_transform_valid(parent)||!era_transform_valid(local))return result;
    result.rotation=quat_product(parent->rotation,local->rotation);
    result.translation=era_transform_point(parent,local->translation);
    result.scale=(EraVec3){parent->scale.x*local->scale.x,
        parent->scale.y*local->scale.y,parent->scale.z*local->scale.z};
    /* FTransform multiplication assumes no shear, matching the supplied ABI. */
    return era_transform_valid(&result)?result:(EraTransform){0};
}

int era_camera_valid(const EraCamera*camera){
    return camera&&era_vec_valid(camera->location)&&era_vec_valid(camera->rotation)&&
        isfinite(camera->fov)&&camera->fov>1.0f&&camera->fov<179.0f;
}

static int viewport_valid(int width,int height){return width>0&&width<=32768&&height>0&&height<=32768;}

int era_project(const EraCamera*camera,EraVec3 position,int width,int height,EraPoint*out){
    if(!out||!era_camera_valid(camera)||!era_vec_valid(position)||!viewport_valid(width,height))return 0;
    EraQuat rotation=era_rotation_quat(camera->rotation);
    EraVec3 forward=quat_rotate(rotation,(EraVec3){1,0,0});
    EraVec3 right=quat_rotate(rotation,(EraVec3){0,1,0});
    EraVec3 up=quat_rotate(rotation,(EraVec3){0,0,1});
    double x=(double)position.x-camera->location.x,y=(double)position.y-camera->location.y,z=(double)position.z-camera->location.z;
    double depth=x*forward.x+y*forward.y+z*forward.z;
    if(!isfinite(depth)||depth<=0.01)return 0;
    double focal=(double)width*0.5/tan((double)camera->fov*ERA_PI/360.0);
    double px=(double)width*0.5+(x*right.x+y*right.y+z*right.z)*focal/depth;
    double py=(double)height*0.5-(x*up.x+y*up.y+z*up.z)*focal/depth;
    if(!isfinite(px)||!isfinite(py)||absolute(px)>10000000.0||absolute(py)>10000000.0)return 0;
    *out=(EraPoint){(float)px,(float)py};return 1;
}

void era_config_defaults(EraConfig*config){
    if(!config)return;
    memset(config,0,sizeof(*config));
    config->aim_ring_enabled=1;
    config->aim_key=2;config->aim_part=1;config->aim_team_filter=1;
    config->aim_fov_degrees=8;config->aim_smooth=6;config->aim_strength=100;config->aim_gain_percent=100;
    config->esp_max_distance_m=500;
    config->crosshair_length=10;config->crosshair_gap=4;config->crosshair_thickness=3;
    config->crosshair_outline=1;config->crosshair_red=255;config->crosshair_green=255;config->crosshair_blue=255;
}

void era_config_clamp(EraConfig*config){
    if(!config)return;
#define BOOL_FIELD(field) config->field=config->field!=0
    BOOL_FIELD(aim_enabled);BOOL_FIELD(aim_ring_enabled);BOOL_FIELD(aim_team_filter);BOOL_FIELD(aim_hard_lock);
    BOOL_FIELD(esp_enabled);BOOL_FIELD(esp_box);BOOL_FIELD(esp_corner);BOOL_FIELD(esp_skeleton);
    BOOL_FIELD(esp_health);BOOL_FIELD(esp_shield);BOOL_FIELD(esp_names);BOOL_FIELD(esp_distance);
    BOOL_FIELD(esp_tracers);BOOL_FIELD(esp_head_dot);BOOL_FIELD(esp_team);
    BOOL_FIELD(crosshair_enabled);BOOL_FIELD(crosshair_outline);BOOL_FIELD(crosshair_dot);
#undef BOOL_FIELD
    config->aim_key=integer_bound(config->aim_key,1,254);
    config->aim_part=integer_bound(config->aim_part,0,2);
    config->aim_fov_degrees=integer_bound(config->aim_fov_degrees,1,45);
    config->aim_smooth=integer_bound(config->aim_smooth,1,30);
    config->aim_strength=integer_bound(config->aim_strength,1,100);
    config->aim_gain_percent=integer_bound(config->aim_gain_percent,10,200);
    config->esp_max_distance_m=integer_bound(config->esp_max_distance_m,1,2000);
    config->crosshair_preset=integer_bound(config->crosshair_preset,0,2);
    config->crosshair_length=integer_bound(config->crosshair_length,1,40);
    config->crosshair_gap=integer_bound(config->crosshair_gap,0,30);
    config->crosshair_thickness=integer_bound(config->crosshair_thickness,1,10);
    config->crosshair_red=integer_bound(config->crosshair_red,0,255);
    config->crosshair_green=integer_bound(config->crosshair_green,0,255);
    config->crosshair_blue=integer_bound(config->crosshair_blue,0,255);
}

void era_aim_reset(EraAimState*state){if(state)*state=(EraAimState){0};}

static int target_point(const EraFrame*frame,const EraConfig*config,const EraEntity*entity,
                        int width,int height,EraPoint*point,double*score){
    if(!entity->id||entity->id==frame->local_pawn||!entity->alive||entity->downed||
       !(entity->target_mask&(1U<<(unsigned)config->aim_part)))return 0;
    if(config->aim_team_filter&&(frame->local_team<=0||entity->team<=0||entity->team==frame->local_team))return 0;
    if(entity->health_valid&&(!isfinite(entity->health)||entity->health<=0.0f))return 0;
    EraVec3 position=entity->targets[config->aim_part];
    if(era_distance(frame->camera.location,position)>(float)config->esp_max_distance_m*100.0f||
       !era_project(&frame->camera,position,width,height,point))return 0;
    if(point->x<0||point->x>width||point->y<0||point->y>height)return 0;
    double x=(double)point->x-(double)width*0.5,y=(double)point->y-(double)height*0.5;
    double focal=(double)width*0.5/tan((double)frame->camera.fov*ERA_PI/360.0);
    double angle=atan2(hypot(x,y),focal)*180.0/ERA_PI;
    if(!isfinite(angle)||angle>config->aim_fov_degrees)return 0;
    *score=angle;return 1;
}

int era_aim_update(const EraFrame*frame,const EraConfig*supplied,EraAimState*state,
                   int width,int height,double seconds,int active,EraMotion*out){
    if(out)*out=(EraMotion){0};
    if(!state||!out)return 0;
    if(!supplied||!active||!supplied->aim_enabled){era_aim_reset(state);return 0;}
    EraConfig config=*supplied;era_config_clamp(&config);
    if(!frame||frame->status!=ERA_READY||!frame->local_alive||!frame->local_pawn||
       frame->count<0||frame->count>ERA_MAX_ENTITIES||!era_camera_valid(&frame->camera)||
       !viewport_valid(width,height)||!isfinite(seconds)||seconds<=0.0||seconds>0.25){
        state->residual_x=state->residual_y=0.0;
        if(!config.aim_hard_lock)state->target=0;
        return 0;
    }
    int best=-1;double closest=DBL_MAX;EraPoint chosen={0};
    for(int i=0;i<frame->count;i++){
        const EraEntity*entity=&frame->entities[i];EraPoint point;double score;
        if(config.aim_hard_lock&&state->target&&entity->id!=state->target)continue;
        if(!target_point(frame,&config,entity,width,height,&point,&score))continue;
        if(best<0||score<closest||(score==closest&&entity->id<frame->entities[best].id)){
            best=i;closest=score;chosen=point;
        }
    }
    if(best<0){
        state->residual_x=state->residual_y=0.0;
        if(!config.aim_hard_lock)state->target=0;
        return 0;
    }
    uint64_t target=frame->entities[best].id;
    if(state->target!=target||!isfinite(state->residual_x)||!isfinite(state->residual_y))
        state->residual_x=state->residual_y=0.0;
    state->target=target;out->target=target;
    double base=config.aim_hard_lock?(double)config.aim_strength/100.0:1.0/(double)config.aim_smooth;
    double fraction=base>=1.0?1.0:-expm1(log1p(-base)*seconds*60.0);
    fraction*=config.aim_gain_percent/100.0;if(fraction>1.0)fraction=1.0;
    double x=((double)chosen.x-width*0.5)*fraction+state->residual_x;
    double y=((double)chosen.y-height*0.5)*fraction+state->residual_y;
    double limit=12000.0*seconds;if(limit>256.0)limit=256.0;if(limit<1.0)limit=1.0;
    if(x>limit)x=limit;
    if(x< -limit)x=-limit;
    if(y>limit)y=limit;
    if(y< -limit)y=-limit;
    out->dx=(int)x;out->dy=(int)y;
    state->residual_x=x-out->dx;state->residual_y=y-out->dy;
    return 1;
}
