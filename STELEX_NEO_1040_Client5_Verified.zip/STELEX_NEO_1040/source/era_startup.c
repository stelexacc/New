#include "era_startup.h"

int era_startup_can_show(const EraFrame*frame,uint64_t now){
    if(!frame||!frame->pid||frame->module_base<UINT64_C(0x10000)||
       frame->module_base>=UINT64_C(0x0000800000000000)||
       (frame->attach_flags&ERA_ATTACH_COMPLETE)!=ERA_ATTACH_COMPLETE||
       frame->captured_ms>now)return 0;
    return now-frame->captured_ms<=ERA_STARTUP_MAX_AGE_MS;
}

int era_startup_update(EraStartupState*state,const EraFrame*frame,uint64_t now){
    if(!state)return ERA_STARTUP_NO_CHANGE;
    if(!era_startup_can_show(frame,now)){
        int result=state->attached?ERA_STARTUP_DETACHED:ERA_STARTUP_NO_CHANGE;
        *state=(EraStartupState){0};
        return result;
    }
    int result=!state->attached?ERA_STARTUP_ATTACHED:
        (state->pid!=frame->pid||state->module_base!=frame->module_base)?
        ERA_STARTUP_REPLACED:ERA_STARTUP_NO_CHANGE;
    state->attached=1;state->pid=frame->pid;state->module_base=frame->module_base;
    return result;
}
