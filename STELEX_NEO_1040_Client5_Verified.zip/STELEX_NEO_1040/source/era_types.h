#ifndef STELEX_ERA_TYPES_H
#define STELEX_ERA_TYPES_H
#include <stdint.h>
#include "era_diagnostics.h"
#define ERA_BUILD "10.40-CL-9380822"
#define ERA_MAX_ENTITIES 128
#define ERA_MAX_BONES 20
enum EraBoneSlot {
    ERA_HEAD=0,ERA_NECK,ERA_PELVIS,ERA_CHEST,
    ERA_L_UPPERARM,ERA_L_FOREARM,ERA_L_HAND,ERA_R_UPPERARM,ERA_R_FOREARM,ERA_R_HAND,
    ERA_L_THIGH,ERA_L_CALF,ERA_L_FOOT,ERA_R_THIGH,ERA_R_CALF,ERA_R_FOOT,
    ERA_SPINE_01,ERA_SPINE_02,ERA_L_CLAVICLE,ERA_R_CLAVICLE
};
typedef struct { float x,y,z; } EraVec3;
typedef struct { float x,y; } EraPoint;
typedef struct { EraVec3 location,rotation;float fov; } EraCamera;
typedef struct { float x,y,z,w; } EraQuat;
typedef struct { EraQuat rotation;EraVec3 translation;float pad0;EraVec3 scale;float pad1; } EraTransform;
typedef struct {
    uint64_t id;EraVec3 root,targets[3],bones[ERA_MAX_BONES];
    uint32_t target_mask,bone_mask;
    int team,alive,downed;float health,max_health,shield,max_shield;
    int health_valid,shield_valid;char name[96];
} EraEntity;
typedef enum {
    ERA_NOT_RUNNING=0,ERA_OPEN_DENIED,ERA_BUILD_UNVERIFIED,ERA_FINDING_ENGINE,
    ERA_WAITING_WORLD,ERA_WAITING_MATCH,ERA_READ_FAILED,ERA_READY,ERA_FINDING_NAMES
} EraStatus;
enum EraAttachFlags {
    ERA_ATTACH_PROCESS=1U,ERA_ATTACH_MODULE=2U,ERA_ATTACH_BUILD=4U,
    ERA_ATTACH_COMPLETE=7U
};
typedef struct {
    EraStatus status;uint32_t windows_error,pid;uint64_t captured_ms,sequence;
    uint64_t module_base;uint32_t attach_flags;
    uintptr_t game_window;uint64_t local_pawn;int local_team,local_alive;
    EraCamera camera;int count,names_ready;EraEntity entities[ERA_MAX_ENTITIES];
    EraNameDiagnostic name_diagnostic;
    uint32_t name_read_error;
    uint64_t name_failed_read_address,name_failed_read_bytes;
    uint32_t reader_generation;
} EraFrame;
typedef struct {
    int aim_enabled,aim_ring_enabled,aim_key,aim_part,aim_team_filter,aim_hard_lock;
    int aim_fov_degrees,aim_smooth,aim_strength,aim_gain_percent;
    int esp_enabled,esp_box,esp_corner,esp_skeleton,esp_health,esp_shield;
    int esp_names,esp_distance,esp_tracers,esp_head_dot,esp_team,esp_max_distance_m;
    int crosshair_enabled,crosshair_preset,crosshair_length,crosshair_gap;
    int crosshair_thickness,crosshair_outline,crosshair_dot;
    int crosshair_red,crosshair_green,crosshair_blue;
} EraConfig;
typedef struct { uint64_t target;double residual_x,residual_y; } EraAimState;
typedef struct { int dx,dy;uint64_t target; } EraMotion;
float era_distance(EraVec3 a,EraVec3 b);
int era_vec_valid(EraVec3 value);
int era_camera_valid(const EraCamera*camera);
int era_project(const EraCamera*camera,EraVec3 position,int width,int height,EraPoint*out);
EraQuat era_rotation_quat(EraVec3 rotator);
int era_transform_valid(const EraTransform*transform);
EraVec3 era_transform_point(const EraTransform*transform,EraVec3 point);
EraTransform era_transform_combine(const EraTransform*parent,const EraTransform*local);
void era_config_defaults(EraConfig*config);
void era_config_clamp(EraConfig*config);
void era_aim_reset(EraAimState*state);
int era_aim_update(const EraFrame*frame,const EraConfig*config,EraAimState*state,
                   int width,int height,double seconds,int active,EraMotion*out);
#endif
