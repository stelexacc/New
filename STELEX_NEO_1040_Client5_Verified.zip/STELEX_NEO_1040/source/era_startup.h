#ifndef STELEX_ERA_STARTUP_H
#define STELEX_ERA_STARTUP_H
#include "era_types.h"

/* Menu readiness is independent of match/aim readiness. The reader must
 * establish all three attach facts; gameplay data may still be unavailable. */
#define ERA_STARTUP_MAX_AGE_MS UINT64_C(5000)
typedef struct {
    int attached;
    uint32_t pid;
    uint64_t module_base;
} EraStartupState;

enum {
    ERA_STARTUP_NO_CHANGE=0,
    ERA_STARTUP_ATTACHED=1,
    ERA_STARTUP_DETACHED=2,
    ERA_STARTUP_REPLACED=3
};

int era_startup_can_show(const EraFrame*frame,uint64_t now);
int era_startup_update(EraStartupState*state,const EraFrame*frame,uint64_t now);
#endif
