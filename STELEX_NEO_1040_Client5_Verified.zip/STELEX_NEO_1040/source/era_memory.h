#ifndef STELEX_ERA_MEMORY_H
#define STELEX_ERA_MEMORY_H
#include "era_types.h"
#ifdef _WIN32
#include <windows.h>
typedef struct EraReader EraReader;
EraReader*era_reader_create(void);
void era_reader_destroy(EraReader*reader);
void era_reader_poll(EraReader*reader,EraFrame*frame);
const wchar_t*era_status_text(EraStatus status);
#endif
#endif
