#ifndef STELEX_ERA_DIAGNOSTICS_H
#define STELEX_ERA_DIAGNOSTICS_H
#include <stddef.h>
#include <stdint.h>

typedef enum {
    ERA_NAME_STAGE_IDLE=0,ERA_NAME_STAGE_APPEND,ERA_NAME_STAGE_GETTER,
    ERA_NAME_STAGE_CANDIDATE,ERA_NAME_STAGE_SENTINELS,
    ERA_NAME_STAGE_STABILITY,ERA_NAME_STAGE_READY
} EraNameStage;
typedef enum {
    ERA_NAME_REASON_NONE=0,ERA_NAME_REASON_READ_FAILED,
    ERA_NAME_REASON_PREFIX_MISMATCH,ERA_NAME_REASON_GETTER_BOUNDS,
    ERA_NAME_REASON_NO_RIP_CANDIDATE,ERA_NAME_REASON_INVALID_POINTER,
    ERA_NAME_REASON_SENTINEL_MISMATCH,ERA_NAME_REASON_AMBIGUOUS,
    ERA_NAME_REASON_UNSTABLE
} EraNameReason;
typedef struct {
    EraNameStage stage;EraNameReason reason;
    uint64_t failed_address;size_t failed_bytes;int64_t getter_rva;
    unsigned attempt,rip_candidates,data_candidates,readable_candidates;
    unsigned valid_candidates,sentinels_matched;
    int entry_offset;
} EraNameDiagnostic;

/* Counts and outcome describe the latest actual discovery attempt. A failed
   candidate read is not evidence that the entire process is inaccessible.
   valid_candidates counts accepted layouts; sentinels_matched is at most 5.
   failed_address/failed_bytes are set only for a selected failed read. */
const char*era_name_stage_text(EraNameStage stage);
const char*era_name_reason_text(EraNameReason reason);
#endif
