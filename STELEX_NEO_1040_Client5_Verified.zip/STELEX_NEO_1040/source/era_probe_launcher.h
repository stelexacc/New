#ifndef STELEX_ERA_PROBE_LAUNCHER_H
#define STELEX_ERA_PROBE_LAUNCHER_H
#include <stddef.h>
#include <stdint.h>

typedef enum {
    ERA_PROBE_FAILURE_NONE=0,ERA_PROBE_FAILURE_LOCATION,ERA_PROBE_FAILURE_OPEN,
    ERA_PROBE_FAILURE_HASH,ERA_PROBE_FAILURE_START
} EraProbeLaunchFailure;
typedef struct {
    int launched,used_attached_path;
    EraProbeLaunchFailure failure;
    uint32_t windows_error,shell_code;
} EraProbeLaunchResult;

/* Starts only the fixed, SHA-256-verified bundled offline probe. attached_pid
   is used for ordinary executable-path metadata, never memory access. Missing
   or unreadable client paths select the probe's file picker instead. */
EraProbeLaunchResult era_probe_launch(uintptr_t owner,uint32_t attached_pid);
const wchar_t*era_probe_failure_text(EraProbeLaunchFailure failure);
#endif
