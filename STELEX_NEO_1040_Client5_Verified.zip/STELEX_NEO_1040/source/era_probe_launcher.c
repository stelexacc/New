#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#include <windows.h>
#include <wincrypt.h>
#include <shellapi.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "era_probe_launcher.h"

enum {PROBE_PATH_CAPACITY=32768};
static const unsigned char probe_expected_sha256[32]={
    0x76,0x3a,0x8c,0x93,0xec,0x4f,0x63,0x1f,0xe5,0xe8,0xb0,0x94,0x76,0x63,0x33,0xa5,
    0xfb,0x66,0x86,0x84,0x61,0x3b,0xfa,0x55,0x2d,0xb7,0x95,0xef,0x28,0xa5,0xcb,0x33
};
typedef struct {
    wchar_t probe[PROBE_PATH_CAPACITY],directory[PROBE_PATH_CAPACITY];
    wchar_t client[PROBE_PATH_CAPACITY],arguments[PROBE_PATH_CAPACITY];
} ProbePaths;

static int probe_sha256_matches(HANDLE file,const unsigned char expected[32],DWORD*error){
    HCRYPTPROV provider=0;HCRYPTHASH hash=0;int matched=0;
    LARGE_INTEGER size,zero;zero.QuadPart=0;*error=ERROR_SUCCESS;
    if(!GetFileSizeEx(file,&size)||!SetFilePointerEx(file,zero,NULL,FILE_BEGIN)){*error=GetLastError();return 0;}
    if(size.QuadPart<0||size.QuadPart>16LL*1024*1024){*error=ERROR_FILE_TOO_LARGE;return 0;}
    if(!CryptAcquireContextW(&provider,NULL,MS_ENH_RSA_AES_PROV_W,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)||
       !CryptCreateHash(provider,CALG_SHA_256,0,0,&hash)){*error=GetLastError();goto cleanup;}
    unsigned char buffer[16384],digest[32];uint64_t total=0;
    for(;;){
        DWORD bytes=0;
        if(!ReadFile(file,buffer,sizeof(buffer),&bytes,NULL)){*error=GetLastError();goto cleanup;}
        if(!bytes)break;
        total+=bytes;
        if(total>(uint64_t)size.QuadPart){*error=ERROR_INVALID_DATA;goto cleanup;}
        if(!CryptHashData(hash,buffer,bytes,0)){*error=GetLastError();goto cleanup;}
    }
    if(total!=(uint64_t)size.QuadPart){*error=ERROR_HANDLE_EOF;goto cleanup;}
    DWORD digest_bytes=sizeof(digest);
    if(!CryptGetHashParam(hash,HP_HASHVAL,digest,&digest_bytes,0)){*error=GetLastError();goto cleanup;}
    matched=digest_bytes==sizeof(digest)&&memcmp(digest,expected,sizeof(digest))==0;
    if(!matched)*error=ERROR_INVALID_DATA;
cleanup:
    if(hash)CryptDestroyHash(hash);if(provider)CryptReleaseContext(provider,0);
    return matched;
}
static int probe_paths(ProbePaths*paths,DWORD*error){
    DWORD length=GetModuleFileNameW(NULL,paths->probe,PROBE_PATH_CAPACITY);
    if(!length){*error=GetLastError();return 0;}
    if(length>=PROBE_PATH_CAPACITY){*error=ERROR_INSUFFICIENT_BUFFER;return 0;}
    wchar_t*separator=wcsrchr(paths->probe,L'\\');
    if(!separator){*error=ERROR_BAD_PATHNAME;return 0;}
    static const wchar_t suffix[]=L"ClientProbeV2\\NEO_Client_Probe.exe";
    size_t parent=(size_t)(separator-paths->probe)+1;
    if(parent+(sizeof(suffix)/sizeof(suffix[0]))>PROBE_PATH_CAPACITY){*error=ERROR_FILENAME_EXCED_RANGE;return 0;}
    memcpy(paths->probe+parent,suffix,sizeof(suffix));
    wcscpy(paths->directory,paths->probe);separator=wcsrchr(paths->directory,L'\\');*separator=0;
    return 1;
}
static int probe_attached_client(ProbePaths*paths,uint32_t pid){
    if(!pid)return 0;
    HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,(DWORD)pid);
    if(!process)return 0;
    DWORD length=PROBE_PATH_CAPACITY;
    int found=QueryFullProcessImageNameW(process,0,paths->client,&length)&&length>0&&length<PROBE_PATH_CAPACITY;
    CloseHandle(process);
    if(!found)return 0;
    paths->client[length]=0;
    const wchar_t*basename=wcsrchr(paths->client,L'\\');basename=basename?basename+1:paths->client;
    if(_wcsicmp(basename,L"FortniteClient-Win64-Shipping.exe")||wcschr(paths->client,L'"')||length>PROBE_PATH_CAPACITY-3)return 0;
    HANDLE file=CreateFileW(paths->client,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
        NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return 0;
    CloseHandle(file);
    /* A Windows filename cannot contain a quote; the validated executable
       basename cannot end in a slash, so one surrounding pair is sufficient. */
    paths->arguments[0]=L'"';memcpy(paths->arguments+1,paths->client,(size_t)length*sizeof(wchar_t));
    paths->arguments[length+1]=L'"';paths->arguments[length+2]=0;return 1;
}
EraProbeLaunchResult era_probe_launch(uintptr_t owner,uint32_t attached_pid){
    EraProbeLaunchResult result={0};DWORD error=ERROR_SUCCESS;
    ProbePaths*paths=calloc(1,sizeof(*paths));HANDLE probe=INVALID_HANDLE_VALUE;
    if(!paths){result.failure=ERA_PROBE_FAILURE_LOCATION;result.windows_error=ERROR_NOT_ENOUGH_MEMORY;return result;}
    if(!probe_paths(paths,&error)){result.failure=ERA_PROBE_FAILURE_LOCATION;result.windows_error=error;goto cleanup;}
    /* Deny writes and replacement across verification and process creation. */
    probe=CreateFileW(paths->probe,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);
    if(probe==INVALID_HANDLE_VALUE){result.failure=ERA_PROBE_FAILURE_OPEN;result.windows_error=GetLastError();goto cleanup;}
    if(!probe_sha256_matches(probe,probe_expected_sha256,&error)){result.failure=ERA_PROBE_FAILURE_HASH;result.windows_error=error;goto cleanup;}
    result.used_attached_path=probe_attached_client(paths,attached_pid);
    if(!result.used_attached_path)wcscpy(paths->arguments,L"--choose-file");
    SetLastError(ERROR_SUCCESS);
    uintptr_t started=(uintptr_t)ShellExecuteW((HWND)owner,L"open",paths->probe,paths->arguments,paths->directory,SW_SHOWNORMAL);
    if(started<=32){
        result.failure=ERA_PROBE_FAILURE_START;result.shell_code=(uint32_t)started;
        result.windows_error=GetLastError();if(!result.windows_error)result.windows_error=ERROR_OPEN_FAILED;
        goto cleanup;
    }
    result.launched=1;
cleanup:
    if(probe!=INVALID_HANDLE_VALUE)CloseHandle(probe);free(paths);return result;
}
const wchar_t*era_probe_failure_text(EraProbeLaunchFailure failure){
    switch(failure){
    case ERA_PROBE_FAILURE_LOCATION:return L"Programmordner konnte nicht bestimmt werden";
    case ERA_PROBE_FAILURE_OPEN:return L"ClientProbeV2\\NEO_Client_Probe.exe fehlt oder ist nicht lesbar";
    case ERA_PROBE_FAILURE_HASH:return L"SHA-256 der Client Probe nicht bestaetigt; ZIP vollstaendig neu entpacken";
    case ERA_PROBE_FAILURE_START:return L"Verifizierte Client Probe konnte nicht gestartet werden";
    default:return L"Client Probe gestartet";
    }
}
