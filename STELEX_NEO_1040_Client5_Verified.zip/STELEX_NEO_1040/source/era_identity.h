#ifndef STELEX_NEO_IDENTITY_H
#define STELEX_NEO_IDENTITY_H
#include <stddef.h>
#include <stdint.h>
/* Text lengths include the terminating UTF-16 NUL and are capped at4096. */
int era_identity_text16(const uint16_t*text,size_t chars);
/* A bounded file-image marker check; it does not establish a file hash. */
int era_identity_image(const unsigned char*data,size_t size);
int era_identity_engine(unsigned short major,unsigned short minor,unsigned short patch,
                        uint32_t raw_changelist,const uint16_t*branch,size_t chars);
#endif
