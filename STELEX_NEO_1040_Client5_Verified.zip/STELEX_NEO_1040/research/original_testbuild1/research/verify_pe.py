"""Inspect the built Windows EXE without executing it. Requires pefile."""
from pathlib import Path
import hashlib,json
import pefile

ROOT=Path(__file__).resolve().parent.parent

def main():
 path=ROOT/'STELEX_NEO_1040.exe'
 pe=pefile.PE(str(path))
 imports={entry.dll.decode('ascii'):[item.name.decode('ascii') if item.name else '#'+str(item.ordinal)
           for item in entry.imports] for entry in pe.DIRECTORY_ENTRY_IMPORT}
 names={name for entries in imports.values() for name in entries}
 banned={'WriteProcessMemory','CreateRemoteThread','DeviceIoControl','OpenSCManagerW','SetWindowsHookExW','NtLoadDriver'}
 checks={
   'windows_amd64':pe.FILE_HEADER.Machine==0x8664,
   'pe32_plus':pe.OPTIONAL_HEADER.Magic==0x20b,
   'console_subsystem':pe.OPTIONAL_HEADER.Subsystem==3,
   'has_memory_reader':'ReadProcessMemory' in names,
   'has_input':'SendInput' in names,
   'excluded_imports_absent':not bool(names&banned),
   'aslr':bool(pe.OPTIONAL_HEADER.DllCharacteristics&0x40),
   'nx':bool(pe.OPTIONAL_HEADER.DllCharacteristics&0x100)}
 report={'passed':all(checks.values()),'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'machine':hex(pe.FILE_HEADER.Machine),'subsystem':pe.OPTIONAL_HEADER.Subsystem,
         'format':hex(pe.OPTIONAL_HEADER.Magic),'checks':checks,'imports':imports,
         'windows_started':False,'live_fortnite_validated':False,
         'scope':'Static PE inspection only; import checks do not prove runtime behavior.'}
 (ROOT/'research/PE_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
 if not report['passed']:raise SystemExit('Static PE inspection failed')
 print('Final EXE static PE inspection passed; no startup validation.')

if __name__=='__main__':main()
