"""Extract numeric metadata from the pinned 10.40 SDK without executing it.

Only layout facts and citations are emitted; downloaded SDK source is not
redistributed. Missing required fields fail extraction explicitly. The SDK's
absence of GNames/GWorld and its private skeleton layout are recorded rather
than replaced with guesses.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path

COMMIT='f53c167439fd3b7b5bfbcf7e88f01a672852a280'
BASE='https://github.com/Vincent1232/Fortnite-sdks/blob/'+COMMIT+'/10.40/'
BUILD='10.40-CL-9380822'
ENGINE_MARKER='4.23.0-9380822+++Fortnite+Release-10.40'
FIELDS={
 'CoreUObject_classes.hpp':{
  'UObject':['Vft','Flags','Index','Class','Name','Outer'],
  'UStruct':['Super']},
 'CoreUObject_structs.hpp':{
  'FVector':['X','Y','Z'],'FQuat':['X','Y','Z','W'],
  'FTransform':['Rotation','Translation','Scale3D']},
 'Engine_classes.hpp':{
  'UEngine':['GameViewport'],'UGameViewportClient':['World'],
  'UWorld':['OwningGameInstance','GameState'],'UGameInstance':['LocalPlayers'],
  'UPlayer':['PlayerController'],
  'APlayerController':['AcknowledgedPawn','PlayerCameraManager'],
  'APlayerCameraManager':['CameraCachePrivate'],
  'AGameStateBase':['PlayerArray'],
  'APlayerState':['PawnPrivate','PlayerNamePrivate'],'APawn':['PlayerState'],
  'AActor':['RootComponent'],'ACharacter':['Mesh'],
  'USceneComponent':['AttachParent','AttachSocketName','RelativeLocation',
                    'RelativeRotation','RelativeScale3D','bAbsoluteLocation',
                    'bAbsoluteRotation','bAbsoluteScale'],
  'USkinnedMeshComponent':['SkeletalMesh'],
  'USkeletalMeshComponent':['CachedBoneSpaceTransforms','CachedComponentSpaceTransforms'],
  'USkeletalMesh':['MorphTargets','PostProcessAnimBlueprint']},
 'Engine_structs.hpp':{
  'FMinimalViewInfo':['Location','Rotation','FOV','AspectRatio',
                    'bConstrainAspectRatio','ProjectionMode','OffCenterProjectionOffset'],
  'FCameraCacheEntry':['POV']},
 'FortniteGame_classes.hpp':{
  'AFortPawn':['HealthSet','bIsDying','bIsDBNO'],
  'AFortPlayerStateAthena':['TeamIndex'],
  'UFortHealthSet':['Health','MaxHealth','CurrentShield','Shield']},
 'GameplayAbilities_structs.hpp':{
  'FGameplayAttributeData':['BaseValue','CurrentValue']},
 'FortniteGame_structs.hpp':{
  'FFortGameplayAttributeData':['Minimum','Maximum','bIsCurrentClamped']}
}
HEX=r'0x[0-9A-Fa-f]+'

def type_block(text:str,name:str)->tuple[str,int,int]:
    match=re.search(r'^(?:class|struct) (?:alignas\([^\n]+?\) )?'+re.escape(name)+r'\b',text,re.M)
    if not match:raise ValueError('Missing type '+name)
    end=text.find('\n};',match.end())
    if end<0:raise ValueError('Unterminated type '+name)
    return text[match.start():end+3],match.start(),text.count('\n',0,match.start())+1

def member(text:str,filename:str,owner:str,field:str)->dict:
    block,start,first_line=type_block(text,owner)
    matches=[]
    for number,line in enumerate(block.splitlines(),first_line):
        if not re.search(r'\b'+re.escape(field)+r'(?:\s*:\s*\d+)?\s*;',line):continue
        location=re.search(r'//\s*(?:Mask\s*:\s*'+HEX+r'\s+)?('+HEX+r')\(('+HEX+r')\)',line)
        if not location:location=re.search(r'//\s*\(('+HEX+r')\[('+HEX+r')\]\)',line)
        if not location:continue
        row={'offset':int(location[1],16),'offset_hex':hex(int(location[1],16)),
             'size':int(location[2],16),'source':BASE+'SDK/'+filename+'#L'+str(number),
             'source_line':number,'kind':'sdk_member_comment'}
        mask=re.search(r'Mask\s*:\s*('+HEX+r')',line)
        if mask:
            value=int(mask[1],16);row.update(bit_mask=value,bit_mask_hex=hex(value))
            if value>0 and value&(value-1)==0:row['bit_index']=value.bit_length()-1
        if line.lstrip().startswith('//'):row['declaration_commented_out']=True
        matches.append(row)
    if not matches:raise ValueError('Missing member offset '+owner+'.'+field+' in '+filename)
    if len(matches)!=1:raise ValueError('Ambiguous member offset '+owner+'.'+field+' in '+filename)
    return matches[0]

def require(pattern:str,text:str,label:str)->re.Match:
    match=re.search(pattern,text,re.S)
    if not match:raise ValueError('Missing/changed declaration '+label)
    return match

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk-dir',type=Path,required=True,help='Directory containing Basic.hpp and Engine_classes.hpp')
    args=parser.parse_args();directory=args.sdk_dir
    report={'build':BUILD,'engine_version':'4.23.0','sdk_repository':'Vincent1232/Fortnite-sdks',
            'sdk_commit':COMMIT,'sdk_sources_redistributed':False,'live_validated':False,
            'facts':{},'type_sizes':{},'source_sha256':{},'extraction_errors':[],
            'missing_metadata':[],
            'derived_not_live_validated':[
             'Calculated x64 ABI fields in Basic.hpp require ordinary 8-byte pointers and declared packing.',
             'Private padding in USkeletalMesh bounds a search region; it does not identify a reference-skeleton member.',
             'CachedComponentSpaceTransforms availability and freshness are not proven.',
             'A matching public SDK is not a live dump of the modified Neo client.'
            ]}
    facts=report['facts'];errors=report['extraction_errors'];loaded={}
    def load(filename:str)->str:
        if filename not in loaded:
            path=directory/filename
            data=path.read_bytes();loaded[filename]=data.decode('utf-8-sig')
            report['source_sha256']['SDK/'+filename]=hashlib.sha256(data).hexdigest()
        return loaded[filename]
    try:
        header=(directory.parent/'SDK.hpp').read_bytes()
        report['source_sha256']['SDK.hpp']=hashlib.sha256(header).hexdigest()
        marker=require(r'//\s*'+re.escape(ENGINE_MARKER)+r'\s*\n',header.decode('utf-8-sig'),'exact SDK engine/release/CL header')
        report['build_evidence']={'marker':ENGINE_MARKER,'source':BASE+'SDK.hpp#L4'}
    except (OSError,ValueError) as error:errors.append(str(error))
    for filename,classes in FIELDS.items():
        try:text=load(filename)
        except (OSError,ValueError) as error:errors.append(str(error));continue
        for owner,fields in classes.items():
            for field in fields:
                try:facts[owner+'.'+field]=member(text,filename,owner,field)
                except ValueError as error:errors.append(str(error))
    for filename,types in {
        'CoreUObject_classes.hpp':['UObject'],
        'CoreUObject_structs.hpp':['FVector','FQuat','FTransform'],
        'Engine_structs.hpp':['FMinimalViewInfo','FCameraCacheEntry'],
        'Engine_classes.hpp':['USkeletalMesh']
    }.items():
        for owner in types:
            try:
                text=load(filename);_,start,line=type_block(text,owner)
                size=re.search(r'//\s*('+HEX+r')\s*\(('+HEX+r')\s*-\s*('+HEX+r')\)\s*\n//[^\n]*\n$',text[:start])
                if not size:raise ValueError('Missing type-size comment '+owner)
                if int(size[2],16)-int(size[3],16)!=int(size[1],16):raise ValueError('Inconsistent type-size comment '+owner)
                report['type_sizes'][owner]={'size':int(size[2],16),'size_hex':hex(int(size[2],16)),
                    'inherited_size':int(size[3],16),'source':BASE+'SDK/'+filename+'#L'+str(line-2),
                    'kind':'sdk_type_size_comment'}
            except (OSError,ValueError) as error:errors.append(str(error))
    try:
        functions=load('CoreUObject_functions.cpp')
        match=require(r'UObject::GObjects\s*=\s*reinterpret_cast<TUObjectArray\*>\(uintptr_t\(GetModuleHandle\(0\)\)\s*\+\s*('+HEX+r')\)',functions,'GObjects module-relative address')
        line=functions.count('\n',0,match.start())+1
        facts['GObjects']={'offset':int(match[1],16),'offset_hex':hex(int(match[1],16)),
                          'source':BASE+'SDK/CoreUObject_functions.cpp#L'+str(line),
                          'source_line':line,'kind':'sdk_module_relative_address'}
    except (OSError,ValueError) as error:errors.append(str(error))
    try:
        basic=load('Basic.hpp')
        array,_,array_line=type_block(basic,'TUObjectArray')
        require(r'ElementsPerChunk\s*=\s*0x10000\s*,',array,'TUObjectArray.ElementsPerChunk')
        require(r'struct FUObjectItem\s*\{\s*class UObject\* Object;\s*uint8 Pad\[0x10\];\s*\};',array,'FUObjectItem pointer and 16-byte padding')
        require(r'FUObjectItem\*\* Objects;\s*uint8 Pad_0\[0x08\];\s*int32 MaxElements;\s*int32 NumElements;\s*int32 MaxChunks;\s*int32 NumChunks;',array,'TUObjectArray data fields')
        for field,offset,size in [('Objects',0,8),('MaxElements',16,4),('NumElements',20,4),('MaxChunks',24,4),('NumChunks',28,4)]:
            facts['TUObjectArray.'+field]={'offset':offset,'offset_hex':hex(offset),'size':size,
                'source':BASE+'SDK/Basic.hpp#L'+str(array_line),'kind':'calculated_x64_abi_layout',
                'assumptions':'8-byte pointers, int32=4 bytes, SDK #pragma pack(push,0x08)'}
        facts['TUObjectArray.ElementsPerChunk']={'value':65536,'value_hex':'0x10000',
            'source':BASE+'SDK/Basic.hpp#L'+str(array_line),'kind':'sdk_constant'}
        facts['FUObjectItem.Stride']={'value':24,'value_hex':'0x18',
            'source':BASE+'SDK/Basic.hpp#L'+str(array_line),'kind':'calculated_x64_abi_layout',
            'derivation':'8-byte UObject pointer followed by uint8 Pad[0x10]'}
        fname,_,fname_line=type_block(basic,'FName')
        require(r'int32 ComparisonIndex;\s*int32 Number;',fname,'FName two int32 fields')
        for field,offset in [('ComparisonIndex',0),('Number',4)]:
            facts['FName.'+field]={'offset':offset,'offset_hex':hex(offset),'size':4,
                'source':BASE+'SDK/Basic.hpp#L'+str(fname_line),'kind':'calculated_x64_abi_layout'}
        append=require(r'AppendString\s*=\s*reinterpret_cast<[^;]+GetModuleHandle\(0\)\)\s*\+\s*('+HEX+r')',fname,'FName AppendString module-relative address')
        line=fname_line+fname.count('\n',0,append.start())
        facts['FName.AppendString']={'offset':int(append[1],16),'offset_hex':hex(int(append[1],16)),
            'source':BASE+'SDK/Basic.hpp#L'+str(line),'kind':'sdk_module_relative_function_address',
            'note':'Function address, not a GNames/FNamePool global or permission to call remote code.'}
    except (OSError,ValueError) as error:errors.append(str(error))
    try:
        lower=facts['USkeletalMesh.MorphTargets']['offset']+facts['USkeletalMesh.MorphTargets']['size']
        upper=facts['USkeletalMesh.PostProcessAnimBlueprint']['offset']
        mesh,_,line=type_block(load('Engine_classes.hpp'),'USkeletalMesh')
        pad=require(r'\bPad_B4C\[('+HEX+r')\];',mesh,'USkeletalMesh private padding Pad_B4C')
        if upper-lower!=int(pad[1],16):raise ValueError('USkeletalMesh private region endpoints disagree with pad size')
        facts['USkeletalMesh.PrivateReferenceSkeletonCandidateRegion']={
            'offset':lower,'offset_hex':hex(lower),'end_exclusive':upper,'end_exclusive_hex':hex(upper),
            'size':upper-lower,'source':BASE+'SDK/Engine_classes.hpp#L'+str(line+mesh.count('\n',0,pad.start())),
            'kind':'private_padding_region',
            'note':'Bounds only; neither FReferenceSkeleton nor its internal arrays have named SDK fields.'}
        pov=facts['APlayerCameraManager.CameraCachePrivate']['offset']+facts['FCameraCacheEntry.POV']['offset']
        facts['CameraPOV']={'offset':pov,'offset_hex':hex(pov),'kind':'composite_member_offset',
            'components':['APlayerCameraManager.CameraCachePrivate','FCameraCacheEntry.POV'],
            'source':[facts['APlayerCameraManager.CameraCachePrivate']['source'],facts['FCameraCacheEntry.POV']['source']]}
    except (KeyError,OSError,ValueError) as error:errors.append(str(error))
    report['missing_metadata']=[
        {'name':'GNames/FNamePool global','reason':'No global is declared by this SDK. FName uses an AppendString function address; it does not expose pool placement or entry packing.'},
        {'name':'GWorld global','reason':'No GWorld module-relative address is declared by the inspected files; the reader must use independently validated object traversal.'},
        {'name':'FReferenceSkeleton and FMeshBoneInfo layouts','reason':'USkeletalMesh private padding has no named reference-skeleton fields. Candidate arrays require structural validation; no fixed bone index is supplied.'},
        {'name':'Live Neo client compatibility and cached-pose liveness','reason':'Public SDK comments and the user version screenshot do not establish readability or runtime freshness.'}
    ]
    report['extraction_passed']=not errors
    output=Path(__file__).with_name('SDK_FACTS.json')
    output.write_text(json.dumps(report,indent=2)+'\n')
    if errors:
        for error in errors:print('ERROR:',error)
        return 1
    print('Extracted',len(facts),'10.40 facts with pinned-source citations; no live validation.')
    return 0

if __name__=='__main__':raise SystemExit(main())
