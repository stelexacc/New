"""Compare decoder constants to numeric facts extracted from the pinned SDK."""
from pathlib import Path
import json,re

ROOT=Path(__file__).resolve().parent.parent
DIRECT={
 'O_GOBJECTS':'GObjects',
 'O_CLASS':'UObject.Class','O_NAME':'UObject.Name','O_SUPER':'UStruct.Super',
 'O_VIEWPORT':'UEngine.GameViewport','O_VIEWPORT_WORLD':'UGameViewportClient.World',
 'O_WORLD_INSTANCE':'UWorld.OwningGameInstance','O_WORLD_GAMESTATE':'UWorld.GameState',
 'O_LOCAL_PLAYERS':'UGameInstance.LocalPlayers','O_LOCAL_CONTROLLER':'UPlayer.PlayerController',
 'O_LOCAL_PAWN':'APlayerController.AcknowledgedPawn','O_CAMERA_MANAGER':'APlayerController.PlayerCameraManager',
 'O_PLAYER_ARRAY':'AGameStateBase.PlayerArray','O_STATE_PAWN':'APlayerState.PawnPrivate',
 'O_PLAYER_NAME':'APlayerState.PlayerNamePrivate','O_PAWN_STATE':'APawn.PlayerState',
 'O_ROOT':'AActor.RootComponent','O_MESH':'ACharacter.Mesh','O_TEAM':'AFortPlayerStateAthena.TeamIndex',
 'O_DYING':'AFortPawn.bIsDying','O_DOWNED':'AFortPawn.bIsDBNO',
 'O_ATTACH_PARENT':'USceneComponent.AttachParent','O_ATTACH_SOCKET':'USceneComponent.AttachSocketName',
 'O_RELATIVE':'USceneComponent.RelativeLocation','O_SCENE_FLAGS':'USceneComponent.bAbsoluteLocation',
 'O_MESH_ASSET':'USkinnedMeshComponent.SkeletalMesh','O_BONE_POSES':'USkeletalMeshComponent.CachedComponentSpaceTransforms',
 'O_POV_FLAGS':'FMinimalViewInfo.bConstrainAspectRatio','O_POV_PROJECTION':'FMinimalViewInfo.ProjectionMode',
 'O_POV_OFF_CENTER':'FMinimalViewInfo.OffCenterProjectionOffset',
 'O_HEALTH_SET':'AFortPawn.HealthSet','O_HEALTH':'UFortHealthSet.Health','O_MAX_HEALTH':'UFortHealthSet.MaxHealth',
 'O_CURRENT_SHIELD':'UFortHealthSet.CurrentShield','O_ATTRIBUTE_VALUE':'FGameplayAttributeData.CurrentValue',
 'O_ATTRIBUTE_MAX':'FFortGameplayAttributeData.Maximum','O_CURRENT_CLAMPED':'FFortGameplayAttributeData.bIsCurrentClamped'}

def main():
 facts=json.loads((ROOT/'research/SDK_FACTS.json').read_text())['facts']
 text=(ROOT/'source/era_snapshot.c').read_text()
 constants={name:int(value,16) for name,value in re.findall(r'\b(O_[A-Z_]+)\s*=\s*(0x[0-9a-fA-F]+)',text)}
 expected={name:(field,facts[field]['offset']) for name,field in DIRECT.items()}
 expected['O_CAMERA_POV']=('APlayerCameraManager.CameraCachePrivate+FCameraCacheEntry.POV',
     facts['APlayerCameraManager.CameraCachePrivate']['offset']+facts['FCameraCacheEntry.POV']['offset'])
 checks=[{'constant':name,'sdk_member':field,'value':constants.get(name),'expected':value,
          'matches':constants.get(name)==value} for name,(field,value) in expected.items()]
 report={'known_fields_match':all(row['matches'] for row in checks),'reader_implemented':True,'live_compatibility_verified':False,'unverified':['Runtime name-table candidate acceptance','Private reference skeleton metadata placement and pose freshness'],'checks':checks}
 (ROOT/'research/LAYOUT_COMPARISON.json').write_text(json.dumps(report,indent=2)+'\n')
 if not report['known_fields_match']:raise SystemExit('Known-field layout comparison failed')
 print(str(len(checks))+' known decoder constants match the pinned SDK facts; runtime name-table confirmation and live behavior remain unverified.')

if __name__=='__main__':main()
