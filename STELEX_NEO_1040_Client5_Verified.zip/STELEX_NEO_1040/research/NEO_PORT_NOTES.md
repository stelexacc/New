# Neo 10.40 port evidence

The public SDK is pinned to Vincent1232/Fortnite-sdks commit f53c167439fd3b7b5bfbcf7e88f01a672852a280, whose header explicitly names4.23.0-9380822+++Fortnite+Release-10.40. The user independently supplied an offline client report with client SHA2563d439ff55d803f2579d9b35a9f25600ed37368fbe0db62db9e2fc31ebaca4323.

The report establishes the AppendString call to RVA0x02152D30, division/modulo16384 and the manager+0xB8 chunk table. It does not include that getter body or establish a global RVA. The implementation reads at most256 bytes of the called getter at runtime. MOV/LEA-RAX RIP patterns are candidate discovery rather than instruction-boundary proof. Candidates must point inside the reported original data section and pass five initial names, uniqueness and repeated-pointer checks. Entry text at12/16 remains structurally confirmed at runtime; no old ERA GNames RVA is retained.

Cached manager, first chunk and None-entry evidence is checked each poll. Replacement invalidates name/class/mesh caches. Invalid names produce a distinct finding-names status with an empty frame and bounded retry. Core aim tests are supplemented by a decoded-neck integration case.

The private reference skeleton still uses validated array-pair candidates entirely inside SDK padding0x178..0x2F0. The SDK does not expose that private member, and the freshness/availability of CachedComponentSpaceTransforms is not established. No assumed body-height or bone-index fallback is added.

Reports distinguish host simulations, real Windows INI/file APIs under Wine, product console waiting/shutdown and a separate fabricated reader for menu transitions. No real Neo client, anti-cheat access, overlay rendering in game or target-input acceptance is claimed.
