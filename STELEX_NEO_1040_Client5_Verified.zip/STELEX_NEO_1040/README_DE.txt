STELEX NEO 10.40-CL-9380822 - Clientbuild 5
========================================

Zuerst START_HIER_DE.txt lesen. Dort stehen der Start, der unabhaengige
Zielkreis und der neue Knopf "Verbindung -> Clientbericht erstellen".
Der echte Namenspool ist noch nicht bestaetigt: Die bisherigen Screenshots
zeigen Anfangsnamen=0/5. Dieses Paket ist deshalb kein Nachweis fuer einen
funktionierenden Aim-/ESP-Betrieb im laufenden Client.

START UND BEDIENUNG
Alte Tool-Instanzen schliessen, die ZIP vollstaendig in einen neuen,
schreibbaren Ordner entpacken und START.cmd oeffnen. Im Titel muss
Clientbuild 5 stehen. INSERT oeffnet/schliesst das Menue, sobald Prozess,
Modulheader und Build bestaetigt sind. Fuer das Overlay Neo in Fenster- oder
rahmenlosem Fenstermodus verwenden und den Spielfokus herstellen.
Aim, ESP und Fadenkreuz starten aus; "Zielkreis anzeigen" startet an.
Ohne frische Kamera ist der Ring sichtbar als 90-Grad-Vorschau beschriftet.

Die Konsole zeigt Status und Logs. STRG+C beendet das Tool. Einstellungen,
Profile und runtime.log liegen unter %LOCALAPPDATA%\STELEX_NEO_1040.
DIAGNOSE.cmd sammelt die letzten Meldungen in diagnose.txt.

CLIENT-BERICHT
Im Menue "Verbindung -> Clientbericht erstellen" anklicken. Die beiliegende
Probe wird nach SHA-256-Pruefung gestartet und liest die ausgewaehlte echte
FortniteClient-Win64-Shipping.exe offline. Sie startet diese Datei nicht.
Der Prozesspfad wird nach Moeglichkeit vorgewaehlt; sonst die Clientdatei im
Dialog waehlen. Ueber "Berichtsordner" die erzeugte *_v2_*.txt weitergeben.
Sie muss mit NEO_PROBE_V2_COMPLETE enden. Ersatzwege: CLIENT_BERICHT.cmd oder
ClientProbeV2\NEO_Client_Probe.exe direkt oeffnen.

DIAGNOSE UND GRENZEN
Handle/Header/Build=1 bestaetigt diese Anbindungsschritte. Namen=0 bestaetigt
keine Namenstabelle; damit fehlen auch die davon abhaengigen Spieler- und
Kameradaten. Win32=299 ist ein unvollstaendiger Leseversuch und kann von
einem verworfenen Kandidaten stammen. DIAGNOSE_LESEN_DE.txt erklaert die
getrennten Namenszaehler und Fehlerangaben.

Der Code prueft Kandidaten mit fuenf festen Anfangsnamen, Struktur und
stabilen Zeigerlesungen. Namen=1 gilt nur fuer die jeweilige aktuelle
Aufnahme. Es werden keine geratenen Ersatz-Zielpunkte verwendet.
Der Prozesszugriff verwendet normale Windows-Leseoperationen, keinen
Treiber und keine Fernaufrufe in den Client.

Die portable, Win32- und Probe-Testevidenz sowie die noch offenen Live-
Pruefungen stehen in REVIEW_DE.txt und research/REVIEW_VALIDATION.json.
Eine Simulation oder Wine-Ausfuehrung ersetzt keinen echten Neo-Test.
Es gibt keine Zusage fuer Fehlerfreiheit oder Eingabeannahme im Spiel.

QUELLEN UND BUILD
research/SDK_FACTS.json und SDK_SOURCE_RESEARCH.json dokumentieren die
gepinnten SDK-Metadaten. CLIENT_NAME_LAYOUT.json trennt statische Belege von
noch offenen Live-Pruefungen. Der vollstaendige hochgeladene Client-Codeauszug
wird nicht mitverteilt. SHA256.json nennt die gelieferten Dateihashes.

Python 3.10+ und Zig 0.15.2:
  python source/build.py --zig PFAD_ZU_ZIG
Portable Tests mit GCC:
  python source/run_tests.py --sanitize
