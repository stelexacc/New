/* Windows integration regression: ordinary INI writes and readback use the real
 * OS. The documented zero return for a three-NULL flush is forced even on OS
 * versions which happen to return TRUE, so the original save bug cannot hide. */
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <wchar.h>
static BOOL WINAPI test_profile_write(LPCWSTR section,LPCWSTR key,LPCWSTR value,LPCWSTR path);
#define WritePrivateProfileStringW test_profile_write
#define wWinMain desktop_entry_not_started
#define wmain desktop_console_not_started
#ifndef ERA_DESKTOP_SOURCE
#define ERA_DESKTOP_SOURCE "../source/era_desktop.c"
#endif
#include ERA_DESKTOP_SOURCE
#undef WritePrivateProfileStringW
#undef wWinMain
#undef wmain
static int test_checks,test_failures,flush_calls,write_calls,fail_next_write;
#define CHECK(c) do {test_checks++;if(!(c)){fwprintf(stderr,L"FAIL line %d: %hs\n",__LINE__,#c);test_failures++;}}while(0)
static BOOL WINAPI test_profile_write(LPCWSTR section,LPCWSTR key,LPCWSTR value,LPCWSTR path){
    if(!section&&!key&&!value){flush_calls++;(void)WritePrivateProfileStringW(section,key,value,path);return FALSE;}
    write_calls++;
    if(fail_next_write){fail_next_write=0;SetLastError(ERROR_ACCESS_DENIED);return FALSE;}
    return WritePrivateProfileStringW(section,key,value,path);
}
static void values_for(int seed){
    era_config_defaults(&config);
    for(int i=0;i<ARRAY_COUNT(settings);i++){
        int range=settings[i].max-settings[i].min+1;
        *setting_value(i)=settings[i].min+(seed+i*7)%range;
    }
    era_config_clamp(&config);
}
static void check_readback(const wchar_t*path,const EraConfig*expected){
    for(int i=0;i<ARRAY_COUNT(settings);i++){
        int wanted=*(const int*)((const unsigned char*)expected+settings[i].offset);
        int got=(int)GetPrivateProfileIntW(L"settings",settings[i].key,-9999,path);
        CHECK(got==wanted);
    }
}
static void remove_ini(const wchar_t*path){
    wchar_t temporary[1200];DeleteFileW(path);swprintf(temporary,ARRAY_COUNT(temporary),L"%ls.tmp",path);DeleteFileW(temporary);
}
int wmain(void){
    wchar_t temporary[MAX_PATH],folder[MAX_PATH],path[1100],other[1100],blocked[1100],scratch[1200];
    DWORD temp_length=GetTempPathW(ARRAY_COUNT(temporary),temporary);
    if(!temp_length||temp_length>=ARRAY_COUNT(temporary)||!GetTempFileNameW(temporary,L"era",0,folder))return 2;
    DeleteFileW(folder);if(!CreateDirectoryW(folder,NULL))return 3;
    /* The master/team/corner switches alone do not request a drawable item. */
    memset(&config,0,sizeof(config));config.esp_enabled=1;CHECK(!esp_features_selected());
    config.esp_team=1;CHECK(!esp_features_selected());config.esp_corner=1;CHECK(!esp_features_selected());
    const size_t visible_fields[]={offsetof(EraConfig,esp_box),offsetof(EraConfig,esp_skeleton),offsetof(EraConfig,esp_health),offsetof(EraConfig,esp_shield),offsetof(EraConfig,esp_names),offsetof(EraConfig,esp_distance),offsetof(EraConfig,esp_tracers),offsetof(EraConfig,esp_head_dot)};
    for(int i=0;i<ARRAY_COUNT(visible_fields);i++){int*field=(int*)((unsigned char*)&config+visible_fields[i]);*field=1;CHECK(esp_features_selected());*field=0;}
    InitializeCriticalSection(&log_lock);log_file[0]=0;menu_window=NULL;
    wcsncpy(config_folder,folder,ARRAY_COUNT(config_folder)-1);config_folder[ARRAY_COUNT(config_folder)-1]=0;
    swprintf(config_file,ARRAY_COUNT(config_file),L"%ls\\settings.ini",folder);
    swprintf(path,ARRAY_COUNT(path),L"%ls\\direct.ini",folder);
    values_for(3);EraConfig first=config;CHECK(save_settings(path));CHECK(flush_calls==1);CHECK(write_calls==ARRAY_COUNT(settings));check_readback(path,&first);
    CHECK(GetFileAttributesW(path)!=INVALID_FILE_ATTRIBUTES);
    swprintf(scratch,ARRAY_COUNT(scratch),L"%ls.tmp",path);CHECK(GetFileAttributesW(scratch)==INVALID_FILE_ATTRIBUTES);
    /* Updating the same destination must replace every old key. */
    values_for(19);EraConfig second=config;CHECK(save_settings(path));check_readback(path,&second);
    CHECK(flush_calls==2);CHECK(GetFileAttributesW(scratch)==INVALID_FILE_ATTRIBUTES);
    /* A normal API write failure must still fail and preserve the old INI. */
    values_for(23);fail_next_write=1;CHECK(!save_settings(path));CHECK(GetFileAttributesW(scratch)==INVALID_FILE_ATTRIBUTES);check_readback(path,&second);
    /* Same INI format and atomic path for Unicode names. */
    swprintf(other,ARRAY_COUNT(other),L"%ls\\Profil_\x00c4\x00df.ini",folder);
    values_for(11);EraConfig unicode_values=config;CHECK(save_settings(other));check_readback(other,&unicode_values);CHECK(load_settings(other,1));
    /* Exercise actual commit and profile functions without starting any window,
       reader, overlay or game process. Logging remains on this test console. */
    config_dirty=1;commit_config();CHECK(!config_dirty);check_readback(config_file,&unicode_values);
    for(int slot=0;slot<3;slot++){
        profile_slot=slot;values_for(30+slot);EraConfig expected=config;profile_action(0);
        swprintf(blocked,ARRAY_COUNT(blocked),L"%ls\\profile_%d.ini",folder,slot+1);CHECK(GetFileAttributesW(blocked)!=INVALID_FILE_ATTRIBUTES);check_readback(blocked,&expected);
        values_for(70+slot);profile_action(1);CHECK(!config_dirty);
        for(int i=0;i<ARRAY_COUNT(settings);i++)CHECK(*setting_value(i)==*(int*)((unsigned char*)&expected+settings[i].offset));
        check_readback(config_file,&expected);
    }
    /* Destination errors must not be mistaken for the benign flush return. */
    swprintf(blocked,ARRAY_COUNT(blocked),L"%ls\\missing-parent\\settings.ini",folder);CHECK(!save_settings(blocked));
    swprintf(blocked,ARRAY_COUNT(blocked),L"%ls\\destination-directory.ini",folder);CHECK(CreateDirectoryW(blocked,NULL));CHECK(!save_settings(blocked));
    CHECK((GetFileAttributesW(blocked)&FILE_ATTRIBUTE_DIRECTORY)!=0);swprintf(scratch,ARRAY_COUNT(scratch),L"%ls.tmp",blocked);CHECK(GetFileAttributesW(scratch)==INVALID_FILE_ATTRIBUTES);
    CHECK(flush_calls>=10);
    remove_ini(path);remove_ini(other);remove_ini(config_file);RemoveDirectoryW(blocked);
    for(int slot=0;slot<3;slot++){swprintf(path,ARRAY_COUNT(path),L"%ls\\profile_%d.ini",folder,slot+1);remove_ini(path);}
    CHECK(RemoveDirectoryW(folder));DeleteCriticalSection(&log_lock);
    printf("ERA Windows settings: %d assertions, %d failures; forced-zero flushes: %d; normal writes: %d\n",test_checks,test_failures,flush_calls,write_calls);
    return test_failures?1:0;
}
