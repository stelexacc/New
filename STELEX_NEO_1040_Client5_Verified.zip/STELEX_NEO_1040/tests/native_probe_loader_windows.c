/* Real ShellExecute of the pinned offline probe only. No game file is selected
 * or executed. Run from an isolated app folder containing ClientProbeV2. */
#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#include <windows.h>
#include <stdio.h>
#include "era_probe_launcher.h"
int wmain(void){
    if(FindWindowW(L"NEO_CLIENT_PROBE_V2_OFFLINE",NULL)){
        puts("existing_probe_window");return 3;
    }
    EraProbeLaunchResult result=era_probe_launch(0,0);
    printf("launched=%d selected=%d failure=%d native=%lu shell=%lu\n",
        result.launched,result.used_attached_path,(int)result.failure,
        (unsigned long)result.windows_error,(unsigned long)result.shell_code);
    if(!result.launched)return 1;
    HWND window=NULL,picker=NULL;DWORD pid=0,picker_pid=0;
    for(int i=0;i<100;i++){
        window=FindWindowW(L"NEO_CLIENT_PROBE_V2_OFFLINE",NULL);
        picker=FindWindowW(L"#32770",L"Neo-Client auswaehlen: FortniteClient-Win64-Shipping.exe (nicht Launcher)");
        if(window&&picker&&IsWindowVisible(window)&&IsWindowVisible(picker))break;
        Sleep(50);
    }
    if(window)GetWindowThreadProcessId(window,&pid);
    if(picker)GetWindowThreadProcessId(picker,&picker_pid);
    int visible=window&&IsWindowVisible(window)&&picker&&IsWindowVisible(picker)&&pid==picker_pid;
    printf("probe_visible=%d picker_visible=%d same_process=%d\n",
        window&&IsWindowVisible(window),picker&&IsWindowVisible(picker),pid!=0&&pid==picker_pid);
    if(picker&&pid==picker_pid)SendMessageW(picker,WM_COMMAND,IDCANCEL,0);
    if(window)PostMessageW(window,WM_CLOSE,0,0);
    for(int i=0;i<100&&window&&IsWindow(window);i++)Sleep(20);
    int closed=!window||!IsWindow(window);printf("closed=%d\n",closed);
    return visible&&closed?0:2;
}
