"""Run the real desktop timer regression under Wine, including its old-order control.

This does not start a game, reader thread, desktop entry point, or mouse input.
Requires Zig 0.15.2 and a configured Wine wrapper; neither is downloaded here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig', required=True)
    parser.add_argument('--wine', required=True)
    args = parser.parse_args()
    source = ROOT / 'source/era_desktop.c'
    text = source.read_text()
    rows = []
    environment = os.environ.copy()
    environment.setdefault('ZIG_GLOBAL_CACHE_DIR', str(ROOT / 'build/zig-global-cache'))
    environment.setdefault('ZIG_LOCAL_CACHE_DIR', str(ROOT / 'build/zig-local-cache'))
    lock = '    EnterCriticalSection(&frame_lock);display_frame=shared_frame;LeaveCriticalSection(&frame_lock);\n'
    clock = '    uint64_t now=GetTickCount64();double seconds=last_tick?(double)(now-last_tick)*0.001:0.016;last_tick=now;\n'
    start = text.index('static void timer_tick(void){')
    end = text.index('static LRESULT CALLBACK overlay_proc(', start)
    timer = text[start:end]
    if timer.count(lock) != 1 or timer.count(clock) != 1 or timer.index(lock) > timer.index(clock):
        raise ValueError('Expected corrected timer order not found; control must be reviewed')
    legacy_timer = timer.replace(lock, '').replace(clock, '')
    legacy_timer = legacy_timer.replace('static void timer_tick(void){\n',
                                        'static void timer_tick(void){\n' + clock + lock, 1)
    with tempfile.TemporaryDirectory(prefix='neo-desktop-regression-') as temporary:
        folder = Path(temporary)
        legacy = folder / 'era_desktop_legacy.c'
        legacy.write_text(text[:start] + legacy_timer + text[end:])
        for variant, implementation in [('current', source), ('legacy_negative', legacy)]:
            executable = folder / (variant + '.exe')
            command = [args.zig, 'cc', '-target', 'x86_64-windows-gnu', '-std=c11',
                       '-O2', '-Wall', '-Wextra', '-Werror', '-municode',
                       '-Wl,--subsystem,console', '-I' + str(ROOT / 'source'),
                       '-DERA_DESKTOP_SOURCE="' + str(implementation) + '"',
                       str(ROOT / 'tests/test_desktop_windows.c')]
            command += [str(ROOT / 'source' / name) for name in
                        ['era_memory.c', 'era_snapshot.c', 'era_core.c',
                         'era_identity.c', 'era_startup.c','era_probe_launcher.c']]
            command += ['-luser32', '-lgdi32', '-lshell32', '-lversion', '-lwinmm','-ladvapi32',
                        '-o', str(executable)]
            compiled = subprocess.run(command, cwd=ROOT, env=environment,
                                      text=True, capture_output=True, timeout=240)
            rows.append(dict(name=variant + ' compile', passed=compiled.returncode == 0,
                             exit_code=compiled.returncode, stdout=compiled.stdout,
                             stderr=compiled.stderr))
            if compiled.returncode:
                print(compiled.stderr)
                continue
            result = subprocess.run([args.wine, str(executable)], cwd=ROOT,
                                    env=environment, text=True, capture_output=True,
                                    timeout=60)
            match = re.search(r'NEO desktop timer: (\d+) assertions, (\d+) failures',
                              result.stdout)
            # A legacy failure must be the three reproduced race assertions,
            # rather than an unrelated loader failure or incomplete test run.
            expected_failures = 0 if variant == 'current' else 3
            passed = bool(match and int(match[1]) == 74 and
                          int(match[2]) == expected_failures and
                          result.returncode == (0 if expected_failures == 0 else 1))
            rows.append(dict(name=variant + ' execute', passed=passed,
                             expected_failures=expected_failures,
                             exit_code=result.returncode, stdout=result.stdout,
                             stderr=result.stderr))
            print(('PASS ' if passed else 'FAIL ') + variant, flush=True)
            print(result.stdout.rstrip(), flush=True)
    report = dict(passed=len(rows) == 4 and all(row['passed'] for row in rows),
                  desktop_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  wine_execution=True, native_windows_tested=False,
                  live_neo_tested=False, checks=rows)
    (ROOT / 'research/DESKTOP_REGRESSION.json').write_text(json.dumps(report, indent=2) + '\n')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
