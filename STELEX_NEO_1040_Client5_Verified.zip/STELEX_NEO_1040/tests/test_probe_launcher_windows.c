/* Actual WinCrypt and filesystem regression. Only executable-path metadata
 * and ShellExecute are mocked. Neither a client EXE nor the probe is executed.
 * Run with the package root as cwd so the pinned bundled probe can be copied. */
#define WIN32_LEAN_AND_MEAN
#define UNICODE 1
#define _UNICODE 1
#include <windows.h>
#include <wincrypt.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdint.h>
#include <wchar.h>
static DWORD WINAPI launcher_test_module(HMODULE module,LPWSTR path,DWORD size);
static HANDLE WINAPI launcher_test_open(DWORD access,BOOL inherit,DWORD pid);
static BOOL WINAPI launcher_test_query(HANDLE process,DWORD flags,LPWSTR path,PDWORD size);
static BOOL WINAPI launcher_test_close(HANDLE handle);
static HINSTANCE WINAPI launcher_test_shell(HWND owner,LPCWSTR operation,LPCWSTR file,LPCWSTR arguments,LPCWSTR directory,INT show);
#define GetModuleFileNameW launcher_test_module
#define OpenProcess launcher_test_open
#define QueryFullProcessImageNameW launcher_test_query
#define CloseHandle launcher_test_close
#define ShellExecuteW launcher_test_shell
#include "../source/era_probe_launcher.c"
#undef GetModuleFileNameW
#undef OpenProcess
#undef QueryFullProcessImageNameW
#undef CloseHandle
#undef ShellExecuteW

static wchar_t module_fixture[PROBE_PATH_CAPACITY],client_fixture[PROBE_PATH_CAPACITY];
static wchar_t expected_probe[PROBE_PATH_CAPACITY],expected_directory[PROBE_PATH_CAPACITY],last_arguments[PROBE_PATH_CAPACITY];
static int module_failure,open_denied,query_denied,shell_failure;
static int open_calls,query_calls,process_closes,shell_calls,test_checks,test_failures;
static const HANDLE process_fixture=(HANDLE)(uintptr_t)0x1234feed;
static const uintptr_t owner_fixture=0x4567;
#define CHECK(condition) do {test_checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);test_failures++;}}while(0)
static DWORD WINAPI launcher_test_module(HMODULE module,LPWSTR path,DWORD size){
    CHECK(module==NULL);
    if(module_failure==1){SetLastError(ERROR_ACCESS_DENIED);return 0;}
    if(module_failure==2){SetLastError(ERROR_INSUFFICIENT_BUFFER);return size;}
    size_t length=wcslen(module_fixture);if(length>=size)return size;
    memcpy(path,module_fixture,(length+1)*sizeof(wchar_t));return (DWORD)length;
}
static HANDLE WINAPI launcher_test_open(DWORD access,BOOL inherit,DWORD pid){
    open_calls++;CHECK(access==PROCESS_QUERY_LIMITED_INFORMATION);CHECK(!inherit);CHECK(pid==777);
    if(open_denied){SetLastError(ERROR_ACCESS_DENIED);return NULL;}return process_fixture;
}
static BOOL WINAPI launcher_test_query(HANDLE process,DWORD flags,LPWSTR path,PDWORD size){
    query_calls++;CHECK(process==process_fixture);CHECK(flags==0);
    if(query_denied){SetLastError(ERROR_ACCESS_DENIED);return FALSE;}
    size_t length=wcslen(client_fixture);if(length>=*size){SetLastError(ERROR_INSUFFICIENT_BUFFER);return FALSE;}
    memcpy(path,client_fixture,(length+1)*sizeof(wchar_t));*size=(DWORD)length;return TRUE;
}
static BOOL WINAPI launcher_test_close(HANDLE handle){
    if(handle==process_fixture){process_closes++;return TRUE;}return CloseHandle(handle);
}
static HINSTANCE WINAPI launcher_test_shell(HWND owner,LPCWSTR operation,LPCWSTR file,LPCWSTR arguments,LPCWSTR directory,INT show){
    shell_calls++;CHECK((uintptr_t)owner==owner_fixture);CHECK(wcscmp(operation,L"open")==0);
    CHECK(wcscmp(file,expected_probe)==0);CHECK(wcscmp(directory,expected_directory)==0);CHECK(show==SW_SHOWNORMAL);
    wcscpy(last_arguments,arguments);
    /* The verified executable stays locked against replacement until the
       launch API has accepted it. A later loader test may execute the probe. */
    HANDLE writer=CreateFileW(file,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,
        NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    CHECK(writer==INVALID_HANDLE_VALUE);if(writer!=INVALID_HANDLE_VALUE)CloseHandle(writer);
    CHECK(!DeleteFileW(file));
    if(shell_failure){SetLastError(ERROR_ACCESS_DENIED);return (HINSTANCE)(uintptr_t)SE_ERR_ACCESSDENIED;}
    SetLastError(ERROR_SUCCESS);return (HINSTANCE)(uintptr_t)33;
}
static int write_bytes(const wchar_t*path,const void*data,DWORD bytes){
    HANDLE file=CreateFileW(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)return 0;DWORD written=0;
    int ok=WriteFile(file,data,bytes,&written,NULL)&&written==bytes;CloseHandle(file);return ok;
}
static EraProbeLaunchResult launch(uint32_t pid){return era_probe_launch(owner_fixture,pid);}
int wmain(void){
    wchar_t temporary[MAX_PATH]={0},folder[MAX_PATH]={0},application[MAX_PATH],client_directory[MAX_PATH];
    wchar_t source[PROBE_PATH_CAPACITY],real_client[PROBE_PATH_CAPACITY],hash_file[MAX_PATH];
    DWORD temp_length=GetTempPathW(MAX_PATH,temporary);
    CHECK(temp_length>0&&temp_length<MAX_PATH);
    if(!temp_length||temp_length>=MAX_PATH)return 2;
    CHECK(GetTempFileNameW(temporary,L"neo",0,folder)!=0);CHECK(DeleteFileW(folder));CHECK(CreateDirectoryW(folder,NULL));
    swprintf(application,MAX_PATH,L"%ls\\STELEX App \x00c4\x00df",folder);CHECK(CreateDirectoryW(application,NULL));
    swprintf(expected_directory,PROBE_PATH_CAPACITY,L"%ls\\ClientProbeV2",application);CHECK(CreateDirectoryW(expected_directory,NULL));
    swprintf(expected_probe,PROBE_PATH_CAPACITY,L"%ls\\NEO_Client_Probe.exe",expected_directory);
    swprintf(module_fixture,PROBE_PATH_CAPACITY,L"%ls\\STELEX_NEO_1040.exe",application);
    CHECK(GetFullPathNameW(L"ClientProbeV2\\NEO_Client_Probe.exe",PROBE_PATH_CAPACITY,source,NULL)>0);
    CHECK(CopyFileW(source,expected_probe,FALSE));
    swprintf(client_directory,MAX_PATH,L"%ls\\Neo Client \x4e2d \x00c4",folder);CHECK(CreateDirectoryW(client_directory,NULL));
    swprintf(real_client,PROBE_PATH_CAPACITY,L"%ls\\FortniteClient-Win64-Shipping.exe",client_directory);
    CHECK(write_bytes(real_client,"abc",3));wcscpy(client_fixture,real_client);

    /* The native hash implementation must match a known independent vector,
       including when called again after the handle reached end-of-file. */
    static const unsigned char abc_sha256[32]={
        0xba,0x78,0x16,0xbf,0x8f,0x01,0xcf,0xea,0x41,0x41,0x40,0xde,0x5d,0xae,0x22,0x23,
        0xb0,0x03,0x61,0xa3,0x96,0x17,0x7a,0x9c,0xb4,0x10,0xff,0x61,0xf2,0x00,0x15,0xad
    };
    swprintf(hash_file,MAX_PATH,L"%ls\\hash.bin",folder);CHECK(write_bytes(hash_file,"abc",3));
    HANDLE hash=CreateFileW(hash_file,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    CHECK(hash!=INVALID_HANDLE_VALUE);DWORD error=0;
    CHECK(probe_sha256_matches(hash,abc_sha256,&error));CHECK(error==ERROR_SUCCESS);
    CHECK(probe_sha256_matches(hash,abc_sha256,&error));
    unsigned char wrong[32]={0};CHECK(!probe_sha256_matches(hash,wrong,&error));CHECK(error==ERROR_INVALID_DATA);CloseHandle(hash);

    EraProbeLaunchResult result=launch(777);
    CHECK(result.launched);CHECK(result.used_attached_path);CHECK(result.failure==ERA_PROBE_FAILURE_NONE);CHECK(!result.windows_error);
    CHECK(shell_calls==1);CHECK(open_calls==1);CHECK(query_calls==1);CHECK(process_closes==1);
    wchar_t command[PROBE_PATH_CAPACITY];swprintf(command,PROBE_PATH_CAPACITY,L"Probe.exe %ls",last_arguments);
    int argc=0;wchar_t**argv=CommandLineToArgvW(command,&argc);CHECK(argv!=NULL);CHECK(argc==2);
    if(argv){CHECK(wcscmp(argv[1],real_client)==0);LocalFree(argv);}

    /* Every unsupported metadata path falls back to the ordinary file picker. */
    result=launch(0);CHECK(result.launched);CHECK(!result.used_attached_path);CHECK(wcscmp(last_arguments,L"--choose-file")==0);CHECK(open_calls==1);
    open_denied=1;result=launch(777);CHECK(result.launched);CHECK(!result.used_attached_path);CHECK(wcscmp(last_arguments,L"--choose-file")==0);open_denied=0;
    query_denied=1;result=launch(777);CHECK(result.launched);CHECK(!result.used_attached_path);CHECK(wcscmp(last_arguments,L"--choose-file")==0);query_denied=0;
    swprintf(client_fixture,PROBE_PATH_CAPACITY,L"%ls\\NeoLauncher.exe",client_directory);
    result=launch(777);CHECK(result.launched);CHECK(!result.used_attached_path);CHECK(wcscmp(last_arguments,L"--choose-file")==0);
    swprintf(client_fixture,PROBE_PATH_CAPACITY,L"%ls\\missing\\FortniteClient-Win64-Shipping.exe",client_directory);
    result=launch(777);CHECK(result.launched);CHECK(!result.used_attached_path);CHECK(wcscmp(last_arguments,L"--choose-file")==0);
    swprintf(client_fixture,PROBE_PATH_CAPACITY,L"%ls\\bad\"name\\FortniteClient-Win64-Shipping.exe",client_directory);
    result=launch(777);CHECK(result.launched);CHECK(!result.used_attached_path);CHECK(wcscmp(last_arguments,L"--choose-file")==0);
    wcscpy(client_fixture,real_client);

    shell_failure=1;result=launch(777);CHECK(!result.launched);CHECK(result.failure==ERA_PROBE_FAILURE_START);
    CHECK(result.shell_code==SE_ERR_ACCESSDENIED);CHECK(result.windows_error==ERROR_ACCESS_DENIED);shell_failure=0;
    int previous_shell=shell_calls;
    module_failure=1;result=launch(777);CHECK(!result.launched);CHECK(result.failure==ERA_PROBE_FAILURE_LOCATION);CHECK(result.windows_error==ERROR_ACCESS_DENIED);CHECK(shell_calls==previous_shell);
    module_failure=2;result=launch(777);CHECK(!result.launched);CHECK(result.failure==ERA_PROBE_FAILURE_LOCATION);CHECK(result.windows_error==ERROR_INSUFFICIENT_BUFFER);CHECK(shell_calls==previous_shell);module_failure=0;
    CHECK(write_bytes(expected_probe,"corrupted",9));result=launch(777);
    CHECK(!result.launched);CHECK(result.failure==ERA_PROBE_FAILURE_HASH);CHECK(result.windows_error==ERROR_INVALID_DATA);CHECK(shell_calls==previous_shell);
    CHECK(DeleteFileW(expected_probe));result=launch(777);CHECK(!result.launched);CHECK(result.failure==ERA_PROBE_FAILURE_OPEN);CHECK(result.windows_error==ERROR_FILE_NOT_FOUND);CHECK(shell_calls==previous_shell);
    CHECK(CopyFileW(source,expected_probe,FALSE));result=launch(777);CHECK(result.launched);CHECK(result.used_attached_path);CHECK(shell_calls==previous_shell+1);
    for(int reason=ERA_PROBE_FAILURE_NONE;reason<=ERA_PROBE_FAILURE_START;reason++)CHECK(era_probe_failure_text((EraProbeLaunchFailure)reason)[0]!=0);
    CHECK(DeleteFileW(expected_probe));CHECK(DeleteFileW(real_client));CHECK(DeleteFileW(hash_file));
    CHECK(RemoveDirectoryW(expected_directory));CHECK(RemoveDirectoryW(application));CHECK(RemoveDirectoryW(client_directory));CHECK(RemoveDirectoryW(folder));
    printf("NEO native probe launcher: %d assertions, %d failures; actual WinCrypt/files, mocked metadata/ShellExecute, no target executed\n",test_checks,test_failures);
    return test_failures?1:0;
}
