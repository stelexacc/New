/* Real Win32/GDI bitmap regression for screen-only overlay widgets. Focus,
 * clock and key samples are deterministic, and SendInput is replaced by a
 * counter. No game process is opened and no OS mouse input is submitted. */
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
static ULONGLONG WINAPI overlay_test_clock(void);
static HWND WINAPI overlay_test_foreground(void);
static SHORT WINAPI overlay_test_keys(int key);
static UINT WINAPI overlay_test_send_input(UINT count,LPINPUT input,int bytes);
#define GetTickCount64 overlay_test_clock
#define GetForegroundWindow overlay_test_foreground
#define GetAsyncKeyState overlay_test_keys
#define SendInput overlay_test_send_input
#define wWinMain desktop_entry_not_started
#define wmain desktop_console_not_started
#ifndef ERA_DESKTOP_SOURCE
#define ERA_DESKTOP_SOURCE "../source/era_desktop.c"
#endif
#include ERA_DESKTOP_SOURCE
#undef GetTickCount64
#undef GetForegroundWindow
#undef GetAsyncKeyState
#undef SendInput
#undef wWinMain
#undef wmain

enum {TEST_WIDTH=640,TEST_HEIGHT=480};
static ULONGLONG test_clock=100000;
static HWND foreground_fixture;
static int held_fixture,input_calls,input_events,test_checks,test_failures;
static uint32_t*bitmap_pixels;
#define CHECK(condition) do {test_checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);test_failures++;}}while(0)
static ULONGLONG WINAPI overlay_test_clock(void){return test_clock;}
static HWND WINAPI overlay_test_foreground(void){return foreground_fixture;}
static SHORT WINAPI overlay_test_keys(int key){return held_fixture&&key==VK_RBUTTON?(SHORT)0x8000:0;}
static UINT WINAPI overlay_test_send_input(UINT count,LPINPUT input,int bytes){
    (void)input;(void)bytes;input_calls++;input_events+=(int)count;return count;
}
static int color_count(COLORREF wanted,int x,int y,int width,int height){
    GdiFlush();int count=0;
    for(int yy=y;yy<y+height;yy++)for(int xx=x;xx<x+width;xx++){
        uint32_t value=bitmap_pixels[yy*TEST_WIDTH+xx];
        COLORREF color=RGB((value>>16)&255,(value>>8)&255,value&255);
        if(color==wanted)count++;
    }
    return count;
}
static void pending_frame(HWND game){
    shared_frame=(EraFrame){0};shared_frame.pid=GetCurrentProcessId();
    shared_frame.module_base=UINT64_C(0x140000000);shared_frame.attach_flags=ERA_ATTACH_COMPLETE;
    shared_frame.captured_ms=test_clock;shared_frame.game_window=(uintptr_t)game;
    shared_frame.status=ERA_FINDING_NAMES;shared_frame.names_ready=0;
    startup_state=(EraStartupState){1,shared_frame.pid,shared_frame.module_base};
    display_frame=shared_frame;
}
static void render(HDC dc){draw_overlay(dc,TEST_WIDTH,TEST_HEIGHT);}
static void tick(void){test_clock+=16;timer_tick();}
int wmain(void){
    int result=0;HDC screen=NULL,dc=NULL;HBITMAP bitmap=NULL;HGDIOBJ original=NULL;
    InitializeCriticalSection(&frame_lock);InitializeCriticalSection(&log_lock);
    HWND game=CreateWindowExW(0,L"STATIC",L"NEO overlay fixture",WS_OVERLAPPEDWINDOW|WS_VISIBLE,
        0,0,TEST_WIDTH,TEST_HEIGHT,NULL,NULL,GetModuleHandleW(NULL),NULL);
    menu_window=CreateWindowExW(WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,L"STATIC",L"NEO test menu",WS_POPUP,
        0,0,1,1,NULL,NULL,GetModuleHandleW(NULL),NULL);
    overlay_window=CreateWindowExW(WS_EX_TOOLWINDOW|WS_EX_NOACTIVATE,L"STATIC",L"NEO test overlay",WS_POPUP,
        0,0,1,1,NULL,NULL,GetModuleHandleW(NULL),NULL);
    CHECK(game!=NULL);CHECK(menu_window!=NULL);CHECK(overlay_window!=NULL);
    if(!game||!menu_window||!overlay_window){result=2;goto cleanup;}
    foreground_fixture=game;menu_shown=0;log_file[0]=0;config_dirty=0;
    screen=GetDC(NULL);dc=CreateCompatibleDC(screen);
    BITMAPINFO info={0};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth=TEST_WIDTH;info.bmiHeader.biHeight=-TEST_HEIGHT;
    info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
    bitmap=CreateDIBSection(screen,&info,DIB_RGB_COLORS,(void**)&bitmap_pixels,NULL,0);
    ReleaseDC(NULL,screen);screen=NULL;
    CHECK(dc!=NULL);CHECK(bitmap!=NULL);CHECK(bitmap_pixels!=NULL);
    if(!dc||!bitmap||!bitmap_pixels){result=3;goto cleanup;}
    original=SelectObject(dc,bitmap);SetBkMode(dc,TRANSPARENT);
    font_small=(HFONT)GetStockObject(DEFAULT_GUI_FONT);
    era_config_defaults(&config);CHECK(config.aim_ring_enabled==1);CHECK(config.aim_enabled==0);
    pending_frame(game);
    CHECK(!fresh_frame(&display_frame,test_clock));CHECK(!era_camera_valid(&display_frame.camera));
    render(dc);
    int preview_radius=(int)(tan((double)config.aim_fov_degrees*0.017453292519943295)*TEST_WIDTH*0.5);
    CHECK(color_count(C_LIGHT,TEST_WIDTH/2+preview_radius-2,TEST_HEIGHT/2-4,5,9)>0);
    CHECK(color_count(C_MUTED,16,12,TEST_WIDTH-32,24)>0); /* explicit FOV preview label */
    CHECK(color_count(C_ENEMY,0,0,TEST_WIDTH,TEST_HEIGHT)==0);
    CHECK(input_calls==0);

    /* Crosshair can be enabled independently of the ring and game camera. */
    config.aim_ring_enabled=0;config.crosshair_enabled=1;render(dc);
    CHECK(color_count(RGB(config.crosshair_red,config.crosshair_green,config.crosshair_blue),TEST_WIDTH/2+6,TEST_HEIGHT/2-2,6,5)>0);
    CHECK(color_count(C_LIGHT,0,0,TEST_WIDTH,TEST_HEIGHT)==0);
    CHECK(color_count(C_MUTED,16,12,TEST_WIDTH-32,24)==0);

    /* Give the fixture a plausible stale camera/entity/target so absence of
       output verifies the freshness gate, not merely invalid coordinates. */
    config.aim_ring_enabled=1;config.aim_enabled=1;config.esp_enabled=1;config.esp_tracers=1;
    held_fixture=1;
    shared_frame.status=ERA_READY;shared_frame.camera.fov=60.0f;
    shared_frame.local_alive=1;shared_frame.local_pawn=11;shared_frame.local_team=1;
    shared_frame.count=1;shared_frame.captured_ms=test_clock-300;
    EraEntity*entity=&shared_frame.entities[0];entity->id=42;entity->alive=1;entity->team=2;
    entity->root=(EraVec3){1000,100,0};entity->targets[1]=entity->root;entity->target_mask=2;
    display_frame=shared_frame;CHECK(era_camera_valid(&display_frame.camera));
    render(dc);
    CHECK(color_count(C_LIGHT,TEST_WIDTH/2+preview_radius-2,TEST_HEIGHT/2-4,5,9)>0);
    CHECK(color_count(C_MUTED,16,12,TEST_WIDTH-32,24)>0);
    CHECK(color_count(C_ENEMY,0,0,TEST_WIDTH,TEST_HEIGHT)==0);
    tick();CHECK(IsWindowVisible(overlay_window));CHECK(input_calls==0);CHECK(input_events==0);

    /* A fresh simulated camera uses its actual FOV, allows entity rendering
       and reaches the mocked input sink. It never injects actual input. */
    shared_frame.captured_ms=test_clock;shared_frame.names_ready=1;display_frame=shared_frame;
    render(dc);
    int measured_radius=(int)(tan((double)config.aim_fov_degrees*0.017453292519943295)*TEST_WIDTH*0.5/tan(60.0*0.008726646259971648));
    CHECK(measured_radius!=preview_radius);
    CHECK(color_count(C_LIGHT,TEST_WIDTH/2+measured_radius-2,TEST_HEIGHT/2-4,5,9)>0);
    CHECK(color_count(C_MUTED,16,12,TEST_WIDTH-32,24)==0);
    CHECK(color_count(C_ENEMY,0,0,TEST_WIDTH,TEST_HEIGHT)>0);
    tick();CHECK(input_calls>0);CHECK(input_events>0);
    int previous_inputs=input_calls;

    /* Normal screen widgets survive missing names. Actual motion does not. */
    pending_frame(game);menu_shown=0;tick();CHECK(IsWindowVisible(overlay_window));
    CHECK(input_calls==previous_inputs);
    foreground_fixture=NULL;tick();CHECK(!IsWindowVisible(overlay_window));
    display_frame=shared_frame;render(dc);CHECK(color_count(C_KEY,0,0,TEST_WIDTH,TEST_HEIGHT)==TEST_WIDTH*TEST_HEIGHT);
    CHECK(input_calls==previous_inputs);
    foreground_fixture=game;tick();CHECK(IsWindowVisible(overlay_window));
    ShowWindow(game,SW_MINIMIZE);tick();CHECK(!IsWindowVisible(overlay_window));
    CHECK(input_calls==previous_inputs);
    ShowWindow(game,SW_RESTORE);foreground_fixture=game;tick();CHECK(IsWindowVisible(overlay_window));
    shared_frame.attach_flags=ERA_ATTACH_PROCESS|ERA_ATTACH_MODULE;tick();
    CHECK(!IsWindowVisible(overlay_window));CHECK(!startup_state.attached);CHECK(input_calls==previous_inputs);
    display_frame=shared_frame;render(dc);CHECK(color_count(C_KEY,0,0,TEST_WIDTH,TEST_HEIGHT)==TEST_WIDTH*TEST_HEIGHT);

cleanup:
    if(dc&&original&&original!=HGDI_ERROR)SelectObject(dc,original);
    if(bitmap)DeleteObject(bitmap);if(dc)DeleteDC(dc);if(screen)ReleaseDC(NULL,screen);
    for(int i=0;i<ARRAY_COUNT(cached_pens);i++)if(cached_pens[i].handle)DeleteObject(cached_pens[i].handle);
    if(game)DestroyWindow(game);if(menu_window)DestroyWindow(menu_window);if(overlay_window)DestroyWindow(overlay_window);
    DeleteCriticalSection(&log_lock);DeleteCriticalSection(&frame_lock);
    printf("NEO screen overlay: %d assertions, %d failures; real GDI bitmap, mocked input, no game started\n",test_checks,test_failures);
    return result?result:test_failures?1:0;
}
