# Desktop smoke checks

For Review 2, use the current reproducible product-only runner with a running
Xvfb display and an initialized Wine prefix:

```sh
python tests/run_review_startup.py --wine /path/to/wine --prefix /path/to/prefix --zig /path/to/zig
```

Its current results are in `research/REVIEW_STARTUP_VALIDATION.json` and the
associated `REVIEW_STARTUP_*.log` files. It checks console visibility, hidden
windows, blocked show requests and message-triggered clean shutdown. Physical
Ctrl+C, live game data and in-game drawing/input are outside this run.
The following manual/fixture procedure describes the original Testbuild 1
evidence, archived under `research/original_testbuild1`; it was not rerun for
Review 2.

These checks exercise the actual Windows UI under Wine/Xvfb. They do not use a Neo client and do not establish EAC access, game layout compatibility, ESP rendering or aim response.

The Neo Testbuild 1 EXE (`STELEX_NEO_1040.exe`, protocol `0x4E454F31`) must first be built normally with `source/build.py`. Its reader is the real `era_memory.c`; no test switch or fake reader is present. Run it without Fortnite in a visible console, confirm the menu remains hidden, and send the existing-instance/show message with the probe. Press **Ctrl+C in that console** and confirm the two EXIT log lines and normal shutdown. `desktop_probe.c` records actual Win32 visibility; its `ctrl`/`break` API modes are not relied on because helper-generated console events did not reproduce the user keyboard event in this Wine setup.

The second stage is a **separate test executable**. Compile `era_desktop.c`, `era_core.c`, `era_startup.c` and `desktop_fixture_reader.c` with the existing icon/manifest resource and the same desktop libraries. Deliberately omit `era_memory.c`. Do not distribute this fixture as the product EXE. It publishes partial flags for 5 seconds, all attach flags for 7 seconds, then a process-loss frame. Its fabricated PID/module/flags are never a real process attachment. Match/world status remains unready.

`run_desktop_smoke.py` automates this fixture stage and combines it with the preceding manually observed console test. It requires the product `show` probe plus tested-product SHA256 at `research/SMOKE_shipped_probe.json` and the shipping runtime evidence in `research/SMOKE_shipped_runtime.log`. A warm idle Wine server avoids startup-delay races; it can be kept briefly with `wineserver -p60`. Pass explicit Wine, prefix, probe and fixture paths as command-line options. The script uses an existing visible Xvfb display and writes the resulting report to `research/STARTUP_VALIDATION.json`.

Useful build commands (Zig 0.15.2+, writable Zig cache paths):

```sh
zig cc -target x86_64-windows-gnu -std=c11 -O2 -Wall -Wextra -Werror tests/desktop_probe.c -luser32 -o /tmp/neo-desktop-probe.exe
zig cc -target x86_64-windows-gnu -std=c11 -O2 -Wall -Wextra -Werror -municode -Wl,--subsystem,console source/era_desktop.c source/era_core.c source/era_startup.c tests/desktop_fixture_reader.c build/app.res -luser32 -lgdi32 -lshell32 -lversion -lwinmm -o /tmp/neo-smoke-fixture.exe
```

The JSON pins the tested product and fixture hashes and separates product waiting/blocked-show/shutdown checks from simulated attach/menu/loss checks. Screenshots and runtime excerpts are evidence, not live-game validation.

Neo uses separate window classes `STELEX_NEO_1040_MENU` / `STELEX_NEO_1040_OVERLAY`, mutex `Local\STELEX_NEO_1040_DESKTOP` and LocalAppData folder `STELEX_NEO_1040`. The menu title is `STELEX NEO | 10.40-CL-9380822 | Testbuild 1`; the console title adds ` | Verbindung und Logs`. Console state lines begin with `[STATE NEO]`. ERA startup evidence must not be reused as Neo evidence.
