#include "../source/era_identity.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

static int checks,failures;
#define CHECK(condition) do {checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);failures++;}} while(0)
static size_t wide(const char*text,uint16_t*out){
    size_t i=0;do{out[i]=(unsigned char)text[i];}while(text[i++]);return i;
}
static size_t image16(const char*text,unsigned char*out,int terminate){
    size_t i=0;while(text[i]){out[i*2]=(unsigned char)text[i];out[i*2+1]=0;i++;}
    if(terminate){out[i*2]=out[i*2+1]=0;i++;}return i*2;
}

int main(void){
    uint16_t buffer[4200];unsigned char bytes[512];size_t chars;
    const char*valid[]={
        "++Fortnite+Release-10.40-CL-9380822-Windows",
        "4.23.0-9380822+++Fortnite+Release-10.40",
        "4.23.0.9380822","10.40 CL-9380822","Fortnite 10.40 (9380822)",
        "4.23.0 build9380822"
    };
    for(unsigned i=0;i<sizeof(valid)/sizeof(valid[0]);i++){chars=wide(valid[i],buffer);CHECK(era_identity_text16(buffer,chars));}
    const char*invalid[]={
        "", "10.40", "9380822", "9.40 CL-9380822", "10.400 CL-9380822", "110.40 CL-9380822",
        "10.40 CL-93808220","10.40 CL-19380822","10.40 CL-9380821",
        "4.23.00 CL-9380822","14.23.0 CL-9380822","4.23.1 CL-9380822",
        "4.23.0.93808220","4.23.0.9380821","4.23.0.19380822",
        "1.10.40 CL-9380822", "10.40.1 CL-9380822","10.40 CL-9380822.1",
        "++Fortnite+Release-9.41-CL-7609292-Windows",
        "4.23.0-7609292+++Fortnite+Release-9.41", "4.23.0.7609292",
        "9.41 CL-9380822", "10.40 CL-7609292", "10.40 CL-9380823",
        "10.41 CL-9380822", "10.30 CL-9380822"
    };
    for(unsigned i=0;i<sizeof(invalid)/sizeof(invalid[0]);i++){chars=wide(invalid[i],buffer);CHECK(!era_identity_text16(buffer,chars));}
    CHECK(!era_identity_text16(NULL,0));CHECK(!era_identity_text16(NULL,4096));
    chars=wide(valid[0],buffer);CHECK(!era_identity_text16(buffer,chars-1));CHECK(!era_identity_text16(buffer,0));
    buffer[0]=0;CHECK(!era_identity_text16(buffer,chars));
    for(size_t i=0;i<4200;i++)buffer[i]='x';
    buffer[4199]=0;CHECK(!era_identity_text16(buffer,4200));
    chars=wide(valid[0],buffer);buffer[chars-1]='x';CHECK(!era_identity_text16(buffer,chars));

    const char*markers[]={"++Fortnite+Release-10.40-CL-9380822","4.23.0-9380822+++Fortnite+Release-10.40"};
    for(unsigned i=0;i<2;i++){
        const char*marker=markers[i];size_t count=strlen(marker);
        CHECK(era_identity_image((const unsigned char*)marker,count));CHECK(era_identity_image((const unsigned char*)marker,count+1));
        CHECK(!era_identity_image((const unsigned char*)marker,count-1));
        for(size_t limit=0;limit<count;limit++)CHECK(!era_identity_image((const unsigned char*)marker,limit));
        char text[256];snprintf(text,sizeof(text),"%s-Windows",marker);CHECK(era_identity_image((const unsigned char*)text,strlen(text)+1));
        snprintf(text,sizeof(text),"%s more",marker);CHECK(era_identity_image((const unsigned char*)text,strlen(text)+1));
        const char*bad_suffix[]={"0",".1","X","+Other"};
        for(unsigned j=0;j<sizeof(bad_suffix)/sizeof(bad_suffix[0]);j++){
            snprintf(text,sizeof(text),"%s%s",marker,bad_suffix[j]);CHECK(!era_identity_image((const unsigned char*)text,strlen(text)+1));
        }
        size_t size=image16(marker,bytes,0);CHECK(era_identity_image(bytes,size));
        for(size_t limit=0;limit<size;limit++)CHECK(!era_identity_image(bytes,limit));
        bytes[size]=0;CHECK(!era_identity_image(bytes,size+1));bytes[size+1]=0;CHECK(era_identity_image(bytes,size+2));
        bytes[size]='-';CHECK(era_identity_image(bytes,size+2));bytes[size]='0';CHECK(!era_identity_image(bytes,size+2));
        bytes[size]=' ';CHECK(era_identity_image(bytes,size+2));bytes[size]='X';CHECK(!era_identity_image(bytes,size+2));
        size=image16(marker,bytes+1,1);bytes[0]=0xEF;CHECK(era_identity_image(bytes,size+1));
    }
    CHECK(!era_identity_image(NULL,100));CHECK(!era_identity_image(bytes,0));
    const char*near_release="++Fortnite+Release-10.400-CL-9380822";
    CHECK(!era_identity_image((const unsigned char*)near_release,strlen(near_release)+1));
    const char*numeric_prefix="14.23.0-9380822+++Fortnite+Release-10.40";
    CHECK(!era_identity_image((const unsigned char*)numeric_prefix,strlen(numeric_prefix)+1));
    const char*rejected_images[]={
        "++Fortnite+Release-9.41-CL-7609292",
        "4.23.0-7609292+++Fortnite+Release-9.41",
        "++Fortnite+Release-10.40-CL-7609292",
        "++Fortnite+Release-9.41-CL-9380822",
        "++Fortnite+Release-10.40-CL-9380821",
        "++Fortnite+Release-10.40-CL-9380823",
        "++Fortnite+Release-10.41-CL-9380822"
    };
    for(unsigned i=0;i<sizeof(rejected_images)/sizeof(rejected_images[0]);i++){
        CHECK(!era_identity_image((const unsigned char*)rejected_images[i],strlen(rejected_images[i])+1));
        size_t size=image16(rejected_images[i],bytes,1);CHECK(!era_identity_image(bytes,size));
    }

    chars=wide("++Fortnite+Release-10.40",buffer);
    CHECK(era_identity_engine(4,23,0,9380822,buffer,chars));
    CHECK(era_identity_engine(4,23,0,UINT32_C(9380822)|UINT32_C(0x80000000),buffer,chars));
    CHECK(!era_identity_engine(5,23,0,9380822,buffer,chars));CHECK(!era_identity_engine(4,22,0,9380822,buffer,chars));
    CHECK(!era_identity_engine(4,23,1,9380822,buffer,chars));CHECK(!era_identity_engine(4,23,0,9380821,buffer,chars));
    CHECK(!era_identity_engine(4,23,0,93808220,buffer,chars));CHECK(!era_identity_engine(4,23,0,9380822,buffer,chars-1));
    CHECK(!era_identity_engine(4,23,0,9380822,NULL,chars));
    chars=wide("++Fortnite+Release-10.400",buffer);CHECK(!era_identity_engine(4,23,0,9380822,buffer,chars));
    chars=wide("++Fortnite+Release-10.40-Windows",buffer);CHECK(!era_identity_engine(4,23,0,9380822,buffer,chars));
    chars=wide("++Fortnite+Release-10.40",buffer);buffer[chars]='x';buffer[chars+1]=0;CHECK(!era_identity_engine(4,23,0,9380822,buffer,chars+2));
    chars=wide("++Fortnite+Release-9.41",buffer);CHECK(!era_identity_engine(4,23,0,7609292,buffer,chars));
    CHECK(!era_identity_engine(4,23,0,9380822,buffer,chars));
    chars=wide("++Fortnite+Release-10.40",buffer);CHECK(!era_identity_engine(4,23,0,7609292,buffer,chars));
    CHECK(!era_identity_engine(4,23,0,9380823,buffer,chars));
    printf("NEO build identity: %d assertions, %d failures\n",checks,failures);return failures?1:0;
}
