"""Wine/Xvfb smoke test. Reader fixture is TEST ONLY; no Neo client is attached.

Completes the fixture phase after the manually observed product-console test.
The product probe JSON and console-key shutdown log must already exist.
Requires compiled tests/desktop_probe.c and a separate fixture executable,
Wine 10/Xvfb, and the environment paths supplied by --wine/--prefix/--fixture.
Use a dedicated idle Wine prefix. Does not build or modify the product EXE.
"""
from __future__ import annotations
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def main()->int:
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--wine',required=True);p.add_argument('--prefix',required=True);p.add_argument('--probe',required=True);p.add_argument('--fixture',required=True);args=p.parse_args()
 env=os.environ.copy();env['WINEPREFIX']=args.prefix;env.setdefault('DISPLAY',':99')
 evidence=ROOT/'research';runtime=Path(args.prefix)/'drive_c/users/agent/AppData/Local/STELEX_NEO_1040/runtime.log'
 product=ROOT/'STELEX_NEO_1040.exe';initial_hash=hashlib.sha256(product.read_bytes()).hexdigest()
 shipping_proof=json.loads((evidence/'SMOKE_shipped_probe.json').read_text())
 assert shipping_proof['artifact_sha256']==initial_hash,'Shipping proof is from a different EXE'
 shipped=shipping_proof['probe']
 assert shipped['protocol']==0x4E454F31
 assert shipped['console_visible'] and shipped['menu_exists'] and not shipped['menu_visible'] and not shipped['overlay_visible']
 txt=(evidence/'SMOKE_shipped_runtime.log').read_text();assert 'Testbuild 1 - Speichern und Aktivierung' in txt and '[STATE NEO]' in txt
 assert '[MENU] Gesperrt:' in txt and '[EXIT] Beenden ueber Konsole angefordert.' in txt and '[EXIT] Worker und Fenster beendet.' in txt
 before=runtime.stat().st_size
 process_log=open('/tmp/neo-smoke-fixture-launch.log','w')
 console=Path(args.prefix)/'drive_c/windows/system32/wineconsole.exe'
 proc=subprocess.Popen([args.wine,str(console),'Z:'+str(Path(args.fixture)).replace('/','\\')],env=env,stdout=process_log,stderr=process_log)
 counter=0
 def probe(mode='probe'):
  nonlocal counter
  counter+=1;file=Path('/tmp')/('neo-fixture-probe-'+str(counter)+'.json')
  file.unlink(missing_ok=True)
  result=subprocess.run([args.wine,args.probe,mode,'Z:'+str(file).replace('/','\\')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
  return json.loads(file.read_text()) if file.exists() else {'menu_exists':False,'returncode':result.returncode}
 def wait_for(predicate,timeout):
  end=time.monotonic()+timeout;last={}
  while time.monotonic()<end:
   last=probe()
   if predicate(last):return last
   time.sleep(.05)
  raise AssertionError(('Timed out waiting for window state',last))
 waiting=wait_for(lambda x:x.get('menu_exists') and x.get('console_visible'),4)
 assert not waiting['menu_visible'] and not waiting['overlay_visible']
 blocked=probe('show');assert not blocked['menu_visible']
 attached=wait_for(lambda x:x.get('menu_visible'),8)
 assert attached['console_visible'] and not attached['overlay_visible']
 try:
  from PIL import ImageGrab
  ImageGrab.grab(xdisplay=env['DISPLAY']).save(evidence/'SMOKE_simulated_attach_menu.png')
 except ImportError:pass
 lost=wait_for(lambda x:x.get('menu_exists') and not x.get('menu_visible'),9)
 blocked_after_loss=probe('show');assert not blocked_after_loss['menu_visible']
 probe('close');proc.wait(timeout=8)
 fixture_txt=runtime.read_bytes()[before:].decode('utf-8')
 (evidence/'SMOKE_fixture_runtime.log').write_text(fixture_txt)
 for required in ['[ATTACH] Bestaetigt:','[ATTACH] Verbindung/Lesenachweis verloren.','[EXIT] Worker und Fenster beendet.']:
  assert required in fixture_txt,required
 assert hashlib.sha256(product.read_bytes()).hexdigest()==initial_hash
 report={'passed':True,'windows_started':False,'wine_started':True,'environment':'Wine 10.0 / Xvfb / Linux; product launched through Wine console host','artifact_sha256':initial_hash,'live_neo_validated':False,'live_fortnite_validated':False,'eac_access_validated':False,
 'product_file':product.name,'console_marker':'Testbuild 1','protocol':hex(shipped['protocol']),
 'shipping_exe_without_game':{'console_visible':True,'menu_created_hidden':True,'overlay_hidden':True,'show_request_without_attach_blocked':True,'state_heartbeat_and_runtime_log':True,'actual_console_ctrl_c_key_clean_shutdown':True,'probe':shipped},
 'separate_test_only_reader_fixture':{'fixture_sha256':hashlib.sha256(Path(args.fixture).read_bytes()).hexdigest(),'no_real_process_attached':True,'initial_build_missing_hidden':waiting,'manual_show_without_build_blocked':blocked,'simulated_verified_attach_opens_menu':attached,'simulated_process_loss_hides_menu':lost,'manual_show_after_loss_blocked':blocked_after_loss,'message_shutdown_clean':True,'fixture_is_not_distributed_product_binary':True},
 'limits':['No actual Neo/Fortnite client, game memory, overlay rendering or aim response was validated.','Wine control events generated by an attached helper did not reproduce user Ctrl+C; actual console keyboard Ctrl+C was used and clean shutdown confirmed.','Only product waiting/blocked-show/shutdown and simulated reader menu transitions were executed.'],
 'evidence':['SMOKE_shipped_runtime.log','SMOKE_shipped_probe.json','SMOKE_fixture_runtime.log','SMOKE_console_waiting.png','SMOKE_simulated_attach_menu.png']}
 (evidence/'STARTUP_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS: product console/hidden menu, blocked show, actual console Ctrl+C; TEST-ONLY reader attach opens menu and loss hides it; no live Neo test.')
 return 0
if __name__=='__main__':raise SystemExit(main())
