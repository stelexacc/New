#include "../source/era_types.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

static int checks,failures;
#define CHECK(condition) do {checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);failures++;}} while(0)
static int near(double a,double b,double tolerance){return fabs(a-b)<=tolerance;}
static EraTransform identity(void){return (EraTransform){{0,0,0,1},{0,0,0},0,{1,1,1},0};}
static EraFrame fixture(void){
    EraFrame frame={0};frame.status=ERA_READY;frame.local_alive=1;frame.local_pawn=1;frame.local_team=2;
    frame.camera=(EraCamera){{0,0,0},{0,0,0},90};frame.count=2;
    for(int i=0;i<2;i++){
        frame.entities[i].id=(uint64_t)(10+i);frame.entities[i].team=3;frame.entities[i].alive=1;
        frame.entities[i].health_valid=1;frame.entities[i].health=100;frame.entities[i].target_mask=7;
        for(int j=0;j<3;j++)frame.entities[i].targets[j]=(EraVec3){1000,(float)(20+i*20),0};
    }
    return frame;
}

static void test_projection(void){
    EraCamera camera={{0,0,0},{0,0,0},90};EraPoint point={-1,-1};
    CHECK(era_project(&camera,(EraVec3){100,0,0},1920,1080,&point));CHECK(near(point.x,960,0.001));CHECK(near(point.y,540,0.001));
    CHECK(era_project(&camera,(EraVec3){100,100,0},1920,1080,&point));CHECK(near(point.x,1920,0.001));
    CHECK(era_project(&camera,(EraVec3){100,0,50},1920,1080,&point));CHECK(near(point.y,60,0.001));
    CHECK(!era_project(&camera,(EraVec3){-1,0,0},1920,1080,&point));
    CHECK(!era_project(&camera,(EraVec3){0,0,1},1920,1080,&point));
    CHECK(!era_project(&camera,(EraVec3){0.001f,0,0},1920,1080,&point));
    camera.rotation.y=90;CHECK(era_project(&camera,(EraVec3){0,100,0},1920,1080,&point));CHECK(near(point.x,960,0.001));CHECK(near(point.y,540,0.001));
    CHECK(era_project(&camera,(EraVec3){-10,100,0},1920,1080,&point));CHECK(point.x>960);
    camera.rotation=(EraVec3){90,0,0};CHECK(era_project(&camera,(EraVec3){0,0,100},1920,1080,&point));CHECK(near(point.x,960,0.001));CHECK(near(point.y,540,0.001));
    camera.rotation=(EraVec3){0,0,90};CHECK(era_project(&camera,(EraVec3){100,10,0},1920,1080,&point));CHECK(near(point.x,960,0.001));CHECK(point.y<540);
    camera.rotation=(EraVec3){0,0,0};camera.location=(EraVec3){100,200,300};CHECK(era_project(&camera,(EraVec3){200,200,300},1000,1000,&point));CHECK(near(point.x,500,0.001));CHECK(near(point.y,500,0.001));
    camera.fov=NAN;CHECK(!era_camera_valid(&camera));CHECK(!era_project(&camera,(EraVec3){200,200,300},1920,1080,&point));
    camera.fov=180;CHECK(!era_camera_valid(&camera));camera.fov=1;CHECK(!era_camera_valid(&camera));camera.fov=90;
    CHECK(!era_project(&camera,(EraVec3){NAN,0,0},1920,1080,&point));CHECK(!era_project(&camera,(EraVec3){200,200,300},0,1080,&point));
    CHECK(!era_project(&camera,(EraVec3){200,200,300},1920,32769,&point));CHECK(!era_project(&camera,(EraVec3){200,200,300},1920,1080,NULL));
    CHECK(!era_project(NULL,(EraVec3){200,200,300},1920,1080,&point));
    CHECK(isinf(era_distance((EraVec3){NAN,0,0},(EraVec3){0,0,0})));
    CHECK(near(era_distance((EraVec3){0,0,0},(EraVec3){3,4,12}),13,0.001));
}

static void test_transforms(void){
    EraTransform transform=identity();EraVec3 point=era_transform_point(&transform,(EraVec3){1,2,3});
    CHECK(era_transform_valid(&transform));CHECK(near(point.x,1,0.001));CHECK(near(point.y,2,0.001));CHECK(near(point.z,3,0.001));
    transform.rotation=era_rotation_quat((EraVec3){0,90,0});transform.translation=(EraVec3){10,20,30};transform.scale=(EraVec3){2,2,2};
    point=era_transform_point(&transform,(EraVec3){1,0,0});CHECK(near(point.x,10,0.001));CHECK(near(point.y,22,0.001));CHECK(near(point.z,30,0.001));
    EraTransform child=identity();child.translation=(EraVec3){5,0,0};child.rotation=era_rotation_quat((EraVec3){0,90,0});
    EraTransform combined=era_transform_combine(&transform,&child);CHECK(era_transform_valid(&combined));
    point=era_transform_point(&combined,(EraVec3){1,0,0});CHECK(near(point.x,8,0.001));CHECK(near(point.y,30,0.001));CHECK(near(point.z,30,0.001));
    EraVec3 nested=era_transform_point(&transform,era_transform_point(&child,(EraVec3){3,2,1}));
    EraVec3 direct=era_transform_point(&combined,(EraVec3){3,2,1});
    CHECK(near(direct.x,nested.x,0.001));CHECK(near(direct.y,nested.y,0.001));CHECK(near(direct.z,nested.z,0.001));
    transform.rotation=era_rotation_quat((EraVec3){90,0,0});transform.translation=(EraVec3){0,0,0};transform.scale=(EraVec3){1,1,1};
    point=era_transform_point(&transform,(EraVec3){1,0,0});CHECK(near(point.x,0,0.001));CHECK(near(point.z,1,0.001));
    transform.rotation=era_rotation_quat((EraVec3){0,0,90});point=era_transform_point(&transform,(EraVec3){0,1,0});CHECK(near(point.y,0,0.001));CHECK(near(point.z,-1,0.001));
    transform.scale.x=0;CHECK(!era_transform_valid(&transform));CHECK(!era_vec_valid(era_transform_point(&transform,(EraVec3){1,2,3})));
    combined=era_transform_combine(&transform,&child);CHECK(!era_transform_valid(&combined));
    CHECK(!era_transform_valid(NULL));transform=identity();transform.rotation.w=NAN;CHECK(!era_transform_valid(&transform));
    transform=identity();transform.translation.x=INFINITY;CHECK(!era_transform_valid(&transform));
    transform=identity();transform.scale.y=-1;CHECK(era_transform_valid(&transform));point=era_transform_point(&transform,(EraVec3){1,2,3});CHECK(near(point.y,-2,0.001));
    EraQuat q=era_rotation_quat((EraVec3){0,450,0});CHECK(near(q.z,sqrt(0.5),0.001));
}

static void test_config(void){
    EraConfig config;era_config_defaults(&config);CHECK(!config.aim_enabled);CHECK(!config.esp_enabled);CHECK(!config.crosshair_enabled);
    CHECK(config.aim_ring_enabled==1);
    CHECK(config.aim_key==2);CHECK(config.aim_part==1);CHECK(config.aim_fov_degrees==8);CHECK(config.aim_smooth==6);CHECK(config.aim_strength==100);
    CHECK(config.aim_gain_percent==100);CHECK(config.esp_max_distance_m==500);CHECK(config.crosshair_outline==1);
    config.aim_key=INT_MIN;config.aim_part=INT_MAX;config.aim_fov_degrees=-100;config.aim_smooth=INT_MAX;config.aim_strength=0;
    config.aim_gain_percent=INT_MAX;config.esp_max_distance_m=INT_MAX;config.crosshair_red=-1;config.crosshair_green=999;config.crosshair_blue=128;
    config.crosshair_thickness=-1;config.crosshair_length=999;config.crosshair_gap=-10;config.crosshair_preset=99;config.aim_enabled=-99;
    era_config_clamp(&config);CHECK(config.aim_key==1);CHECK(config.aim_part==2);CHECK(config.aim_fov_degrees==1);CHECK(config.aim_smooth==30);
    CHECK(config.aim_strength==1);CHECK(config.aim_gain_percent==200);CHECK(config.esp_max_distance_m==2000);CHECK(config.crosshair_red==0);
    CHECK(config.crosshair_green==255);CHECK(config.crosshair_blue==128);CHECK(config.crosshair_thickness==1);CHECK(config.crosshair_length==40);
    CHECK(config.crosshair_gap==0);CHECK(config.crosshair_preset==2);CHECK(config.aim_enabled==1);era_config_clamp(NULL);era_config_defaults(NULL);
    config.aim_ring_enabled=-5;era_config_clamp(&config);CHECK(config.aim_ring_enabled==1);
    config.aim_ring_enabled=0;era_config_clamp(&config);CHECK(config.aim_ring_enabled==0);
}

static void test_aim(void){
    EraFrame frame=fixture();EraConfig config;era_config_defaults(&config);config.aim_enabled=1;
    EraAimState state={0};EraMotion motion={0};
    CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==10);CHECK(motion.dx>0);CHECK(motion.dy==0);
    frame.entities[0].team=2;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==11);
    frame.entities[0].team=0;frame.entities[1].team=0;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(!motion.target);
    config.aim_team_filter=0;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==10);
    frame=fixture();frame.entities[0].downed=1;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==11);
    frame.entities[1].alive=0;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame=fixture();frame.entities[0].target_mask=1;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==11);
    frame.entities[1].target_mask=1;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame=fixture();frame.entities[0].health=0;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==11);
    frame.entities[1].health=NAN;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame=fixture();frame.entities[0].id=frame.local_pawn;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==11);
    frame=fixture();frame.count=1;frame.entities[0].targets[1]=(EraVec3){1000,500,0};CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    config.aim_fov_degrees=30;CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    config.esp_max_distance_m=1;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    config.esp_max_distance_m=500;frame.entities[0].targets[1].x=-1000;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));

    /* A held hard lock cannot silently transfer when its original target vanishes. */
    frame=fixture();config.aim_hard_lock=1;config.aim_fov_degrees=8;era_aim_reset(&state);
    CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==10);
    frame.entities[0].alive=0;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(state.target==10);
    CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,0,&motion));CHECK(!state.target);
    CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(motion.target==11);
    config.aim_enabled=0;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));CHECK(!state.target);config.aim_enabled=1;

    /* Invalid tick lengths and malformed frame bounds produce no mouse movement. */
    double invalid_dt[]={0,-0.01,NAN,INFINITY,1.0};
    for(unsigned i=0;i<sizeof(invalid_dt)/sizeof(invalid_dt[0]);i++){
        motion=(EraMotion){123,456,789};CHECK(!era_aim_update(&frame,&config,&state,1920,1080,invalid_dt[i],1,&motion));CHECK(motion.dx==0&&motion.dy==0&&motion.target==0);
    }
    frame.count=ERA_MAX_ENTITIES+1;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame.count=-1;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame=fixture();frame.local_alive=0;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame.local_alive=1;frame.status=ERA_READ_FAILED;CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));
    frame=fixture();CHECK(!era_aim_update(&frame,&config,&state,0,1080,1.0/60.0,1,&motion));
    CHECK(!era_aim_update(NULL,&config,&state,1920,1080,1.0/60.0,1,&motion));
    CHECK(!era_aim_update(&frame,NULL,&state,1920,1080,1.0/60.0,1,&motion));
    CHECK(!era_aim_update(&frame,&config,NULL,1920,1080,1.0/60.0,1,&motion));
    CHECK(!era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,NULL));

    /* Fractional input accumulates without losing sub-pixel corrections. */
    config.aim_hard_lock=0;config.aim_smooth=30;frame=fixture();frame.count=1;
    frame.entities[0].targets[1]=(EraVec3){1000,1,0};era_aim_reset(&state);int total=0;
    for(int i=0;i<100;i++){CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/60.0,1,&motion));total+=motion.dx;}
    CHECK(total>=3&&total<=4);
    /* Per-second response remains equivalent across different render rates. */
    double final[2]={0};
    for(int variant=0;variant<2;variant++){
        frame=fixture();frame.count=1;config.aim_smooth=6;era_aim_reset(&state);
        int rate=variant?120:60;double screen_error=96.0;
        for(int i=0;i<rate;i++){
            frame.entities[0].targets[1].y=(float)(screen_error*1000.0/960.0);
            CHECK(era_aim_update(&frame,&config,&state,1920,1080,1.0/rate,1,&motion));screen_error-=motion.dx;
        }
        final[variant]=screen_error;
    }
    CHECK(fabs(final[0]-final[1])<=1.0);CHECK(final[0]<=1.0&&final[1]<=1.0);
}

int main(void){test_projection();test_transforms();test_config();test_aim();
    printf("ERA core: %d assertions, %d failures\n",checks,failures);return failures?1:0;}
