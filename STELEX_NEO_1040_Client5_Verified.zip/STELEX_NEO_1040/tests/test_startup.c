#include "../source/era_startup.h"
#include <stdio.h>
#include <string.h>

static int assertions,failures;
#define CHECK(value) do{assertions++;if(!(value)){failures++;fprintf(stderr,"startup line %d: %s\n",__LINE__,#value);}}while(0)
static EraFrame frame;
static void valid_frame(void){
    memset(&frame,0,sizeof(frame));
    frame.pid=123;frame.module_base=UINT64_C(0x140000000);
    frame.attach_flags=ERA_ATTACH_COMPLETE;frame.captured_ms=1000;
    frame.status=ERA_FINDING_ENGINE;
}

int main(void){
    EraStartupState state={0};
    CHECK(!era_startup_can_show(NULL,1000));
    CHECK(era_startup_update(NULL,NULL,1000)==ERA_STARTUP_NO_CHANGE);
    CHECK(era_startup_update(&state,NULL,1000)==ERA_STARTUP_NO_CHANGE);
    CHECK(!state.attached&&!state.pid&&!state.module_base);
    valid_frame();
    /* Opening the verified process is insufficient without both independent
       module-read and build evidence. Unknown extra facts are harmless. */
    for(unsigned flags=0;flags<8;flags++){
        frame.attach_flags=flags;
        CHECK(era_startup_can_show(&frame,1000)==(flags==ERA_ATTACH_COMPLETE));
    }
    frame.attach_flags=ERA_ATTACH_COMPLETE|UINT32_C(0x80000000);
    CHECK(era_startup_can_show(&frame,1000));
    frame.attach_flags=ERA_ATTACH_PROCESS|ERA_ATTACH_BUILD;
    CHECK(era_startup_update(&state,&frame,1000)==ERA_STARTUP_NO_CHANGE);
    CHECK(!state.attached);
    frame.attach_flags=ERA_ATTACH_COMPLETE;
    CHECK(era_startup_update(&state,&frame,1000)==ERA_STARTUP_ATTACHED);
    CHECK(state.attached&&state.pid==frame.pid&&state.module_base==frame.module_base);
    CHECK(era_startup_update(&state,&frame,1001)==ERA_STARTUP_NO_CHANGE);
    /* The menu is useful for diagnosis while game-world data is not ready. */
    const EraStatus waiting[]={ERA_FINDING_ENGINE,ERA_WAITING_WORLD,ERA_WAITING_MATCH,ERA_READ_FAILED,ERA_READY};
    for(unsigned i=0;i<sizeof(waiting)/sizeof(waiting[0]);i++){
        frame.status=waiting[i];frame.sequence++;
        CHECK(era_startup_can_show(&frame,1001));
        CHECK(era_startup_update(&state,&frame,1001)==ERA_STARTUP_NO_CHANGE);
    }
    frame.pid=124;
    CHECK(era_startup_update(&state,&frame,1001)==ERA_STARTUP_REPLACED);
    CHECK(state.attached&&state.pid==124);
    frame.module_base=UINT64_C(0x180000000);
    CHECK(era_startup_update(&state,&frame,1001)==ERA_STARTUP_REPLACED);
    CHECK(state.module_base==frame.module_base);
    frame.attach_flags=ERA_ATTACH_PROCESS;
    CHECK(era_startup_update(&state,&frame,1002)==ERA_STARTUP_DETACHED);
    CHECK(!state.attached&&!state.pid&&!state.module_base);
    CHECK(era_startup_update(&state,&frame,1003)==ERA_STARTUP_NO_CHANGE);
    frame.attach_flags=ERA_ATTACH_COMPLETE;
    CHECK(era_startup_update(&state,&frame,1004)==ERA_STARTUP_ATTACHED);
    CHECK(era_startup_update(&state,NULL,1004)==ERA_STARTUP_DETACHED);
    CHECK(!state.attached&&!state.pid&&!state.module_base);

    valid_frame();frame.pid=0;CHECK(!era_startup_can_show(&frame,1000));frame.pid=1;
    const uint64_t invalid_bases[]={0,1,UINT64_C(0xffff),UINT64_C(0x800000000000),UINT64_C(0xffff800000000000),UINT64_MAX};
    for(unsigned i=0;i<sizeof(invalid_bases)/sizeof(invalid_bases[0]);i++){
        frame.module_base=invalid_bases[i];CHECK(!era_startup_can_show(&frame,1000));
    }
    frame.module_base=UINT64_C(0x10000);CHECK(era_startup_can_show(&frame,1000));
    frame.module_base=UINT64_C(0x7fffffffffff);CHECK(era_startup_can_show(&frame,1000));
    valid_frame();
    CHECK(!era_startup_can_show(&frame,999));
    CHECK(era_startup_can_show(&frame,1000));
    CHECK(era_startup_can_show(&frame,6000));
    CHECK(!era_startup_can_show(&frame,6001));
    CHECK(!era_startup_can_show(&frame,UINT64_MAX));
    CHECK(era_startup_update(&state,&frame,6000)==ERA_STARTUP_ATTACHED);
    CHECK(era_startup_update(&state,&frame,6001)==ERA_STARTUP_DETACHED);
    frame.captured_ms=UINT64_MAX;
    CHECK(!era_startup_can_show(&frame,UINT64_MAX-1));
    CHECK(era_startup_can_show(&frame,UINT64_MAX));
    CHECK(era_startup_update(&state,&frame,UINT64_MAX)==ERA_STARTUP_ATTACHED);
    frame.captured_ms=UINT64_MAX-5000;
    CHECK(era_startup_can_show(&frame,UINT64_MAX));
    frame.captured_ms=UINT64_MAX-5001;
    CHECK(!era_startup_can_show(&frame,UINT64_MAX));
    CHECK(era_startup_update(&state,&frame,UINT64_MAX)==ERA_STARTUP_DETACHED);
    CHECK(!state.attached&&!state.pid&&!state.module_base);
    printf("ERA startup: %d assertions, %d failures\n",assertions,failures);
    return failures?1:0;
}
