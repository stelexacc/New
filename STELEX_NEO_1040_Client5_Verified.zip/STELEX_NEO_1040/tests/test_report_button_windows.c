/* Actual connection-page hit testing/message dispatch. Only the probe launch
 * operation is replaced; this test never launches a game, probe or mouse input. */
#define WIN32_LEAN_AND_MEAN
#define UNICODE 1
#define _UNICODE 1
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include "../source/era_probe_launcher.h"
static EraProbeLaunchResult report_test_launch(uintptr_t owner,uint32_t pid);
#define era_probe_launch report_test_launch
#define wmain desktop_console_not_started
#define wWinMain desktop_entry_not_started
#include "../source/era_desktop.c"
#undef era_probe_launch
#undef wmain
#undef wWinMain

static int checks,failures,launch_calls;
static uint32_t requested_pid;
static uintptr_t requested_owner;
static EraProbeLaunchResult fixture_result;
#define CHECK(condition) do {checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);failures++;}}while(0)
static EraProbeLaunchResult report_test_launch(uintptr_t owner,uint32_t pid){
    launch_calls++;requested_owner=owner;requested_pid=pid;return fixture_result;
}
int wmain(void){
    InitializeCriticalSection(&log_lock);log_file[0]=0;
    menu_window=CreateWindowExW(0,L"STATIC",L"Native report button fixture",WS_POPUP,
        0,0,1120,790,NULL,NULL,GetModuleHandleW(NULL),NULL);
    CHECK(menu_window!=NULL);if(!menu_window)return 2;
    HDC target=GetDC(menu_window);CHECK(target!=NULL);
    CHECK(canvas_prepare(&menu_canvas,target,1120,790));ReleaseDC(menu_window,target);
    if(!menu_canvas.dc){DestroyWindow(menu_window);return 3;}
    era_config_defaults(&config);config_dirty=0;selected=4;scroll[4]=0;
    font_regular=font_small=font_bold=font_brand=(HFONT)GetStockObject(DEFAULT_GUI_FONT);
    display_frame=(EraFrame){0};display_frame.status=ERA_FINDING_NAMES;
    display_frame.pid=34956;display_frame.attach_flags=ERA_ATTACH_COMPLETE;
    draw_menu(menu_canvas.dc,1120,790);
    int index=-1,count=0;
    for(int i=0;i<hit_count;i++)if(hits[i].kind==8){index=i;count++;}
    CHECK(count==1);CHECK(index>=0);
    if(index<0){canvas_close(&menu_canvas);DestroyWindow(menu_window);return 4;}
    Hit report=hits[index];int x=(report.r.left+report.r.right)/2,y=(report.r.top+report.r.bottom)/2;
    CHECK(y>=124&&y<790-43);CHECK(report.r.right>report.r.left);
    fixture_result=(EraProbeLaunchResult){1,1,ERA_PROBE_FAILURE_NONE,0,0};
    menu_proc(menu_window,WM_LBUTTONDOWN,0,MAKELPARAM(x,y));
    CHECK(launch_calls==1);CHECK(requested_pid==34956);CHECK(requested_owner==(uintptr_t)menu_window);
    CHECK(wcsstr(notice,L"Clientbericht angefordert")!=NULL);
    CHECK(display_frame.status==ERA_FINDING_NAMES);CHECK(!display_frame.names_ready);
    CHECK(!config.aim_enabled);CHECK(!config.esp_enabled);
    /* Lost process evidence at click time uses file selection instead. */
    display_frame.attach_flags=0;
    fixture_result=(EraProbeLaunchResult){1,0,ERA_PROBE_FAILURE_NONE,0,0};
    menu_proc(menu_window,WM_LBUTTONDOWN,0,MAKELPARAM(x,y));
    CHECK(launch_calls==2);CHECK(requested_pid==0);CHECK(wcsstr(notice,L"Clientdatei")!=NULL);
    fixture_result=(EraProbeLaunchResult){0,0,ERA_PROBE_FAILURE_HASH,ERROR_INVALID_DATA,0};
    menu_proc(menu_window,WM_LBUTTONDOWN,0,MAKELPARAM(x,y));
    CHECK(launch_calls==3);CHECK(wcsstr(notice,L"SHA-256")!=NULL);
    /* A click outside controls must not launch anything. */
    menu_proc(menu_window,WM_LBUTTONDOWN,0,MAKELPARAM(1,1));CHECK(launch_calls==3);
    canvas_close(&menu_canvas);DestroyWindow(menu_window);DeleteCriticalSection(&log_lock);
    printf("NEO report button: %d assertions, %d failures; real menu hit testing, mocked probe start\n",checks,failures);
    return failures?1:0;
}
