/* Resize/redraw stress of the product's actual canvases and all five menu
 * pages. No target process, worker thread, probe or input is started. */
#define WIN32_LEAN_AND_MEAN
#define UNICODE 1
#define _UNICODE 1
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
static HWND fixture_foreground;
static HWND WINAPI resource_test_foreground(void){return fixture_foreground;}
static ULONGLONG WINAPI resource_test_clock(void){return 100000;}
#define GetForegroundWindow resource_test_foreground
#define GetTickCount64 resource_test_clock
#define wmain desktop_console_not_started
#define wWinMain desktop_entry_not_started
#include "../source/era_desktop.c"
#undef GetForegroundWindow
#undef GetTickCount64
#undef wmain
#undef wWinMain

static int checks,failures;
#define CHECK(condition) do {checks++;if(!(condition)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#condition);failures++;}}while(0)
static void clear_pen_cache(void){
    for(int i=0;i<ARRAY_COUNT(cached_pens);i++)if(cached_pens[i].handle){DeleteObject(cached_pens[i].handle);cached_pens[i]=(CachedPen){0};}
}
int wmain(void){
    int result=0;InitializeCriticalSection(&log_lock);log_file[0]=0;
    HWND game=CreateWindowExW(0,L"STATIC",L"GDI stress fixture",WS_POPUP|WS_VISIBLE,
        0,0,1120,790,NULL,NULL,GetModuleHandleW(NULL),NULL);
    CHECK(game!=NULL);if(!game){DeleteCriticalSection(&log_lock);return 2;}
    fixture_foreground=game;era_config_defaults(&config);config.crosshair_enabled=1;
    font_regular=font_small=font_bold=font_brand=(HFONT)GetStockObject(DEFAULT_GUI_FONT);
    display_frame=(EraFrame){0};display_frame.status=ERA_FINDING_NAMES;
    display_frame.pid=GetCurrentProcessId();display_frame.module_base=UINT64_C(0x140000000);
    display_frame.attach_flags=ERA_ATTACH_COMPLETE;display_frame.captured_ms=100000;
    display_frame.game_window=(uintptr_t)game;
    HDC target=GetDC(game);CHECK(target!=NULL);if(!target){DestroyWindow(game);return 3;}
    DWORD baseline=GetGuiResources(GetCurrentProcess(),GR_GDIOBJECTS);
    int allocation_failures=0,invalid_hits=0,iterations=512;
    DWORD warm=0,maximum=baseline;
    const int widths[]={1040,1120,1280,1600,1920};
    const int heights[]={700,790,900,1080};
    for(int i=0;i<iterations;i++){
        int width=widths[i%ARRAY_COUNT(widths)],height=heights[(i/5)%ARRAY_COUNT(heights)];
        if(!canvas_prepare(&menu_canvas,target,width,height)||
           !canvas_prepare(&overlay_canvas,target,width,height)){allocation_failures++;break;}
        selected=i%5;draw_menu(menu_canvas.dc,width,height);
        if(hit_count<=0||hit_count>ARRAY_COUNT(hits))invalid_hits++;
        draw_overlay(overlay_canvas.dc,width,height);GdiFlush();
        DWORD count=GetGuiResources(GetCurrentProcess(),GR_GDIOBJECTS);
        if(i==39)warm=count;
        if(count>maximum)maximum=count;
    }
    CHECK(allocation_failures==0);CHECK(invalid_hits==0);
    CHECK(menu_canvas.width==widths[(iterations-1)%ARRAY_COUNT(widths)]);
    CHECK(overlay_canvas.height==heights[((iterations-1)/5)%ARRAY_COUNT(heights)]);
    /* Invalid dimensions are rejected without destroying retained canvases. */
    HDC retained=menu_canvas.dc;CHECK(!canvas_prepare(&menu_canvas,target,0,700));
    CHECK(menu_canvas.dc==retained);CHECK(!canvas_prepare(&menu_canvas,target,1040,-1));
    CHECK(menu_canvas.dc==retained);
    int supported=baseline>0&&warm>0;
    if(supported){CHECK(maximum<=warm+8);}
    canvas_close(&menu_canvas);canvas_close(&overlay_canvas);clear_pen_cache();GdiFlush();
    DWORD cleaned=GetGuiResources(GetCurrentProcess(),GR_GDIOBJECTS);
    if(supported){CHECK(cleaned<=baseline+2);}
    ReleaseDC(game,target);DestroyWindow(game);DeleteCriticalSection(&log_lock);
    printf("NEO GDI resources: %d assertions, %d failures; redraws=%d resource_api=%d baseline=%lu warm=%lu maximum=%lu cleaned=%lu; no target or input started\n",
        checks,failures,iterations,supported,(unsigned long)baseline,(unsigned long)warm,(unsigned long)maximum,(unsigned long)cleaned);
    return result?result:failures?1:0;
}
