/* TEST-ONLY deterministic reader. It is never linked into the distributed EXE.
   No actual game process or anti-cheat is used by this simulated attach. */
#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE 1
#endif
#ifndef _UNICODE
#define _UNICODE 1
#endif
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include "../source/era_memory.h"
struct EraReader {ULONGLONG started;uint64_t sequence;};
EraReader*era_reader_create(void){EraReader*r=calloc(1,sizeof(*r));if(r)r->started=GetTickCount64();return r;}
void era_reader_destroy(EraReader*r){free(r);}
void era_reader_poll(EraReader*r,EraFrame*f){
    memset(f,0,sizeof(*f));f->captured_ms=GetTickCount64();f->sequence=++r->sequence;
    ULONGLONG elapsed=f->captured_ms-r->started;
    if(elapsed<5000){f->status=ERA_BUILD_UNVERIFIED;f->pid=777;f->module_base=0x140000000ULL;f->attach_flags=ERA_ATTACH_PROCESS|ERA_ATTACH_MODULE;}
    else if(elapsed<12000){f->status=ERA_WAITING_WORLD;f->pid=777;f->module_base=0x140000000ULL;f->attach_flags=ERA_ATTACH_COMPLETE;}
    else f->status=ERA_NOT_RUNNING;
}
const wchar_t*era_status_text(EraStatus s){return s==ERA_BUILD_UNVERIFIED?L"TEST: Buildnachweis fehlt":s==ERA_WAITING_WORLD?L"TEST: Attach bestaetigt, Spielwelt fehlt":L"TEST: Prozess verloren";}
