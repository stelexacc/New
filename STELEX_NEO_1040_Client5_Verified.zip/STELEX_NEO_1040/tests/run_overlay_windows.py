"""Build/run actual GDI overlay checks under Wine without any game or real input."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zig', required=True)
    parser.add_argument('--wine', required=True)
    parser.add_argument('--baseline-desktop', type=Path,
                        help='Optional old desktop source expected to fail the same checks')
    args = parser.parse_args()
    env = os.environ.copy()
    env.setdefault('ZIG_GLOBAL_CACHE_DIR', str(ROOT / 'build/zig-global-cache'))
    env.setdefault('ZIG_LOCAL_CACHE_DIR', str(ROOT / 'build/zig-local-cache'))
    rows = []
    variants = [('current', ROOT / 'source/era_desktop.c')]
    if args.baseline_desktop:
        variants.append(('baseline_negative', args.baseline_desktop.resolve()))
    with tempfile.TemporaryDirectory(prefix='neo-overlay-test-') as temporary:
        directory = Path(temporary)
        for name, implementation in variants:
            output = directory / (name + '.exe')
            command = [args.zig, 'cc', '-target', 'x86_64-windows-gnu', '-std=c11',
                       '-O2', '-Wall', '-Wextra', '-Werror', '-municode',
                       '-Wl,--subsystem,console', '-I' + str(ROOT / 'source'),
                       '-DERA_DESKTOP_SOURCE="' + str(implementation) + '"',
                       str(ROOT / 'tests/test_overlay_windows.c')]
            command += [str(ROOT / 'source' / source) for source in
                        ['era_memory.c', 'era_snapshot.c', 'era_core.c',
                         'era_identity.c', 'era_startup.c','era_probe_launcher.c']]
            command += ['-luser32', '-lgdi32', '-lshell32', '-lversion', '-lwinmm','-ladvapi32',
                        '-o', str(output)]
            compiled = subprocess.run(command, cwd=ROOT, env=env, text=True,
                                      capture_output=True, timeout=240)
            rows.append(dict(name=name + ' compile', passed=compiled.returncode == 0,
                             exit_code=compiled.returncode, stdout=compiled.stdout,
                             stderr=compiled.stderr))
            if compiled.returncode:
                print(compiled.stderr, flush=True)
                continue
            # Wine services may inherit stdout; a disk handle avoids waiting
            # for their pipe EOF after the tested process has already exited.
            log = directory / (name + '.log')
            with log.open('wb') as stream:
                result = subprocess.run([args.wine, str(output)], cwd=ROOT,
                                        env=env, stdout=stream, stderr=stream,
                                        timeout=60)
            text = log.read_text(errors='replace')
            match = re.search(r'NEO screen overlay: (\d+) assertions, (\d+) failures', text)
            passed = bool(match and int(match[1]) == 43 and
                          ((result.returncode == 0 and int(match[2]) == 0)
                           if name == 'current' else
                           (result.returncode == 1 and int(match[2]) > 0)))
            rows.append(dict(name=name + ' execute', passed=passed,
                             expected_success=name == 'current',
                             source_sha256=hashlib.sha256(implementation.read_bytes()).hexdigest(),
                             exit_code=result.returncode, output=text,
                             assertions=int(match[1]) if match else None,
                             failures=int(match[2]) if match else None))
            print(('PASS ' if passed else 'FAIL ') + name, flush=True)
            print(match[0] if match else text[-1000:], flush=True)
    report = dict(passed=len(rows) == 2 * len(variants) and all(row['passed'] for row in rows),
                  wine_execution=True, actual_windows_tested=False,
                  live_neo_tested=False, real_gdi_bitmap=True,
                  real_mouse_input_submitted=False,
                  test_sha256=hashlib.sha256((ROOT / 'tests/test_overlay_windows.c').read_bytes()).hexdigest(),
                  checks=rows)
    (ROOT / 'research/OVERLAY_TEST_RESULTS.json').write_text(json.dumps(report, indent=2) + '\n')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
