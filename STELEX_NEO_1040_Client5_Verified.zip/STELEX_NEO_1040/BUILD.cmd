@echo off
setlocal
cd /d "%~dp0"
python source\build.py
exit /b %ERRORLEVEL%
